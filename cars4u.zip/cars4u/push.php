<?php
#API access key from Google API's Console
    define( 'API_ACCESS_KEY', 'AAAA0L2gPtk:APA91bF6nXcBa70NU0ZD5Y-Cig5OxsD64lZW7oOa_2wd4qn96DPKEPTTl30ss9ZKDbQDhPcIrs2GqhaN4nIwNbwXi8b2qLMiHRcBuck0kgyS9H8bBJ8mT0sLFEgBVBNJU6wfJGDZPyDI' );
 $registrationIds = array("cZgMkFwuRLU:APA91bF9MbGh5Y-kbtectdiaU0lYuRM3lDE7amEAOr64jV65b7Ai_CqAtqJZjSXNVOx3B1frw3ttJMF6rbLDgG7M3TT9yVYa-C8XURX-zWegfygLtMJmvGmf68uCmLvThDIPaSCpdq1o");

 $ids=json_encode($registrationIds);
 #prep the bundle
     $msg = array
          (
		'body' 	=> 'hey',
		'title'	=> 'prerena',
             	'icon'	=> 'myicon',/*Default Icon*/
              	'sound' => 'mySound'/*Default sound*/
          );
	$fields = array
			(
				'to'		=> 'dF0FsdUT3CM:APA91bHrGucd02kPU41BSBve94ab78-vNw50P2s3Eqq8O0Vb-YFq-zhqbgmvhtO8CLrw86E1VmhP6-1-mMQPsTNC7eAEZuLhBNS0YKhXV56fPhPmxFrP6P-p8QRytpCBcoZzM3cAwaq-',
				'notification'	=> $msg
			);
	
	
	$headers = array
			(
				'Authorization: key=' . API_ACCESS_KEY,
				'Content-Type: application/json'
			);
#Send Reponse To FireBase Server	
		$ch = curl_init();
		curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
		curl_setopt( $ch,CURLOPT_POST, true );
		curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
		curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
		curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
		$result = curl_exec($ch );
		curl_close( $ch );
#Echo Result Of FireBase Server
echo $result;