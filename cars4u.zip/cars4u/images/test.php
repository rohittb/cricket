<?php
 include("data/conn.php");
 
   $sql = 'DROP DATABASE cars_bid';
  $result = $connection->query($sql);
   
   if(! $result ) {
      die('Could not delete database db_test: ' . mysql_error());
   }
   
   echo "Database deleted successfully\n";
   
   mysql_close($conn);
?>
