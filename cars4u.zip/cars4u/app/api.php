<?php
   
	/* 
		This is an example class script proceeding secured API
		To use this class you should keep same as query string and function name
		Ex: If the query string value rquest=delete_user Access modifiers doesn't matter but function should be
		     function delete_user(){
				 You code goes here
			 }
		Class will execute the function dynamically;
		
		usage :
		
		    $object->response(output_data, status_code);
			$object->_request	- to get santinized input 	
			
			output_data : JSON (I am using)
			status_code : Send status message for headers
			
		Add This extension for localhost checking :
			Chrome Extension : Advanced REST client Application
			URL : https://chrome.google.com/webstore/detail/hgmloofddffdnphfgcellkdfbfbjeloo
		
		I used the below table for demo purpose.
		
		CREATE TABLE IF NOT EXISTS `users` (
		  `user_id` int(11) NOT NULL AUTO_INCREMENT,
		  `user_fullname` varchar(25) NOT NULL,
		  `user_email` varchar(50) NOT NULL,
		  `user_password` varchar(50) NOT NULL,
		  `user_status` tinyint(1) NOT NULL DEFAULT '0',
		  PRIMARY KEY (`user_id`)
		) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;
 	*/
	error_reporting(E_ALL ^ E_NOTICE);
ini_set('display_errors', '1');
	require_once("Rest.inc.php");
	require_once('conn.php');
	
	class API extends REST {
		public $data = "";
		
		const DB_SERVER = "localhost";
		const DB_USER = "cars_bid";
		const DB_PASSWORD ='uUw3zbis-s(N';
		const DB = "cars_bid";
		
		private $db = NULL;
	
		public function __construct(){
			parent::__construct();				// Init parent contructor
			$this->dbConnect();					// Initiate Database connection
		}
		
		/*
		 *  Database connection 
		*/
		private function dbConnect(){
			 $connection =  mysqli_connect("localhost", "cars_bid", "uUw3zbis-s(N","cars_bid");
			 return $connection;
			 // $mysql_hostname = "localhost";
// $mysql_user = "cars_bid";
// $mysql_password = "uUw3zbis-s(N";
// $mysql_database = "cars_bid";
// return mysqli_connect($mysql_hostname, $mysql_user, $mysql_password,$mysql_database) or die("Could not connect database");
		}
		
		/*
		 * Public method for access api.
		 * This method dynmically call the method based on the query string
		 *
		 */
		public function processApi(){
			$func = strtolower(trim(str_replace("/","",$_REQUEST['rquest'])));
			if((int)method_exists($this,$func) > 0)
				$this->$func();
			else
				$this->response('',404);				// If the method not exist with in this class, response would be "Page not found".
		}
				 
		private function login(){
     $con = $this->dbConnect();
	// Cross validation if the request method is POST else it will return "Not Acceptable" status
			 if($this->get_request_method() != "POST"){
				
				$error = array('status' => "Error", "msg" => "Invalid Method");
			    $this->response($this->json($error), 400);
			}
			
			 $username = $this->_request['username'];		
			 $password = $this->_request['password'];
			
			// // Input validations
			 if(!empty($password) and !empty($username)){
			 $qry = "SELECT * FROM ca_user WHERE email= '$username' AND password='$password' AND role='subscriber' AND user_approve='1'";
			 $result = $con->query($qry);
			$row_count=  $result->num_rows;
				if($row_count>0)
				{
					echo "ok";
				}					
	}
		}
		
		private function signup(){
     $con = $this->dbConnect();
	 
	// //Cross validation if the request method is POST else it will return "Not Acceptable" status
			 if($this->get_request_method() != "POST"){
				
				echo "please try again";
			}
			
			 $email = $this->_request['email'];		
			 $password = $_REQUEST['password'];
			 $pan = $this->_request['pan'];
			 $location = $this->_request['location'];
			   $mobile = $this->_request['mobile'];
			 $prefrences = $this->_request['prefrences'];
			 $user_id = "user_".uniqid(); 
			$user_approve = 0;
  $sql="SELECT * FROM ca_user WHERE email='$email'";
 $result = $con->query($sql);
			 $row_count=  $result->num_rows;
			 if($row_count>0)
			 {
				 echo "user exist";
			 }
			
			 else
			 {
				 $sql="INSERT INTO ca_user (role, email,password,pan_no,mobile_no,location,user_approve,user_main_id,prefrences) VALUES('subscriber','$email','$password','$pan','$mobile','$location','$user_approve','$user_id','$prefrences')";
				 $result = $con->query($sql);
				 echo "successfully  registered";
			 }
			// // Input validations

			
		}
		/***************** home screen **************************/
		private function home(){
     $con = $this->dbConnect();
	 date_default_timezone_set('Asia/Kolkata');
	// Cross validation if the request method is POST else it will return "Not Acceptable" status
			 // if($this->get_request_method() != "POST"){
				
				// $error = array('status' => "Error", "msg" => "Invalid Method");
			    // $this->response($this->json($error), 400);
			// }
			$rows = array();
	
		 $qry = "SELECT car_id,car_name,fuel_type,car_kms,car_model,registration,price,id,car_profile_img,auction_date,auction_duration,start_auction,auction_time,transmission as ac FROM ca_cars where start_auction='1' || start_auction='0'";
			 $result = $con->query($qry);
			 	 while ($row2 = $result->fetch_assoc()) {
					
		  $auction_date_time = $row2['auction_date'];
		  $start_auction = $row2['start_auction'];
		  
	   if(!empty($auction_date_time)){

		   if($start_auction==1)
		   {
	
	 $auction_duration = $row2['auction_duration'];
	  $car_id = $row2['car_id'];
	
 $auction_timestamp = strtotime('+'.$auction_duration .' hours', strtotime( $auction_date_time ));
	 // $auction_timestamp1 = strtotime($auction_date_time);
	 
	 $current_date = date('d-m-Y H:i:s');
	 $current_timestamp = strtotime($current_date);
	 $differenceInSeconds = $auction_timestamp - $current_timestamp; 
	 $minutes =  gmdate("H:i:s", $differenceInSeconds);
	 // $minutes1 = $differenceInSeconds / 60;
 // $minutes2 = round($minutes1);
// $minutes = strval($minutes2);
$time = array('time' => $minutes);
//print_r($time);
 $row13 = array_merge($row2,$time);
 $sql1= "select MAX(price_auction) as max_bid from car_auction where car_id = '$car_id'";
 $results = $con->query($sql1);
$max_bid = $results->fetch_object();
 $max_value = $max_bid->max_bid;
 $bid = array('max_bid' => $max_value);
 $row = array_merge($row13,$bid);
	 }	 
	elseif($start_auction==2)
	 
	 {
		 $time = array('time' => 'Auction completed');
		 
$row13 = array_merge($row2,$time);
 $sql1= "select MAX(price_auction) as max_bid from car_auction where car_id = '$car_id'";
 $results = $con->query($sql1);
$max_bid = $results->fetch_object();
 $max_value = $max_bid->max_bid;
 $bid = array('max_bid' => $max_value);
 $row = array_merge($row13,$bid);
	 }
	 
	 }
	else 
		 
		 {
			 $time = array('time' => 'Coming Soon','max_bid'=>"");
			 $row = array_merge($row2,$time);
		 }
     $rows[] = $row; 
	
	
 
				 }  
$pp['car']=$rows; 
 echo json_encode($pp);
			
		}
		
		/*********** profile  *******************/
		private function profile(){
     $con = $this->dbConnect();
	 date_default_timezone_set('Asia/Kolkata');
	//Cross validation if the request method is POST else it will return "Not Acceptable" status
			 if($this->get_request_method() != "POST"){
				
				$error = array('status' => "Error", "msg" => "Invalid Method");
			    $this->response($this->json($error), 400);
			}
			$email = $this->_request['email'];	
		 $sql = "select * from ca_user where email = '$email' AND role ='subscriber'";
		$result = $con->query($sql);
		$row['profile'][] = $result->fetch_assoc();
		echo json_encode($row);
		
		}
		
		/********* cuurent bid *********************/
		
		private function current_bid(){
     $con = $this->dbConnect();
	 date_default_timezone_set('Asia/Kolkata');
	// Cross validation if the request method is POST else it will return "Not Acceptable" status
			 // if($this->get_request_method() != "POST"){
				
				// $error = array('status' => "Error", "msg" => "Invalid Method");
			    // $this->response($this->json($error), 400);
			// }
			$email = $this->_request['email'];	
			$rows=array();
			 $sql = "select car_id from car_auction where user_id='$email'";
			
		 $result1 = $con->query($sql);
		
			while ($row1 = $result1->fetch_assoc()) {
  $id = $row1['car_id'];
	
		 $qry = "SELECT car_id,car_name,fuel_type,car_kms,car_model,transmission as ac,price,id,car_profile_img,auction_date,auction_duration FROM ca_cars where  car_id='$id' AND start_auction='1'";
			 $result = $con->query($qry);
			 	 while ($row2 = $result->fetch_assoc()) {
				$minutes="";	
		  $auction_date_time = $row2['auction_date'];
		  $car_id = $row2['car_id'];
	   if(!empty($auction_date_time)){
	
	 $auction_duration = $row2['auction_duration'];
	
 $auction_timestamp = strtotime('+'.$auction_duration .' hours', strtotime( $auction_date_time ));
	 // $auction_timestamp1 = strtotime($auction_date_time);
	 $current_date = date('d-m-Y H:i:s');
	 $current_timestamp = strtotime($current_date);
	 $differenceInSeconds = $auction_timestamp - $current_timestamp; 
	$minutes =  gmdate("H:i:s", $differenceInSeconds);
 $time = array('time'=> $minutes); 
 
 $row13 = array_merge($row2,$time);
 $sql1= "select MAX(price_auction) as max_bid from car_auction where car_id = '$car_id'";
 $results = $con->query($sql1);
$max_bid = $results->fetch_object();
 $max_value = $max_bid->max_bid;
 $bid = array('max_bid' => $max_value);
 $row = array_merge($row13,$bid);
	 }	 
					 
     $rows[] = $row; 
	
  }
			 
	 }
	
			
			
$pp['car']=$rows; 
 echo json_encode($pp);
			
		}
		
		/****************** lost_bid ***********************/
		
		private function user_bid(){
     $con = $this->dbConnect();
	 $email = $this->_request['email'];
	 echo "http://go4intern.com/cars/app/current_bid?email=".$email;
		}
	 /********* ************/
		private function lost_bid(){
     $con = $this->dbConnect();
	 date_default_timezone_set('Asia/Kolkata');
	// Cross validation if the request method is POST else it will return "Not Acceptable" status
			 // if($this->get_request_method() != "POST"){
				
				// $error = array('status' => "Error", "msg" => "Invalid Method");
			    // $this->response($this->json($error), 400);
			// }
			 $email = $this->_request['email'];	
			$rows=array();
			 $sql = "select car_id,price_auction from car_auction where user_id='$email' AND bid_status='lost'";	
		 $result1 = $con->query($sql);
		 
			while ($row1 = $result1->fetch_assoc()) {
			 $id = $row1['car_id'];
			 $bid_price = $row1['price_auction'];
	$bid =array("max_bid"=> $bid_price);
	
		 $qry = "SELECT car_name,fuel_type,car_kms,car_model,transmission as ac,price,id,car_profile_img,auction_date,auction_duration FROM ca_cars where  car_id='$id' AND start_auction='2'";
			 $result = $con->query($qry);
 $row2 = $result->fetch_assoc();
		
		$row= array_merge($row2,$bid);
		 $rows[] = $row;
		}
		$pp['car'] = $rows;
		echo json_encode($pp);
		}
 		/**************** edit profile *******************/
			private function edit_profile()
		{
     $con = $this->dbConnect();
	// Cross validation if the request method is POST else it will return "Not Acceptable" status
			 if($this->get_request_method() != "POST"){
				
				$error = array('status' => "Error", "msg" => "Invalid Method");
			    $this->response($this->json($error), 400);
			}
			 $username = $this->_request['email'];		
			 $location = $this->_request['location'];
			 // $prefrences = $this->_request['prefrences'];
			 $password = $this->_request['password'];
			 $pan = $this->_request['pan'];
			 $mobile = $this->_request['mobile'];
			
					 $sql = "UPDATE ca_user SET location = '$location',pan_no = '$pan',mobile_no = '$mobile' ,password = '$password' where email = '$username' AND role = 'subscriber'";
					 $result1 = $con->query($sql);
					 if($result1)
					 {
						 echo "update";
					 }
					 else 
					 {
						 echo "not";
					 }
				// $row = array("status" => 'updated');
					
		 
 // echo json_encode($row);
		}                                                                                                                                        			
			
			 
			 
			
		
		/*********************** win bid *****************/
		private function win_bid(){
     $con = $this->dbConnect();
	 date_default_timezone_set('Asia/Kolkata');
	// Cross validation if the request method is POST else it will return "Not Acceptable" status
			 // if($this->get_request_method() != "POST"){
				
				// $error = array('status' => "Error", "msg" => "Invalid Method");
			    // $this->response($this->json($error), 400);
			// }
			 $email = $this->_request['email'];	
			$rows=array();
			 $sql = "select car_id,price_auction from car_auction where user_id='$email' AND bid_status='win'";	
		 $result1 = $con->query($sql);
		 
			while ($row1 = $result1->fetch_assoc()) {
			 $id = $row1['car_id'];
			 $bid_price = $row1['price_auction'];
	$bid =array("max_bid"=> $bid_price);
	
$qry = "SELECT car_name,fuel_type,car_kms,car_model,transmission as ac,price,id,car_profile_img,auction_date,auction_duration FROM ca_cars where  car_id='$id' AND start_auction='2'";
			 $result = $con->query($qry);
 $row2 = $result->fetch_assoc();
		
		$row= array_merge($row2,$bid);
		 $rows[] = $row;
		}
		$pp['car'] = $rows;
		echo json_encode($pp);
		}
		/***************** car bidding ********************/
		
		private function single_car_info(){
     $con = $this->dbConnect();
	  date_default_timezone_set('Asia/Kolkata');
	// Cross validation if the request method is POST else it will return "Not Acceptable" status
			 // if($this->get_request_method() != "POST"){
				
				// $error = array('status' => "Error", "msg" => "Invalid Method");
			    // $this->response($this->json($error), 400);
			// }
			 $id = $this->_request['car_id'];	
			 //$id = 29;	
			$rows=array();
			 $qry = "select start_auction from ca_cars where id='$id'";
			 $result2 = $con->query($qry);
			$row2 = $result2->fetch_object();
			$start_auction = $row2->start_auction;
			if($start_auction==1)
			{
			 $sql = "SELECT car_id,car_name,fuel_type,car_kms,car_model,ac,price,id,car_profile_img,auction_date,auction_duration FROM ca_cars where  id='$id'";
			$result = $con->query($sql);
			$row = $result->fetch_assoc();
			  $auction_date_time = $row['auction_date'];
	 $auction_duration = $row['auction_duration'];
	 $price = $row['price'];
	 $car_id = $row['car_id'];
	
 $auction_timestamp = strtotime('+'.$auction_duration .' hours', strtotime( $auction_date_time ));
	 // $auction_timestamp1 = strtotime($auction_date_time);
	 $current_date = date('d-m-Y H:i:s');
	 $current_timestamp = strtotime($current_date);
	 $differenceInSeconds = $auction_timestamp - $current_timestamp; 
	 $minutes =  gmdate("H:i:s", $differenceInSeconds);
		$qry = "select MAX(price_auction) as max_bid from car_auction  where car_id = '$car_id'";
		$result12 = $con->query($qry);
		$row12 = $result12->fetch_object();
		$max_bid=$row12->max_bid;
		$time = array("time" => $minutes,"max_bid"=> $max_bid);
		$pp['car'][]= array_merge($row,$time);
		
		echo json_encode($pp);
 }
 else
 {
	 $pp['car'][]= array('status' => 'Auction not availble');
		
		echo json_encode($pp);
 }
		}
 private function car_bid(){
	 $con = $this->dbConnect();
 $id = $this->_request['car_id'];
 echo "http://go4intern.com/cars/app/single_car_info?car_id=".$id;
 }
 
/*************** genrate report ******************/
private function car_report(){
	 $con = $this->dbConnect();
 $id = $this->_request['car_id'];
$sql = "select report_url FROM ca_cars where  id='$id'";
		 $result1 = $con->query($sql);
		 $row = $result1->fetch_assoc();
		 echo  $row['report_url'];
		
}

		/********************* bid_price **********************************/
		private function bid_price()
		{
     $con = $this->dbConnect();
	// Cross validation if the request method is POST else it will return "Not Acceptable" status
			 if($this->get_request_method() != "POST"){
				
				$error = array('status' => "Error", "msg" => "Invalid Method");
			    $this->response($this->json($error), 400);
			}
			 $username = $this->_request['email'];		
		 $car_id = $this->_request['id'];
 $price = $this->_request['price'];
			 $sql1 ="SELECT car_id FROM ca_cars WHERE id = '$car_id'";
			  $result2 = $con->query($sql1);
			  $row2 = $result2->fetch_object();
			   $cars_id = $row2->car_id;

			 $qry = "SELECT * FROM car_auction WHERE user_id = '$username' AND car_id='$cars_id'";
			 $result = $con->query($qry);
			$row_count=  $result->num_rows;
				if($row_count>0)
				{
					 $sql = "UPDATE car_auction SET price_auction = '$price' where car_id = '$cars_id' AND user_id = '$username'";
					$result1 = $con->query($sql);
					
				 $row = array("status" => 'update');
				}	
else{
	$sql="INSERT INTO car_auction (car_id,user_id,price_auction) VALUES('$cars_id','$username','$price')";
				 $result1 = $con->query($sql);	
$row = array("status" => 'update');				 
}				
			
			 
			 
			 echo json_encode($row);
		}
		
		
		/************************** forgot password ***************/
				private function forgot_password(){
     $con = $this->dbConnect();
	// Cross validation if the request method is POST else it will return "Not Acceptable" status
			 if($this->get_request_method() != "POST"){
				
				$error = array('status' => "Error", "msg" => "Invalid Method");
			    $this->response($this->json($error), 400);
			}
			
			 $email =  $this->_request['email'];		
$sql = "select password FROM ca_user where  email='$email'";
		 $result1 = $con->query($sql);
		 $row = $result1->fetch_object();
		 $password = $row->password;
		 $subject = "Carsforu";
 $message = "please 
 
 
  using your password ".$password;
mail($email,$subject,$message);	
if(mail)
{
	echo "password sent to your registered email";
}	
else{
echo "please try again";
}
		}
		/*************** gallery image *******************/
		private function gallery_image(){
     $con = $this->dbConnect();
	// Cross validation if the request method is POST else it will return "Not Acceptable" status
			 // if($this->get_request_method() != "POST"){
				
				// $error = array('status' => "Error", "msg" => "Invalid Method");
			    // $this->response($this->json($error), 400);
			// }
			 $car_id =  $this->_request['car_id'];
			
			
			 // $qry = "SELECT car_gallery_image FROM ca_cars WHERE id='$car_id'";
			 // $result = $con->query($qry);
			 // $row = $result->fetch_object();
// $data = $row->car_gallery_image;
			 // $arr['image'] = explode(",",$data);
			
			// echo json_encode($arr);
			$car_image =  "http://go4intern.com/cars/cars4u/data/car_gallery.php?car_id=".$car_id;
$sql = "select report_url FROM ca_cars where  id='$car_id'";
		 $result1 = $con->query($sql);
		 $row = $result1->fetch_assoc();
		  $report =  $row['report_url'];
		  echo $url = $car_image .",". $report;
		}
		//For Check : //http://www.gaudiumivfcentre.com/app/ws/resend_otp?player_id=db1a9773-2ce7-4dfd-8db3-b14be8cd3c63&phone=9716510341
		
		
		
		// For Check : http://www.gaudiumivfcentre.com/app/ws/get_otp?player_id=db1a9773-2ce7-4dfd-8db3-b14be8cd3c63&phone=9716510341
		
		
		
 /* ============================== OTP SECTION END ===================================== */
 
		
		
		private function users(){	
			// Cross validation if the request method is GET else it will return "Not Acceptable" status
			if($this->get_request_method() != "GET"){
				$this->response('',406);
			}
			$sql = mysql_query("SELECT user_id, user_fullname, user_email FROM users WHERE user_status = 1", $this->db);
			if(mysql_num_rows($sql) > 0){
				$result = array();
				while($rlt = mysql_fetch_array($sql,MYSQL_ASSOC)){
					$result[] = $rlt;
				}
				// If success everythig is good send header as "OK" and return list of users in JSON format
				$this->response($this->json($result), 200);
			}
			$this->response('',204);	// If no records "No Content" status
		}
		
		private function register(){
			 
			if($this->get_request_method() != "PUT"){
			    $error = array('status' => "Error", "msg" => "Invalid Method");
			     $this->response($this->json($error), 400);
			}
			if(isset($this->_request['user_fullname']) and isset($this->_request['user_email']) and isset($this->_request['phone_no']) and isset($this->_request['player_id'])){
					$user_fullname = $this->_request['user_fullname'];		
					$user_email = $this->_request['user_email'];
					$phone_no = $this->_request['phone_no'];
					$player_id = $this->_request['player_id'];
					$user_passwd = $this->_request['user_passwd'];
					 
					$date = date('Y-m-d h:i:s');
			 }
			if(!empty($user_fullname) and !empty($user_email)and !empty($user_passwd) and !empty($phone_no)and !empty( $player_id)){
				if(filter_var($phone_no, FILTER_SANITIZE_NUMBER_INT)){
					$user_passwd   = md5($this->_request['user_passwd']);
					$user_fullname = filter_var($user_fullname, FILTER_SANITIZE_STRING);
					$phone_no = filter_var($phone_no, FILTER_SANITIZE_NUMBER_INT);
					
					  $checkusrexist = mysql_query("SELECT * FROM users where player_id='".$player_id."' and phone_no = '".$phone_no."' ", $this->db);
					 $usrcount=mysql_num_rows($checkusrexist);
					 
					if($usrcount==1){
						$row = mysql_fetch_object($checkusrexist);
					$sql = mysql_query("UPDATE users SET user_fullname = '$user_fullname',user_email = '$user_email',user_password = '$user_passwd', date = '$date' WHERE phone_no = '$phone_no' and player_id = '$player_id'");
					  $result = array('status' => "success","user_id"=> $row->user_id, "msg" => "You have registered successfully!");
						$this->response($this->json($result), 200);
				     }
					$error = array('status' => "error", "msg" => "Please Verify OTP first!");
					$this->response($this->json($error), 400);
				}
			}
			 $error = array('status' => "error", "msg" => "Missing data(Required: user_fullname, user_email, user_passwd, phone_no,player_id.)");
			$this->response($this->json($error), 400);
		}
		
			
		 	private function review_new(){
			 
			if($this->get_request_method() != "PUT"){
			    $error = array('status' => "error", "msg" => "Invalid Method");
			     $this->response($this->json($error), 400);
			}
			if(isset($this->_request['uid']) and isset($this->_request['doctor']) and isset($this->_request['staff']) and isset($this->_request['waiting_time'])and isset($this->_request['environment']) and isset($this->_request['facilities']) and isset($this->_request['suggestion'])){
					$uid = $this->_request['uid'];		
					$doctor = $this->_request['doctor'];		
					$staff = $this->_request['staff'];
					$waiting_time = $this->_request['waiting_time'];
					$environment = $this->_request['environment'];
					$facilities = $this->_request['facilities'];
					$suggestion = $this->_request['suggestion'];
					$date = date('Y-m-d h:i:s');
					 
			}
			if(!empty($uid) and !empty($doctor) and !empty($staff)and !empty($waiting_time) and !empty($environment) and !empty($facilities) and !empty($suggestion)){
				 
				 $sql = mysql_query("INSERT into review  SET uid = '$uid', doctor = '$doctor',staff = '$staff',waiting_time = '$waiting_time',environment = '$environment',facilities = '$facilities',suggestion = '$suggestion',date = '$date' ");
					 $id=mysql_insert_id();
					if($sql){
						$result = array('status' => "success","review_id"=> $id, "msg" => "Review saved successfully!");
						$this->response($this->json($result), 200);
					}
					$error = array('status' => "error", "msg" => "Some problem occurs!");
					$this->response($this->json($error), 400);
				 
			}
			 $error = array('status' => "error", "msg" => "Missing data(Required: doctor, staff, waiting_time, environment,. facilities,suggestions rating.)");
			$this->response($this->json($error), 400);
		}
		
		
		// For Check : http://www.gaudiumivfcentre.com/app/ws/consult_new?user_id=19&name=Nitin&phone=9716510341&comment=This is testing
		private function consult_new(){
			 
			if($this->get_request_method() != "PUT"){
			    $error = array('status' => "Error", "msg" => "Invalid Method");
			     $this->response($this->json($error), 400);
			}
			if(isset($this->_request['user_id']) and isset($this->_request['name']) and isset($this->_request['phone']) and isset($this->_request['comment'])){
					$user_id = $this->_request['user_id'];		
					$name = $this->_request['name'];
					$phone = $this->_request['phone'];
					$comment = $this->_request['comment'];
					$date = date('Y-m-d h:i:s');
					
					 
					if (65525 < mb_strlen( $comment, '8bit' )) { 
						 $error = array('status' => "error", "msg" => "Query text too large!");
						 $this->response($this->json($error), 413);
					}
					 
					
			}
			if(!empty($user_id) and !empty($name)and !empty($phone)and !empty($comment)){
				if(filter_var($phone, FILTER_SANITIZE_NUMBER_INT)){
					 $phone = filter_var($phone, FILTER_SANITIZE_NUMBER_INT);
					$user_id = filter_var($user_id, FILTER_SANITIZE_NUMBER_INT);
					$name = filter_var($name, FILTER_SANITIZE_STRING);
					$name = preg_replace("/[^A-Za-z]/",'',$name);
					$sql = mysql_query("INSERT into consultations  SET user_id = '$user_id',name = '$name',phone = '$phone',comment = '$comment',date = '$date' ");
					 $id=mysql_insert_id();
					if($sql){
						$result = array('status' => "success","consult_id"=> $id, "msg" => "Consult saved successfully!");
						$this->response($this->json($result), 200);
					}
					$error = array('status' => "error", "msg" => "Some problem occurs!");
					$this->response($this->json($error), 400);
				}
			}
			 $error = array('status' => "error", "msg" => "Missing data(Required: userid, Phone, name, query. )");
			$this->response($this->json($error), 400);
		}
		
		
		private function appointment_new(){
			 
			if($this->get_request_method() != "PUT"){
			    $error = array('status' => "Error", "msg" => "Invalid Method");
			     $this->response($this->json($error), 400);
			}
			if(isset($this->_request['user_id']) and isset($this->_request['name']) and isset($this->_request['phone']) and isset($this->_request['comment']) and isset($this->_request['ap_date'])){
					$user_id = $this->_request['user_id'];		
					$name = $this->_request['name'];
					$phone = $this->_request['phone'];
					$comment = $this->_request['comment'];
					$ap_date = $this->_request['ap_date'];
					$date = date('Y-m-d h:i:s');
					
					 
					if (65525 < mb_strlen( $comment, '8bit' )) { 
						 $error = array('status' => "error", "msg" => "Query text too large!");
						 $this->response($this->json($error), 413);
					}
					 
					
			}
			
			if(!empty($user_id) and !empty($name) and !empty($phone) and !empty($comment) and !empty($ap_date)){
				
				if(filter_var($phone, FILTER_SANITIZE_NUMBER_INT)){
					 $phone = filter_var($phone, FILTER_SANITIZE_NUMBER_INT);
					$user_id = filter_var($user_id, FILTER_SANITIZE_NUMBER_INT);
					$name = filter_var($name, FILTER_SANITIZE_STRING);
					$name = preg_replace("/[^A-Za-z]/",'',$name);
					$ap_date = filter_var($ap_date, FILTER_SANITIZE_STRING);
					
					$sql = mysql_query("INSERT into appointments  SET user_id = '$user_id',name = '$name',phone = '$phone',comment = '$comment',ap_date = '$ap_date',date = '$date' ");
					 $id=mysql_insert_id();
					if($sql){
						$result = array('status' => "success","ap_id"=> $id, "msg" => "Appointment saved successfully!");
						$this->response($this->json($result), 200);
					}
					$error = array('status' => "error", "msg" => "Some problem occurs!");
					$this->response($this->json($error), 400);
				}
			}
			 $error = array('status' => "error", "msg" => "Missing data(Required: userid, Phone, name, query. )");
			$this->response($this->json($error), 400);
		}
		
		
		private function contact(){
			// Cross validation if the request method is GET else it will return "Not Acceptable" status
			if($this->get_request_method() != "GET"){
				$this->response('',406);
			}
			
			$branch['Head Branch'][] = array(
				'center' => 'Head Branch',
				'Address' => 'A-41, Chander Nagar Janakpuri West (Near Janakpuri West Metro Station) New Delhi - 110 058 (India)',
				'Founder and CEO' => 'Dr Manika Khanna, M.B.B.S., M.D., D.A.G.E. (Germany)',
				'Centre Incharge' => array('Dr Ambika Vaid, M.B.B.S., M.D. (Gynaecology)', 'Dr Deepali Kaushik, B.A.M.S (Gynaecology)'),
				'Contact Numbers' => array('+91-11-69418485','+91-11-43528485','+91-11-84854359','+91-8527858585','+91-9899953963','+91-9810739199'),
				'lat' => '28.6273078',
				'long' => '77.0756307',
			);
			 
			$branch['Centres in India'][] = array(
				'center' => 'South Delhi Centre',
				'Address' => 'R - 21, Greater Kailash, New Delhi - 110 048.',
				'Centre Incharge' => array('Dr Meeta Airen (MBBS, DNB, MNAMS)'),
				'Contact Numbers' => array('+91-11-26418585'),
				'lat' => '28.544764',
				'long' => '77.2444519',
			);	
			
			$branch['Centres in India'][] = array(
				'center' => 'Ludhiana, Punjab Centre',
				'Address' => 'Gaudium Bawa IVF Centre, Bawa Hospital Near Old Dandi Swami Mandir, Civil Lines, Ludhiana, Punjab – 141001',
				'Centre Incharge' => array('Dr Sayesha Bawa (MBBS, MD)'),
				'Contact Numbers' => array('+91-8527858585'),
				'lat' => '30.916285',
				'long' => '75.834092',
			);
			
			$branch['Centres in India'][] = array(
				'center' => 'Srinagar Centre',
				'Address' => 'Gaudium IVF Centre, Ramzana Hospital Gogji Bagh Jawahar Nagar Srinagar, J&K 190008.',
				'Centre Incharge' => array('Dr Asmat Khandey (MBBS, DGO (Obstt & Gynae))'),
				'Contact Numbers' => array('+91-8527858585'),
				'lat' => '34.0611273',
				'long' => '74.809447',
			);
			
			$branch['Centres in India'][] = array(
				'center' => 'Yamunanagar Centre',
				'Address' => 'Gaudium Gaba IVF Centre Yamuna Nagar Haryana - 135001',
				'Centre Incharge' => array('Dr Geetinder Kaur Gaba (MBBS, MS (Obstt & Gynae))'),
				'Contact Numbers' => array('+91-8527858585'),
				'lat' => '30.1290485',
				'long' => '77.2673901',
			);	 
			 
			$branch['Centres in India'][] = array(
				'center' => 'Jammu Centre',
				'Address' => 'Gaudium Greencourt IVF Centre, Exchange Rd Ambphalla, Old Heritage City, Jammu, Jammu and Kashmir 180001.',
				'Centre Incharge' => array('Dr Sapna Khullar (DGO, MD)'),
				'Contact Numbers' => array('+91-11-8527858585'),
				'lat' => '32.7411909',
				'long' => '75.834092',
			);	 
			 
			$branch['Centres in India'][] = array(
				'center' => 'Patna Centre',
				'Address' => 'Gaudium Kare IVF, MP Sinha Road, Kadam Kuan, Patna – 800 003.',
				'Centre Incharge' => array('Dr Vinita Singh (MBBS, MD)'),
				'Contact Numbers' => array('+91-11-8527858585'),
				'lat' => '25.6108123',
				'long' => '85.1504038',
			);
			
			$branch['International Centres'][] = array(
				'center' => 'Nigeria Centre',
				'Address' => 'No. 88 A, Upper New Market Road, Kamo Plaza Qnitsha, Anambra, Nigeria',
				'Centre Incharge' => array('Ms Umeh Vivian'),
				'Contact Numbers' => array('+234 8033410868'),
				'lat' => '6.1528633',
				'long' => '6.7880883',
			);	 
			 
			$branch['International Centres'][] = array(
				'center' => 'Afghanistan Centre',
				'Address' => 'Mirwais Market Office # 26, Sardar Mad Khan Chowk, Kandahar, Afghanistan',
				'Centre Incharge' => array('Mr Hameed Khan'),
				'Contact Numbers' => array('0093-700307108', '0093-700330729', '0093-795398000', '0093-302005623'),
				'lat' => '31.628871',
				'long' => '65.7371749',
			);	 
			  
			$branch['International Centres'][] = array(
				'center' => 'Canada Centre',
				'Address' => '581 Matisee Place, Mississauga, ON L5W 1M3',
				'Centre Incharge' => array('Ms Smita'),
				'Contact Numbers' => array('+1-647-273-2193'),
				'lat' => '43.6411868',
				'long' => '-79.7271401',
			);	 
			   
			$branch['International Centres'][] = array(
				'center' => 'Nepal Centre',
				'Address' => 'Gaudium Norvic IVF Centre, P.O.Box:14126, Thapathali, Kathmandu, Nepal.',
				'Centre Incharge' => array('Dr Kumkum Jha, MBBS, MD (Consultant Gynaecologist)'),
				'Contact Numbers' => array('977-1-4258554', '977-1-4218230'),
				'lat' => '27.6894055',
				'long' => '85.3226683',
			);	 
			 
			/* echo "<pre>";print_r($branch);echo "</pre>"; die; */
			$this->response($this->json($branch), 200);
			 
		}
		
		private function deleteUser(){
			// Cross validation if the request method is DELETE else it will return "Not Acceptable" status
			if($this->get_request_method() != "DELETE"){
				$this->response('',406);
			}
			$id = (int)$this->_request['id'];
			if($id > 0){
				mysql_query("DELETE FROM `users` WHERE `user_id` = $id");
				$success = array('status' => 'success', 'msg' => 'User deleted successfully.');
				$this->response($this->json($success),200);
			}
			else{
				$this->response('',204);	/*  If no records "No Content" status */
			}
		}
		
	 // For Check : http://www.gaudiumivfcentre.com/app/ws/reviews?uid=16	
	 private function reviews(){	
		
		  if($this->get_request_method() != "POST"){
				  $error = array('status' => "Error", "msg" => "Invalid Method");
			      $this->response($this->json($error), 400);
			} 
			$result = array();
			
			$uid=$_REQUEST['uid']; 
			
			 if(empty($uid)){
				 $error = array('status' => "error", "msg" => "Missing data(Required: uid )");
			     $this->response($this->json($error), 400);
			 
			}
			$uid_check = mysql_query("SELECT * FROM review where uid='".$uid."' ", $this->db);
			$uidcount=mysql_num_rows($uid_check);
			
			if($uidcount>0){
				$result['exist'] = array('status' => 'success', 'exist' => 1);
				$usr = mysql_query("SELECT * FROM users where user_id='".$uid."' ", $this->db);
				$row=mysql_fetch_object($usr);
				$name = $row->user_fullname;
			 
				$topuid = mysql_fetch_object($uid_check);
				$result['review'][] = array("rid"=>$topuid->rid,"uid"=>$topuid->uid,"name"=>$name,"doctor"=>$topuid->doctor,"staff"=>$topuid->staff,"waiting_time"=>$topuid->waiting_time,"environment"=>$topuid->environment,"facilities"=>$topuid->facilities,"suggestion"=>$topuid->suggestion,"date"=>$topuid->date);
				}
				else{
					$result['exist'] = array('status' => 'success', 'exist' => 0);	
				}
			 $sql = mysql_query("SELECT  * FROM review WHERE uid NOT IN ($uid) order by date DESC", $this->db);
			 if(mysql_num_rows($sql) > 0){
				 while($rlt = mysql_fetch_object($sql)){
					  $usrs = mysql_query("SELECT * FROM users where user_id='".$rlt->uid."' ", $this->db);
					 $rows=mysql_fetch_object($usrs);
					 $name = $rows->user_fullname;
					 
					$result['review'][] = array("rid"=>$rlt->rid,"uid"=>$rlt->uid,"name"=>$name,"doctor"=>$rlt->doctor,"staff"=>$rlt->staff,"waiting_time"=>$rlt->waiting_time,"environment"=>$rlt->environment,"facilities"=>$rlt->facilities,"suggestion"=>$rlt->suggestion,"date"=>$rlt->date);
                }
				$this->response($this->json($result), 200);
			}
			$this->response($this->json($result),200);	// If no records "No Content" status
	 }
	 
		// For Check : http://www.gaudiumivfcentre.com/app/ws/consultations?user_id=19
		private function consultations(){
		
		   if($this->get_request_method() != "POST"){
				  $error = array('status' => "Error", "msg" => "Invalid Method");
			      $this->response($this->json($error), 400);
			} 
			$result = array();
			$user_id=$_REQUEST['user_id']; 
			
			  if(empty($user_id))
			  {
				 $error = array('status' => "error", "msg" => "Missing data(Required: Consult ID )");
			     $this->response($this->json($error), 400);
			  }
			  
				$cid_check = mysql_query("SELECT * FROM consultations where user_id='".$user_id."' ", $this->db);
				$cidcount=mysql_num_rows($cid_check);
				if($cidcount>0){
					$result = array();
					$topuid = mysql_fetch_object($cid_check);
					 if(strlen($topuid->reply)){
						 $reply =$topuid->reply;
					 } else {
						$reply ="Not Replied";
					 }
					$result['count']=$cidcount; 
					$rows = mysql_query("SELECT * FROM consultations where user_id='".$user_id."' ORDER BY cid DESC ", $this->db);
					//while($rlt = mysql_fetch_array($cid_check,MYSQL_ASSOC)){
					while($rlt = mysql_fetch_array($rows,MYSQL_ASSOC)){
				  		$result['consultations'][] = $rlt;
					}  
					$this->response($this->json($result), 200); 
				 }
				 $result['count']=0; 
				 $result['consultations'][]= array("user_id"=>$user_id);
			     $this->response($this->json($result),200);	 
		} 
		
		// For Check : http://www.gaudiumivfcentre.com/app/ws/notifications?user_id=16
		 private function notifications(){	
		 
		      if($this->get_request_method() != "POST"){
				  $error = array('status' => "Error", "msg" => "Invalid Method");
			      $this->response($this->json($error), 400);
				}   
				$result = array();
				$user_id=$_REQUEST['user_id']; 
				
				if(empty($user_id)){
				 $error = array('status' => "error", "msg" => "Missing data(Required: ID )");
			     $this->response($this->json($error), 400);
				} 
				
			 // Get and count all the notifications as per user id.
			 $allNotifications = mysql_query("SELECT count(*) FROM notifications where user_id='".$user_id."' ", $this->db); // ok
			 if($allNotifications > 0){
				
				//$alltype = mysql_query("SELECT type FROM notifications where user_id='".$user_id."' ", $this->db); // ok
				
				
				
				$consult = mysql_query("SELECT * FROM notifications AS n, consultations AS c WHERE n.type_id = c.cid AND c.reply<>' ' AND n.user_id='".$user_id."' ORDER BY n.notification_date DESC",$this->db);
				$appointment = mysql_query("SELECT * FROM notifications AS n, appointments AS a WHERE n.type_id = a.eid AND a.reply<>' ' AND n.user_id='".$user_id."' ORDER BY n.notification_date DESC",$this->db);
				
				while($row_app = mysql_fetch_array($appointment,MYSQL_ASSOC)){
					array_push($result, $row_app);
	
				}
				while($row = mysql_fetch_array($consult_result,MYSQL_ASSOC))
				{
					array_push($result, $row);
					if($row['type'] == 'consult') {
						$date = $row['date'];
					}
					if($row['type'] == 'appointment') {
								$date = $row['ap_date'];
							}
					
					$result['notifications'][] = array("nid"=>$row['nid'],"name"=>$row['name'],"phone"=>$row['phone'],"reply"=>$row['reply'],"notification_date"=>$row['notification_date'],"date"=>$date,"status"=>$row['status'],"type"=>$row['type']);
					
				}
				/*
			while($row = mysql_fetch_array($consult))
					{
						
						if($row['type'] == 'consult') {
							$date = $row['date'];
						}
						
						$result['notifications'][] = array("nid"=>$row['nid'],"name"=>$row['name'],"phone"=>$row['phone'],"reply"=>$row['reply'],"notification_date"=>$row['notification_date'],"date"=>$date,"status"=>$row['status'],"type"=>$row['type']);
						
					}
				while($row = mysql_fetch_array($appointment))
						{
							
							if($row['type'] == 'appointment') {
										$date = $row['ap_date'];
									}
							
							$result['notifications'][] = array("nid"=>$row['nid'],"name"=>$row['name'],"phone"=>$row['phone'],"reply"=>$row['reply'],"notification_date"=>$row['notification_date'],"date"=>$date,"status"=>$row['status'],"type"=>$row['type']);
							
						}*/
				   			 
			   $this->response($this->json($result), 200); 							 
			} 
				  $result['notifications'][]= array("user_id"=>$user_id,'msg'=>'no records found');
			      $this->response($this->json($result),200);	 
		}       
		
		private function availability(){	
		 
			if($this->get_request_method() == "POST"){
			 
			if(isset($this->_request['year']) and isset($this->_request['month'])){
				$cyear=$this->_request['year'];
				$cmon=$this->_request['month'];
			}
		   }
		   if($this->get_request_method() == "GET"){
				$cyear=date('Y');
			    $cmon=date('m');
			 }
		     $result = array();
			  
			 $result['Year']=$cyear;
			 $result['Month']=$cmon;
			$sql = mysql_query("SELECT  * FROM availability where YEAR(available_date) = $cyear AND MONTH(available_date) = $cmon and availablity=0", $this->db);
			
			if(mysql_num_rows($sql) > 0){
				
				while($rlt = mysql_fetch_array($sql,MYSQL_ASSOC)){
					$date=explode('-',$rlt['available_date']);
					$result['days'][] = $date[2];
					
				 }
				 $result['count'][] = mysql_num_rows($sql);
				$this->response($this->json($result), 200);
			}
			 
			   
			$nocontent=array('status' => "success", "msg" => "No Records found.","count" => 0);
			$this->response($this->json($nocontent),200);	// If no records "No Content" status
		}
		/*
		 *	Encode array into JSON
		*/
		private function json($data){
			if(is_array($data)){
				return json_encode($data);
			}
		}
	}
	
	$api = new API;
	$api->processApi();
?>