<?php
 // $connection =  mysqli_connect("localhost", "cars_bid", "uUw3zbis-s(N","cars_bid");
 // return $connection;
 // echo $id = $_REQUEST['car_id'];
 // $qry = "SELECT car_gallery_image FROM ca_cars WHERE id='$id'";
			 // $result = $connection->query($qry);
			 // $row = $result->fetch_object();
// $data = $row->car_gallery_image;
			 // $arr['image'] = explode(",",$data);
			 // print_r($arr);
			 echo "ejejk";
?>