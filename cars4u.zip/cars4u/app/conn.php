<?php
$con = mysqli_connect('localhost','cars_bid','uUw3zbis-s(N','cars_bid') or die(mysqli_error('Error establishing database connection'));
			if($con == TRUE)
			{
				
			}
			else{
				
			}
?>