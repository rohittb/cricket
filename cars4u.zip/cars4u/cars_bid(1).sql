-- phpMyAdmin SQL Dump
-- version 4.0.10.18
-- https://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Oct 23, 2017 at 05:48 AM
-- Server version: 5.6.35-cll-lve
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cars_bid`
--

-- --------------------------------------------------------

--
-- Table structure for table `car_auction`
--

CREATE TABLE IF NOT EXISTS `car_auction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `car_id` varchar(50) NOT NULL,
  `price_auction` int(11) NOT NULL,
  `bid_status` varchar(10) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=91 ;

--
-- Dumping data for table `car_auction`
--

INSERT INTO `car_auction` (`id`, `user_id`, `car_id`, `price_auction`, `bid_status`, `timestamp`) VALUES
(66, 'choudharyyogesh15@gmail.com', 'car_59ca1b5949d25', 280000, NULL, '2017-09-26 09:22:47'),
(90, 'admin@admin.com', 'car_59de1ed4ba29f', 462000, 'win', '2017-10-23 11:03:56'),
(87, 'choudharyyogesh15@gmail.com', 'car_59de1ed4ba29f', 440000, 'lost', '2017-10-23 11:03:56'),
(88, 'nishant@gmail.com', 'car_59de1ed4ba29f', 442000, 'lost', '2017-10-23 11:03:56'),
(61, 'atul@gmail.com', 'car_59c4d9bd90a7f', 81000, 'lost', '2017-09-22 11:06:50'),
(60, 'admin@admin.com', 'car_59c4d9bd90a7f', 73000, 'lost', '2017-09-22 11:06:50'),
(59, 'choudharyyogesh15@gmail.com', 'car_59c4d9bd90a7f', 87000, 'win', '2017-09-22 11:06:50'),
(89, 'prince@gmail.com', 'car_59de1ed4ba29f', 402000, 'lost', '2017-10-23 11:03:56');

-- --------------------------------------------------------

--
-- Table structure for table `ca_cars`
--

CREATE TABLE IF NOT EXISTS `ca_cars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `car_name` varchar(255) NOT NULL,
  `car_kms` varchar(255) NOT NULL,
  `registration` varchar(255) NOT NULL,
  `car_model_year` varchar(255) NOT NULL,
  `car_id` varchar(255) NOT NULL,
  `car_profile_img` varchar(255) NOT NULL,
  `car_gallery_image` longtext NOT NULL,
  `price` varchar(255) NOT NULL,
  `start_auction` varchar(255) NOT NULL,
  `auction_date` varchar(255) NOT NULL,
  `auction_duration` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `second_key` varchar(255) NOT NULL,
  `insurance` varchar(255) NOT NULL,
  `owner_serial` varchar(255) NOT NULL,
  `fuel_type` varchar(255) NOT NULL,
  `wheel_cover` varchar(255) NOT NULL,
  `music_player` varchar(255) NOT NULL,
  `tool_kit` varchar(255) NOT NULL,
  `jack` varchar(255) NOT NULL,
  `sun_roof` varchar(255) NOT NULL,
  `fog_lamp` varchar(255) NOT NULL,
  `seat_covers` varchar(255) NOT NULL,
  `noises` varchar(255) NOT NULL,
  `fuel` varchar(255) NOT NULL,
  `temprature` varchar(255) NOT NULL,
  `dashboard_warning_light` varchar(255) NOT NULL,
  `headlight` varchar(255) NOT NULL,
  `break_light` varchar(255) NOT NULL,
  `parking_light` varchar(255) NOT NULL,
  `turn_signals` varchar(255) NOT NULL,
  `hazzard_light` varchar(255) NOT NULL,
  `windshield_wipers` varchar(255) NOT NULL,
  `fans_defosters` varchar(255) NOT NULL,
  `brakes` varchar(255) NOT NULL,
  `parking_brakes` varchar(255) NOT NULL,
  `mirrors` varchar(255) NOT NULL,
  `horn` varchar(255) NOT NULL,
  `exhaust_system` varchar(255) NOT NULL,
  `suspension` varchar(255) NOT NULL,
  `steering` varchar(255) NOT NULL,
  `steering_cntrls` varchar(255) NOT NULL,
  `proper_inflation` varchar(255) NOT NULL,
  `adequate` varchar(255) NOT NULL,
  `spare_inflated` varchar(255) NOT NULL,
  `oil` varchar(255) NOT NULL,
  `other_leaks` varchar(255) NOT NULL,
  `first_aid_kit` varchar(255) NOT NULL,
  `seat_belts` varchar(255) NOT NULL,
  `airbag` varchar(255) NOT NULL,
  `absbreak` varchar(255) NOT NULL,
  `ac` varchar(255) NOT NULL,
  `boonet` varchar(255) NOT NULL,
  `right_fander` varchar(255) NOT NULL,
  `left_fander` varchar(255) NOT NULL,
  `front_right_window` varchar(255) NOT NULL,
  `front_left_window` varchar(255) NOT NULL,
  `rear_right_window` varchar(255) NOT NULL,
  `rear_left_window` varchar(255) NOT NULL,
  `right_quarter_panel` varchar(255) NOT NULL,
  `left_quarter_panel` varchar(255) NOT NULL,
  `roof` varchar(255) NOT NULL,
  `boot` varchar(255) NOT NULL,
  `front_bumper` varchar(255) NOT NULL,
  `rear_bumper` varchar(255) NOT NULL,
  `ext_comment` varchar(255) NOT NULL,
  `int_dashboard` varchar(255) NOT NULL,
  `int_steeering` varchar(255) NOT NULL,
  `gear_console` varchar(255) NOT NULL,
  `hand_break` varchar(255) NOT NULL,
  `seats` varchar(255) NOT NULL,
  `int_comments` int(255) NOT NULL,
  `folowing_inception_condition` varchar(255) NOT NULL,
  `signature_image_url` varchar(255) NOT NULL,
  `car_model` varchar(255) NOT NULL,
  `ac_cond` varchar(20) NOT NULL,
  `report_url` varchar(100) NOT NULL,
  `rating` varchar(20) NOT NULL,
  `transmission` varchar(50) NOT NULL,
  `alloy_wheel` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=88 ;

--
-- Dumping data for table `ca_cars`
--

INSERT INTO `ca_cars` (`id`, `car_name`, `car_kms`, `registration`, `car_model_year`, `car_id`, `car_profile_img`, `car_gallery_image`, `price`, `start_auction`, `auction_date`, `auction_duration`, `color`, `second_key`, `insurance`, `owner_serial`, `fuel_type`, `wheel_cover`, `music_player`, `tool_kit`, `jack`, `sun_roof`, `fog_lamp`, `seat_covers`, `noises`, `fuel`, `temprature`, `dashboard_warning_light`, `headlight`, `break_light`, `parking_light`, `turn_signals`, `hazzard_light`, `windshield_wipers`, `fans_defosters`, `brakes`, `parking_brakes`, `mirrors`, `horn`, `exhaust_system`, `suspension`, `steering`, `steering_cntrls`, `proper_inflation`, `adequate`, `spare_inflated`, `oil`, `other_leaks`, `first_aid_kit`, `seat_belts`, `airbag`, `absbreak`, `ac`, `boonet`, `right_fander`, `left_fander`, `front_right_window`, `front_left_window`, `rear_right_window`, `rear_left_window`, `right_quarter_panel`, `left_quarter_panel`, `roof`, `boot`, `front_bumper`, `rear_bumper`, `ext_comment`, `int_dashboard`, `int_steeering`, `gear_console`, `hand_break`, `seats`, `int_comments`, `folowing_inception_condition`, `signature_image_url`, `car_model`, `ac_cond`, `report_url`, `rating`, `transmission`, `alloy_wheel`) VALUES
(85, 'Hyundai', '75000', 'HR72B8378', '2014', 'car_59de1ed4ba29f', 'http://go4intern.com/cars/cars4u/data/images/59de1ed4ba782untitled.png', 'http://go4intern.com/cars/cars4u/data/images/59de1ed4ba2ebuntitled.png,', '400000', '2', '11-10-2017 19:26:08', '1', '', 'Yes', 'YES', '1st', 'Diesel', 'yes', 'yes', 'yes', 'yes', 'no', 'yes', 'yes', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', '60%', '60%', '20%', 'ok', 'ok', 'ok', 'ok', 'no', 'ok', 'manual', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 0, 'acceptable', '', 'Grand i 10 Magna', 'ok', 'http://go4intern.com/cars/cars4u/data/reports/car_59de1ed4ba29f.html', '4.5', 'Manual', ''),
(87, 'AU', '0', '0', '0', '  car_59edcdaaccc60  ', '  http://go4intern.com/cars/cars4u/data/images/59edcdaaccdc1images.jpg', '  http://go4intern.com/cars/cars4u/data/images/59edcdaaccca259e0592cbb1e5index1.png,http://go4intern.com/cars/cars4u/data/images/59edcdaaccd48index1.png,', '000000000000000000000000000000000', '0', '', '', '0', '0', '0  ', '0', 'Cng & Petrol', 'yes', 'yes ', 'yes', 'yes', 'yes ', 'yes', 'yes', 'ok', 'ok ', 'ok ', 'ok', 'ok', 'ok', 'ok', 'ok', '', 'ok', 'ok', 'ok ', '', 'ok', 'ok ', 'ok', 'ok', 'ok', 'ok ', '80%', '20', '20% ', 'ok', 'ok', 'ok', 'ok', 'yes', 'Yes ', 'automatic', 'original', 'original', 'original', 'original', 'original ', 'original ', 'original', 'original', 'original ', 'original', 'original', '0', '0', '0  ', 'ok ', 'ok ', 'ok', 'ok', 'ok', 0, 'acceptable', 'http://go4intern.com/cars/cars4u/data/images/59edcdaacce63images.png  ', '0', 'ok', 'http://go4intern.com/cars/cars4u/data/reports/59edcfa86e16f.html ', '5', 'automatic', 'Yes ');

-- --------------------------------------------------------

--
-- Table structure for table `ca_user`
--

CREATE TABLE IF NOT EXISTS `ca_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `pan_no` varchar(255) NOT NULL,
  `mobile_no` varchar(11) NOT NULL,
  `location` varchar(255) NOT NULL,
  `prefrences` varchar(255) NOT NULL,
  `user_main_id` varchar(255) NOT NULL,
  `profile_image` varchar(255) NOT NULL,
  `user_approve` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `ca_user`
--

INSERT INTO `ca_user` (`user_id`, `role`, `email`, `password`, `pan_no`, `mobile_no`, `location`, `prefrences`, `user_main_id`, `profile_image`, `user_approve`) VALUES
(1, 'admin', 'admin@admin.com', 'admin123', 'bam12345678', '123456789', 'delhi', 'd7TtTBSYY4Y:APA91bF_SUMPhROoQaS5kVNF4ZdbMOZqx-wDo1M0qWYeItIXJxcU94mruhP7GwN2ydtDfcEIPLHWHrd2JwkJ_HiC0Uyczm56O6XaRdA4nauLXFryJ8BqF4bW3CWCNZPsL0yVIK3koEsU', '', '', '1'),
(4, 'subscriber', 'admin@admin.com', 'admin123', 'ABXCDN1234f', '4947864058', 'gurum', 'd7TtTBSYY4Y:APA91bF_SUMPhROoQaS5kVNF4ZdbMOZqx-wDo1M0qWYeItIXJxcU94mruhP7GwN2ydtDfcEIPLHWHrd2JwkJ_HiC0Uyczm56O6XaRdA4nauLXFryJ8BqF4bW3CWCNZPsL0yVIK3koEsU', '', '', '1'),
(9, 'subscriber', 'deepan@gmail.com', 'samsunghtc', '', '2147483647', 'gurgaon', 'd7TtTBSYY4Y:APA91bF_SUMPhROoQaS5kVNF4ZdbMOZqx-wDo1M0qWYeItIXJxcU94mruhP7GwN2ydtDfcEIPLHWHrd2JwkJ_HiC0Uyczm56O6XaRdA4nauLXFryJ8BqF4bW3CWCNZPsL0yVIK3koEsU', 'user_59b65715b5d48', '', '1'),
(14, 'subscriber', 'dr@gmail.com', 'samsunghtc', '', '9999999999', 'gurgaon', '', 'user_59ba667551b72', '', '1'),
(23, 'subscriber', 'atul@gmail.com', 'samsunghtc', '', '9999955555', 'Gurugram', 'fuWHzE2Z1R0:APA91bHzZCgenJXDOU6bekDeX1MONpjXkNYwgPELYGo4JQ322-Fd8ttL7Np534BTsLedzp3sXM8PWpomYDQ70J9vgVZCP4HsBvMqRGHMM6h_YPs9-tMI6pnIOncnd5WWTF-YMQYilkIo', 'user_59c1ebc39c532', '', '1'),
(25, 'subscriber', 'sanjeev@test.com', 'hello1234', 'yoboyqwer', '3564949494', 'Warangal', 'cEBvifwlHCE:APA91bHdoTpbwI0ARTTmsLydgUBTZmYFjw2QaYFi_OLj0wcySlf7OIWGmYAhXldiNynI4wgTQEVE6Veh4cYM244Cba_4_nwgQQwS7vz2o8HhcRrvZr6BjJfWK1zN4Ksr5J32uytvyPMK', 'user_59c8a6872c856', '', '1'),
(27, 'subscriber', 'nishant@gmail.com', '61416141', '', '9416924000', 'Gurugram', 'd-p1LV-5S-4:APA91bEYZcjkY23OvoEKp5QCGQ2EyCyll0-fL4cLKzuHvjmGpeWrHpnEn1YqqjJ3GnUfx1qcuz758QyTGczEH3bntQKnipsjqMytPZ0e869vYs5j6rLf4BebRvSGILbmv5j4ryoqjphg', 'user_59d34d1ca3b9f', '', '1'),
(28, 'subscriber', 'prince@gmail.com', '1234567890', '1234567890', '1234567890', 'Kotagiri', 'f_aaMrajUxw:APA91bHv9aLY2ZPEZEiQ3AXhBF7uyCd03i2kwwkWqvHxrVTJwV-r75MPzbZsA6KMVLtNl6eF7kYY0n9r9OQpiORLCFRLEDsYvRi6UFTne7Wk98sWbbXGlEWdTPbytRMqOWmGwaVhgisc', 'user_59dddb3e37492', '', '1'),
(29, 'subscriber', 'new@gmail.com', 'q2345678', '12345678', '9099900088', 'Wayanad Wildlife Sanctuary', 'dPm9m3SV8Xc:APA91bH1Be_65wqf7jMGsngIVp7JAfRnOA-KJpP0xWO8IhZPnQ2dLdNPC2kGmngRfGqrlJwP7iOMwOXOd9KkPJFLsfdyB8ni8SXl9BFXLjTOOMOBB0urpNdT0HBJ4oKU2fPQmriJET3N', 'user_59dddc90a2266', '', '1'),
(30, 'subscriber', 'ad@gmail.com', '123456u8', '12345678', '9034640888', 'Wayanad Wildlife Sanctuary', 'dPm9m3SV8Xc:APA91bH1Be_65wqf7jMGsngIVp7JAfRnOA-KJpP0xWO8IhZPnQ2dLdNPC2kGmngRfGqrlJwP7iOMwOXOd9KkPJFLsfdyB8ni8SXl9BFXLjTOOMOBB0urpNdT0HBJ4oKU2fPQmriJET3N', 'user_59dddd03ef4f0', '', '1'),
(31, 'subscriber', 'choudharyyogesh15@gmail.com', '9729973005', 'bmsbdjkjd', '9582704524', 'sushant lok', '', 'user_59de1f8b51ad1', '', '1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
