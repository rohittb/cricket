<?php 
include('../header.php');
date_default_timezone_set('Asia/Kolkata');
										 ?>
										 
										
 <div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
								
  
						
 		<div class="row">
									<div class="col-xs-12">
										<table id="simple-table" class="table  table-bordered table-hover">
											<thead>
												<tr>
													<th class="detail-col">Sr.no</th>
													<th>User</th>
													<th>Car</th>
													<th class="hidden-480">Bid price</th>
													<th class="hidden-480">highest bid</th>												
													
												</tr>
											</thead>

											<tbody id="result">
											<?php  
$qry = "select id from ca_cars where start_auction='1'";
$result1 = $connection->query($qry);
$count=1;
while($row2 = $result1->fetch_assoc())
{
	
	$id = $row2['id'];
	 $sql = "SELECT ca_cars.id, ca_cars.car_name, ca_cars.car_model, ca_cars.price, car_auction.price_auction as max_bid, car_auction.user_id
FROM ca_cars
JOIN car_auction ON ca_cars.id = car_auction.car_id
WHERE car_auction.price_auction = (
SELECT max( price_auction )
FROM car_auction
WHERE car_id = '$id')";
$result=$connection->query($sql);
 $count=1;
 $row = $result->fetch_assoc();

 //print_r($row);



?>
			<tr>
													<td class="center">
														<?php echo $count; ?>
													</td>

													<td class="center">
					<?php echo $row['user_id'];?>
															
														</div>
													</td>

													<td>
														<?php echo $row['car_name']." ".$row['car_model'] ;?>
													</td>
													<td><?php echo $row['price'];?></td>
													<td><?php echo $row['max_bid'];?></td>
													
												
												</tr>
<?php  $count++; }?>
											</tbody>
										</table>
									</div><!-- /.span -->
								</div><!-- /.row -->
								</div><!-- /.row -->
								</div><!-- /.row -->
								
<script>
var interval;
function callAjax() {
	
  $.ajax({
                type: 'POST',
                url: '../data/ajax_bids.php',
                data: $(this).serialize(),
                dataType: 'html',
                success: function (data) {
					
                        $('#result').html(data);// first set the value 
        
                }
        });
}



window.setInterval(function(){
 //alert("interval");
 callAjax();
}, 5000);


$(document).ready(function(){
  // we call the function
  
});
</script>

<?php include('../footer.php'); ?>
