<?php
include('../header.php');

?>
<div class="container-fluid">
    <section class="container">
		<div class="container-page">				
			<div class="col-md-6">
			<form id ="new_user_reg" action = "../data/user_add.php" >
				<h3 class="dark-grey">Registration</h3>
				
				<div class="form-group col-lg-12">
					<label>Email</label>
					<input type="email" name="email" class="form-control" id="email" value="" required= "required">
				</div>
				
				<div class="form-group col-lg-6">
					<label>Password</label>
					<input type="password" name="password" class="form-control" id="password" value="" required= "required">
				</div>
				
				<div class="form-group col-lg-6">
					<label>Pan Number</label>
					<input type="text" name="pan" class="form-control" id="pan" value="pan" required= "required">
				</div>
								
				<div class="form-group col-lg-6">
					<label>Mobile Number</label>
					<input type="text" name="mobile" class="form-control" id="mobile" value="" required= "required">
				</div>
				
				<div class="form-group col-lg-6">
					<label>Location</label>
					<input type="text" name="" class="form-control" id="location" value="location" required= "required">
				</div>			
		<div class="form-group col-lg-6">
					<label>Prefrences</label>
					<input type="text" name="prefrences" class="form-control" id="prefrences" value="prefrences" required= "required">
				</div>	
					<div class="form-group col-lg-12">
					<button type="submit" class="btn btn-default">Add user</button>
					</div>
			</div>
			</form>
		</div>
		</div>		
	</section>
	<i id = "loader" class="fa fa-spinner fa-spin" style="font-size:24px;display:none;"></i>
		<div id = "result" style = "display:none;margin:0 0 0 200px;font-size:17px;color:red;">
</div>

<?php include('../footer.php');?>
