<?php 
include('../header.php');
date_default_timezone_set('Asia/Kolkata');
										 ?>
										 
										
 <div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
								<div class="row">
									<div class="col-xs-12">
										<table id="simple-table" class="table  table-bordered table-hover">
											<thead>
												<tr>
													<th class="detail-col">Sr.no</th>
													<th>car</th>
													<th>Kms  Driven</th>
													<th class="hidden-480">Reg No.</th>
													<th class="hidden-480">Year</th>
													<th></th>
													<th></th>
												</tr>
											</thead>

											<tbody>
											<?php   $sql = "select * from ca_cars";
											$result=$connection->query($sql);
											$total_records = $result->num_rows;
											$num_rec_per_page = 50;
$total_pages = ceil($total_records / $num_rec_per_page);											
											
											if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; }; 
$start_from = ($page-1) * $num_rec_per_page; 
											$sql1 = "select * from ca_cars ORDER BY id DESC limit $start_from, $num_rec_per_page";
											$result1=$connection->query($sql1); 
										 if($result1){
   $count=1;
  while($row = $result1->fetch_assoc()) {
   $array[] = $row;
   
}

 foreach($array as $val)
 {
	  $auction_start = $val['start_auction'];
	  $auction_date_time = $val['auction_date'];
	  $minutes="";
	 if(!empty($auction_date_time)){
	
	 $auction_duration = $val['auction_duration'];
	
 $auction_timestamp = strtotime('+'.$auction_duration .' hours', strtotime( $auction_date_time ));
	 // $auction_timestamp1 = strtotime($auction_date_time);
	 $current_date = date('d-m-Y H:i:s');
	 $current_timestamp = strtotime($current_date);
	 $differenceInSeconds = $auction_timestamp - $current_timestamp; 
	 $minutes1 = $differenceInSeconds / 60;
$minutes = round($minutes1);
	 }
 ?>
												<tr>
													<td class="center">
														<?php echo $count; ?>
													</td>

													<td class="center">
					<?php echo $val['car_name']." ". $val['car_model'];?>
															
														</div>
													</td>

													<td>
														<?php echo $val['car_kms'];?>
													</td>
													<td><?php echo $val['registration'];?></td>
													<td><?php echo $val['car_model_year'];?></td>
													<td>
														<div class="hidden-sm hidden-xs btn-group">
															<a href="<?php echo $base_url;?>/pages/edit-car.php?car_id=<?php echo$val['id']; ?>"><button class="btn btn-xs btn-info" edit = "<?php echo $val['id']; ?>">
																<i class="ace-icon fa fa-pencil bigger-120"></i>
															</button>
															<!--</a>-->

															<button class="btn btn-xs btn-danger delete_car" dlt = "<?php echo $val['id']; ?>">
																<i class="ace-icon fa fa-trash-o bigger-120"></i>
															</button>

														</div>

												
													</td>
													<td>
<?php if($minutes<=0 AND !empty($minutes)) { ?>			
	<button type="button" class="btn btn-info disabled">Auction completed </button>	
	<?php  $sql3="UPDATE ca_cars SET start_auction  ='2' where id = $val[id]";
	 
	$result3=$connection->query($sql3); $qry = "select MAX(price_auction) as price from car_auction where car_id='$val[car_id]'";
$result4 = $connection->query($qry); 
$row4 =  $result4->fetch_object();//print_r($row4);
$max_price = $row4->price;$qry1 = "UPDATE car_auction SET bid_status  ='win' where car_id = '$val[car_id]' AND price_auction = '$max_price'";$result4 = $connection->query($qry1);$qry2 = "UPDATE car_auction SET bid_status = 'lost' WHERE price_auction < '$max_price' AND car_id = '$val[car_id]'";$result5 = $connection->query($qry2);
	?>
	 <?php } else { if($auction_start=="0") {?>								
													
													
													<button type="button" class="btn btn-info  start_auction" data-toggle="modal" data-target="#myModal" car_id = "<?php echo $val['id']; ?>" price = "<?php echo $val['price']; ?>" car_name = "<?php echo $val['car_name'].$val['car_model'];?>">Start auction</button>
<?php } elseif($auction_start=="1") { ?>
<button  class="btn btn-info stop_auction" edit = "<?php echo $val['id']; ?>" start_auction="<?php echo $val['start_auction']; ?>" >Stop Auction </button>
<?php } } ?>	
													<!--<button class="btn btn-xs btn-danger start_auction" car_id = "<?php echo $val['id']; ?>" price = "<?php echo $val['price']; ?>" data-target="#myModal">
																start auction
															</button>--></td>
												</tr>

										 <?php $count++;} } ?>
																</div>
															</div>
														</div>
													</td>
												</tr>
											</tbody>
										</table>
									</div><!-- /.span -->
								</div><!-- /.row -->
								</div><!-- /.row -->
								</div><!-- /.row -->
								<?php
echo "<a href='pagination.php?page=1'>".'|<'."</a> "; // Goto 1st page  

for ($i=1; $i<=$total_pages; $i++) { 
            echo "<a href='view-user.php?page=".$i."'>".$i."</a> "; 
}; 
echo "<a href='view-user?page=$total_pages'>".'>|'."</a> "; // Goto last page
?>
		



<!-- Modal -->

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Auction info</h4>
      </div>
      <div class="modal-body">
        <form id="auction_form" action="">
		<div class="form-group col-lg-6">
					<label>price:</label>
					<input type="text" name="price" class="form-control" id="price" value="" required= "required">
				</div>
				
				<div class="form-group col-lg-6">
					<label>auction duration</label>
					<input type="number" name="auction_duration" class="form-control" id="auction_duration" value="" required= "required">
					<input type="hidden" name="auction_start" class="form-control" id="auction_start" value="1" >
					<input type="hidden" name="car_id_auction" class="form-control" id="car_id_auction" value="" >
					<input type="hidden" name="car_name1" class="form-control" id="car_name1" value="" >
				</div>
				<div class="form-group col-lg-12">
					
					<input type="submit" value = "start_auction">
				</div>
		</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<?php include('../footer.php'); ?>
