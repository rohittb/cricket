<?php 
include('../header.php');
 
										 ?>
										 
										
 <div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
								<div class="row">
									<div class="col-xs-12">
										<table id="simple-table" class="table  table-bordered table-hover">
											<thead>
												<tr>
												<th class="detail-col">Sr.no</th>
													<th>Mobile</th>
													<th>Email</th>
													<th class="hidden-480">Pan</th>
													<th class="hidden-480">location</th>
													<th></th>
												</tr>
											</thead>
											<tbody>
											<?php  $sql = "select * from ca_user";
											$result = $connection->query($sql);
											 $total_records = $result->num_rows;
											 $num_rec_per_page = 100;
$total_pages = ceil($total_records / $num_rec_per_page);											
											
											if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; }; 
$start_from = ($page-1) * $num_rec_per_page; 
											$query = "select * from ca_user limit $start_from, $num_rec_per_page";
											$result1 = $connection->query($query);
										 if($result1){
   $count=1;
  while($row = $result1->fetch_assoc()) {
   $array[] = $row;
   
}

 foreach($array as $val)
 {
 ?>
												<tr>
													<td class="center">
														<?php echo $count; ?>
													</td>

													<td class="center">
					<?php echo $val['email'];?>
															
														</div>
													</td>

													<td>
														<?php echo $val['mobile_no'];?>
													</td>
													<td><?php echo $val['pan_no'];?></td>
													<td><?php echo $val['location'];?></td>
													<td><?php  if($val['user_approve']==1){?>
<div class="hidden-sm hidden-xs btn-group">
															<button  class="btn btn-xs btn-info approve" edit = "<?php echo $val['user_id']; ?>" app_rove="<?php echo $val['user_approve']; ?>">
																Approved
															</button>
															</div>
													<?php }  else {?>
													<div class="hidden-sm hidden-xs btn-group">
															<button  class="btn btn-xs btn-info approve" edit = "<?php echo $val['user_id']; ?>" app_rove="<?php echo $val['user_approve']; ?>" >
																Pending
															</button>
															</div>
													<?php } ?>
													</td>
													<td>
														<div class="hidden-sm hidden-xs btn-group">
															<a href="<?php echo $base_url;?>/pages/edit-user.php?user_id=<?php echo$val['user_id']; ?>"><button class="btn btn-xs btn-info edit_user" edit = "<?php echo $val['user_id']; ?>">
																<i class="ace-icon fa fa-pencil bigger-120"></i>
															</button></a>

															<button class="btn btn-xs btn-danger delete_user" dlt = "<?php echo $val['user_id']; ?>">
																<i class="ace-icon fa fa-trash-o bigger-120"></i>
															</button>

														</div>

												
													</td>
												</tr>

										 <?php $count++;} } ?>
																</div>
															</div>
														</div>
													</td>
												</tr>
											</tbody>
										</table>
									</div><!-- /.span -->
								</div><!-- /.row -->
								</div><!-- /.row -->
								</div><!-- /.row -->
								<?php
echo "<a href='pagination.php?page=1'>".'|<'."</a> "; // Goto 1st page  

for ($i=1; $i<=$total_pages; $i++) { 
            echo "<a href='view-user.php?page=".$i."'>".$i."</a> "; 
}; 
echo "<a href='view-user?page=$total_pages'>".'>|'."</a> "; // Goto last page
?>
									
<?php include('../footer.php'); ?>