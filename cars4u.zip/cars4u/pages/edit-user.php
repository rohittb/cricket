<?php
include('../header.php');
$user_id = $_REQUEST['user_id'];
$sql ="select * from ca_user where user_id = $user_id";
$result= $connection->query($sql);
while($row = $result->fetch_assoc()) {
   $array[] = $row;
   
}
foreach($array as $val)
{
	
?>
<div class="container-fluid">
    <section class="container">
		<div class="container-page">				
			<div class="col-md-6">
			<form id ="user_update" action = "../data/user_info_update.php" >
				<h3 class="dark-grey">Registration</h3>
				
				<div class="form-group col-lg-12">
					<label>Email</label>
					<input type="email" name="email" class="form-control" id="email" value="<?php echo  $val['email']; ?>" required= "required">
				</div>
				
				<div class="form-group col-lg-6">
					<label>Password</label>
					<input type="password" name="password" class="form-control" id="password" value="<?php echo  $val['password']; ?>" required= "required">
				</div>
				
				<div class="form-group col-lg-6">
					<label>Pan Number</label>
					<input type="text" name="pan" class="form-control" id="pan" value="<?php echo  $val['pan_no']; ?>" required= "required">
				</div>
								
				<div class="form-group col-lg-6">
					<label>Mobile Number</label>
					<input type="text" name="mobile" class="form-control" id="mobile" value="<?php echo  $val['mobile_no']; ?>" required= "required">
				</div>
				
				<div class="form-group col-lg-6">
					<label>Location</label>
					<input type="text" name="" class="form-control" id="location" value="<?php echo  $val['location']; ?>" required= "required">
				</div>			
		<div class="form-group col-lg-6">
					<label>Prefrences</label>
					<input type="text" name="prefrences" class="form-control" id="prefrences" value="<?php echo  $val['prefrences']; ?>" required= "required">
				<input type="hidden" name = "user_id" value = "<?php echo $val['user_id']; ?>" id ="user_id"/>
				</div>	
					<div class="form-group col-lg-12">
					<button type="submit" class="btn btn-default">Update user</button>
					</div>
			</div>
			</form>
		</div>
		</div>		
	</section>
	<i id = "loader" class="fa fa-spinner fa-spin" style="font-size:24px;display:none;"></i>
		<div id = "result" style = "display:none;margin:0 0 0 200px;font-size:17px;color:red;">
</div>
<?php } include('../footer.php');
?>

