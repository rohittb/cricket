<?php
include('../header.php');
?>
<div class="container-fluid">
    <section class="container">
		<div class="container-page">
	
			<div class="col-md-6">
			<form id ="uploadForm" action = "../data/user_add.php" method = "get">
				<h3 class="dark-grey">Registration</h3>
				<div class="col-md-12">
    <div class="form-group">
        <label>car main Image</label>
        <div class="input-group">
            <span class="input-group-btn">
                <span class="btn btn-default btn-file">
                    Browse… <input type="file" id="imgInp" name = "profile_img">
                </span>
            </span>
            <input type="text" class="form-control" readonly>
        </div>
		
        <img id='img-upload'/>
    </div>
</div>	
				<div class="form-group col-lg-6">
					<label>Vehicle Make</label>
					<input type="text" name="car_name" class="form-control" id="car_name" value="" required= "required">
				</div>
				
				<div class="form-group col-lg-6">
					<label>Car Registration</label>
					<input type="text" name="car_reg" class="form-control" id="car_reg" value="" required= "required">
				</div>
				
				<div class="form-group col-lg-6">
					<label>Odometer Reading</label>
					<input type="text" name="kms" class="form-control" id="kms" value="" required= "required">
				</div>
								
				<div class="form-group col-lg-6">
					<label>Model</label>
					<input type="text" name="model" class="form-control" id="model" value="" required= "required">
				</div>
				<div class="form-group col-lg-6">
					<label>Year</label>
					<input type="text" name="year" class="form-control" id="year" value="" required= "required">
				</div>	
				<div class="form-group col-lg-6">
					<label>color</label>
					<input type="text" name="color" class="form-control" id="color" value="" required= "required">
				</div>
<div class="form-group col-lg-6">
					<label>2nd Key</label>
					<input type="text" name="second_key" class="form-control" id="second_key" value="" required= "required">
				</div>	
<div class="form-group col-lg-6">
					<label>Insurance</label>
					<input type="text" name="insurance" class="form-control" id="insurance" value="" required= "required">
				</div>	
<div class="form-group col-lg-12">
					<label>Owner Serial</label>
					<input type="text" name="serial" class="form-control" id="serial" value="" required= "required">
				</div>					
<div class="form-group col-lg-6">
					<label>Fuel Type</label>
					<div>
					<select id = "car_varriant" name ="car_varriant" required>
					<option value = "Petrol">Petrol</option>
					<option value = "Diesel">Diesel</option>
					<option value = "Cng & Petrol">Cng & Petrol</option>
					
					</select>
				</div>				
				</div>	
<div class="form-group col-lg-6">
					<label>Transmission</label>
					<div>
					<select id = "transmission" name ="transmission" required>
					<option value = "automatic">Automatic</option>
					<option value = "Manual">Manual</option>
</select>
				</div>				
				</div>					
		<div class="form-group col-lg-6">
		
					<label>Wheel Cover</label>
					<div>
					<select id = "wheel_cover" name = "wheel_cover" required>
					<option value = "yes">Yes</option>
					<option value = "no">No</option>
					
					
					</select>
				</div>
				</div>
				<div class="form-group col-lg-6">
					<label>Music Player</label>
					<div>
					<select id = "music_player" name = "music_player" required>
					<option value = "yes">Yes</option>
					<option value = "no">No</option>
					
					
					</select>
					
					
					</div>
				</div>	
			<div class="form-group col-lg-6">
					<label>Tool Kit</label>
					<div>
					<select id = "tool_kit" name = "tool_kit" required>
					<option value = "yes">Yes</option>
					<option value = "no">No</option>
					
					
					</select>
					
					
					</div>
				</div>	
				<div class="form-group col-lg-6">
					<label>Jack</label>
					<div>
					<select id = "jack" name = "jack" required>
					<option value = "yes">Yes</option>
					<option value = "no">No</option>
					
					
					</select>
					
					
					</div>
				</div>	
				<div class="form-group col-lg-6">
					<label>Sun Roof</label>
					<div>
					<select id = "sunroof" name = "sunroof" required>
					<option value = "yes">Yes</option>
					<option value = "no">No</option>
					
					
					</select>
					
					
					</div>
				</div>
<div class="form-group col-lg-6">
					<label>Fog Lamp</label>
					<div>
					<select id = "fog_lamp" name = "fog_lamp" required>
					<option value = "yes">Yes</option>
					<option value = "no">No</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-12">
					<label>Seat Covers</label>
					<div>
					<select id = "seat_covers" name = "seat_covers" required>
					<option value = "yes">Yes</option>
					<option value = "no">No</option>
					
					
					</select>
					
					
					</div>
				</div>	
				<div class="form-group col-lg-12">
<h4 style = "text-align:center;">INSPECTION CHECKLIST</h4>	
</div>
<h6 style = "text-align:center;">Unusual Noises:</h6>	
			<div class="form-group col-lg-12">
					<label>Noises:</label>
					<div>
					<select id = "noise" name = "noise" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
				<h6 style = "text-align:center;">Gauges</h6>
				<div class="form-group col-lg-6">
					<label>fuel:</label>
					<div>
					<select id = "fuel" name = "fuel" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Temprature:</label>
					<div>
					<select id = "temprature" name = "temprature" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-12">
					<label>Dashboard Warning Light:</label>
					<div>
					<select id = "dashboard_warning_light" name = "dashboard_warning_light" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<h6 style = "text-align:center;">Lights:</h6>	
<div class="form-group col-lg-6">
					<label>Headlight:</label>
					<div>
					<select id = "headlight" name = "headlight" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>		
<div class="form-group col-lg-6">
					<label>Break light:</label>
					<div>
					<select id = "break_light" name = "break_light" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Parking light:</label>
					<div>
					<select id = "park_light" name = "park_light" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Turn Signals:</label>
					<div>
					<select id = "turn_signals" name = "turn_signals" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
			<!--<div class="form-group col-lg-12">
					<label>Hazzard Lights:</label>
					<div>
					<select id = "hazzard_light" name = "hazzard_light" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>-->
<h6 style = "text-align:center;">Others:</h6>	
<div class="form-group col-lg-6">
					<label>Windshield Wipers:</label>
					<div>
					<select id = "Windshield_wipers" name = "Windshield_wipers" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>		
<div class="form-group col-lg-6">
					<label>Fans and Defroster:</label>
					<div>
					<select id = "fans_defroster" name = "fans_defroster" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Brakes:</label>
					<div>
					<select id = "brakes" name = "brakes" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<!--<div class="form-group col-lg-6">
					<label>Parking Break:</label>
					<div>
					<select id = "parking_break" name = "parking_break" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	-->
			<div class="form-group col-lg-6">
					<label>Mirrors:</label>
					<div>
					<select id = "mirrors" name = "mirrors" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Horn:</label>
					<div>
					<select id = "horn" name = "horn" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Exhaust System:</label>
					<div>
					<select id = "exhaust_system" name = "exhaust_system" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Suspension:</label>
					<div>
					<select id = "Suspension" name = "Suspension" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>
<div class="form-group col-lg-6">
					<label>Steering:</label>
					<div>
					<select id = "steering" name = "Steering" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>
<div class="form-group col-lg-12">
					<label>Steering controls:</label>
					<div>
					<select id = "steering_cntrls" name = "steering_cntrls" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
				<h6 style = "text-align:center;">Tyres:</h6>
				<div class="form-group col-lg-6">
					<label>Front Tyres:</label>
					<div>
					<select id = "infaltion" name = "infaltion" required>
					<option value = "20%">20%</option>
					<option value = "40%">40%</option>					<option value = "60%">60%</option>					<option value = "80%">80%</option>					<option value = "100%">100%</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Rear Tyre:</label>
					<div>
					<select id = "adequate" name = "adequate" required>
					<option value = "20">20%</option>					<option value = "40">40%</option>					<option value = "60%">60%</option>					<option value = "80%">80%</option>					<option value = "100">100</option>
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-12">
					<label>Spare Tyre	:</label>
					<div>
					<select id = "spare_inflated" name = "spare_inflated" required>
					<option value = "20%">20%</option>					<option value = "40%">40%</option>					<option value = "60%">60%</option>					<option value = "80%">80%</option>					<option value = "100%">100%</option>
					
					
					</select>
					
					
					</div>
				</div>	
				<h6 style = "text-align:center;">Leaks:</h6>
				<div class="form-group col-lg-6">
					<label>Oil:</label>
					<div>
					<select id = "oil" name = "oil" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Other:</label>
					<div>
					<select id = "leaks_other" name = "leaks_other" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
					<h6 style = "text-align:center;">Safety Equipment:</h6>
				<div class="form-group col-lg-6">
					<label>First Aid Kit:</label>
					<div>
					<select id = "first_aid" name = "first_aid" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Seat Belts:</label>
					<div>
					<select id = "seat_belts" name = "seat_belts" required>
					<option value = "ok">ok</option>
					<option value = "need attention">Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
				<div class="form-group col-lg-6">
					<label>Airbag:</label>
					<div>
					<select id = "airbag" name = "airbag" required>
					<option value = "yes">yes</option>
					<option value = "no">No</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Abs Break:</label>
					<div>
					<select id = "abs_break" name = "absbreak" required>
					<option value = "Yes">Yes</option>
					<option value = "No">No</option>
					
					
					</select>
					
					
					</div>
				</div>
<h6 style = "text-align:center;">Air conditioner:</h6>
				<div class="form-group col-lg-6">
					<label>Ac:</label>
					<div>
					<select id = "ac" name = "ac" required>
					<option value = "automatic">automatic</option>
					<option value = "manual">manual</option>
					
					
					</select>
					
					
					</div>
				</div>	<div class="form-group col-lg-6">					<label>Ac Condition:</label>					<div>					<select id = "ac_cond" name = "ac_cond" required>					<option value = "ok">ok</option>					<option value = "needs attention">needs attention</option>															</select>															</div>				</div>	
				<div class="form-group col-lg-12">
<h4 style = "text-align:center;">Exterior</h4>	

</div>			
<div class="form-group col-lg-6">
					<label>Boonet:</label>
					<div>
					<select id = "boonet" name = "boonet" required>
					<option value = "original">original</option>
					<option value = "painted">painted</option>
					<option value = "painted">painted</option>
					<option value = "changed">changed</option>
					<option value = "need reparing">need reparing</option>
					
					
					</select>
					
					
					</div>
				</div>
				<div class="form-group col-lg-6">
					<label>Right Fander:</label>
					<div>
					<select id = "right_fander" name = "right_fander" required>
					<option value = "original">original</option>
					<option value = "painted">painted</option>
					<option value = "painted">painted</option>
					<option value = "changed">changed</option>
					<option value = "need reparing">need reparing</option>
					
					
					</select>
					
					
					</div>
				</div>
				<div class="form-group col-lg-6">
					<label>Left Fander:</label>
					<div>
					<select id = "left_fander" name = "left_fander" required>
					<option value = "original">original</option>
					<option value = "painted">painted</option>
					<option value = "painted">painted</option>
					<option value = "changed">changed</option>
					<option value = "need reparing">need reparing</option>
					
					
					</select>
					
					
					</div>
					
				</div>
					<div class="form-group col-lg-6">
					<label>Front Right Window:</label>
					<div>
					<select id = "front_rit_window" name = "front_rit_window" required>
					<option value = "original">original</option>
					<option value = "painted">painted</option>
					<option value = "painted">painted</option>
					<option value = "changed">changed</option>
					<option value = "need reparing">need reparing</option>
					
					
					</select>
					
					
					</div>
					
				</div>
				<div class="form-group col-lg-6">
					<label>Front Left Window:</label>
					<div>
					<select id = "front_left_window" name = "front_left_window" required>
					<option value = "original">original</option>
					<option value = "painted">painted</option>
					<option value = "painted">painted</option>
					<option value = "changed">changed</option>
					<option value = "need reparing">need reparing</option>
					
					
					</select>
					
					
					</div>
					
				</div>
				<div class="form-group col-lg-6">
					<label>Rear right Window:</label>
					<div>
					<select id = "rear_right_window" name = "rear_right_window" required>
					<option value = "original">original</option>
					<option value = "painted">painted</option>
					<option value = "painted">painted</option>
					<option value = "changed">changed</option>
					<option value = "need reparing">need reparing</option>
					
					
					</select>
					
					
					</div>
					
				</div>
				<div class="form-group col-lg-6">
					<label>Rear Left Window:</label>
					<div>
					<select id = "rear_left_window" name = "rear_left_window" required>
					<option value = "original">original</option>
					<option value = "painted">painted</option>
					<option value = "painted">painted</option>
					<option value = "changed">changed</option>
					<option value = "need reparing">need reparing</option>
					
					
					</select>
					
					
					</div>
					
				</div>
				<div class="form-group col-lg-6">
					<label>Right Quarter Panel:</label>
					<div>
					<select id = "right_quarter_panel" name = "right_quarter_panel" required>
					<option value = "original">original</option>
					<option value = "painted">painted</option>
					<option value = "painted">painted</option>
					<option value = "changed">changed</option>
					<option value = "need reparing">need reparing</option>
					
					
					</select>
					
					
					</div>
					
				</div>
				<div class="form-group col-lg-6">
					<label>Left Quarter Panel:</label>
					<div>
					<select id = "left_quarter_panel" name = "left_quarter_panel" required>
					<option value = "original">original</option>
					<option value = "painted">painted</option>
					<option value = "painted">painted</option>
					<option value = "changed">changed</option>
					<option value = "need reparing">need reparing</option>
					
					
					</select>
					
					
					</div>
					
				</div>
				<div class="form-group col-lg-6">
					<label>Roof:</label>
					<div>
					<select id = "roof" name = "roof" required>
					<option value = "original">original</option>
					<option value = "painted">painted</option>
					<option value = "painted">painted</option>
					<option value = "changed">changed</option>
					<option value = "need reparing">need reparing</option>
					
					
					</select>
					
					
					</div>
					
				</div>
				<div class="form-group col-lg-6">
					<label>Boot:</label>
					<div>
					<select id = "boot" name = "boot" required>
					<option value = "original">original</option>
					<option value = "painted">painted</option>
					<option value = "painted">painted</option>
					<option value = "changed">changed</option>
					<option value = "need reparing">need reparing</option>
					
					
					</select>
					
					
					</div>
					
				</div>
				<div class="form-group col-lg-6">
					<label>Alloy Wheel:</label>
					<div>
					<select id = "alloy_wheel" name = "alloy_wheel" required>
					<option value = "Yes">Yes</option>
					<option value = "No">No</option>
					
					
					
					</select>
					
					
					</div>
					
				</div>
					<div class="form-group col-lg-6">
					<label>Front Bumper</label>
					<input type="text" name="front_bumper" class="form-control" id="front_bumper" value="" required= "required">
				</div>
				<div class="form-group col-lg-6">
					<label>Rear Bumper</label>
					<input type="text" name="rear_bumper" class="form-control" id="rear_bumper" value="" required= "required">
				</div>
				<div class="form-group col-lg-12">
					<label>Exterior comment:</label>
					<div>
					<input type="textarea" name = "exterior_comments" />
					
					
					</select>
					
					
					</div>
					
				</div>
				<div class="form-group col-lg-12">
				<h4 style = "text-align:center;">Interior</h4>
				</div><div class="form-group col-lg-6">					<label>Dashboard:</label>					<div>					<select id = "dashboard" name = "dashboard" required>					<option value = "ok">ok</option>					<option value = "needs attention">needs attention</option>					</select>					</div>				</div>	
			<div class="form-group col-lg-6">					<label>Steering:</label>					<div>					<select id = "int_steering" name = "int_steering" required>					<option value = "ok">ok</option>					<option value = "needs attention">needs attention</option>					</select>					</div>				</div>	
				<div class="form-group col-lg-6">					<label>Gear Console:</label>					<div>					<select id = "gear_console" name = "gear_console" required>					<option value = "ok">ok</option>					<option value = "needs attention">needs attention</option>					</select>					</div>				</div>	
				<div class="form-group col-lg-6">					<label>Hand Break:</label>					<div>					<select id = "hand_break" name = "hand_break" required>					<option value = "ok">ok</option>					<option value = "needs attention">needs attention</option>					</select>					</div>				</div>	
				<div class="form-group col-lg-6">					<label>Seats:</label>					<div>					<select id = "seats" name = "seats" required>					<option value = "ok">ok</option>					<option value = "needs attention">needs attention</option>					</select>					</div>				</div>	
				<div class="form-group col-lg-12">
					<label>Interior comments</label>
					<input type="textarea" name="int_comments" class="form-control" id="int_comments" value="" required= "required">
				</div>
				<div class="form-group col-lg-12">
<h4 style="text-align:center;">Auction:</h4>
</div>
				<div class="form-group col-lg-6">
					<label>Price:</label>
					<input type="text" name="price" class="form-control" id="price" value="" required= "required">
				</div>
				<div class="form-group col-lg-6">
					<label>Auction Time:</label>
					<input type="text" name="auction_time" class="form-control" id="auction_time" value="" required= "required">
				</div>
				
				
				<div class="form-group col-lg-12">
<h4 style="text-align:center;">Car gallery</h4>
</div>
<div class="form-group col-lg-12">
<input type="file" id="files" name="files[]" multiple />
</div>	

				<div class="form-group col-lg-12">
<h4 style="text-align:center;">Signature</h4>
</div>
				<div class="form-group col-lg-12">
       
        <div class="input-group">
            <span class="input-group-btn">
                <span class="btn btn-default btn-file">
                    Browse… <input type="file" id="signature" name = "signature">
                </span>
            </span>
            <input type="text" class="form-control" readonly>
        </div>
		
        <img id='img-signature' style="width:20%"/>
    </div>
				<div class="form-group col-lg-12">
<h4 style="text-align:center;">Condition of Vehicle Following the Inspection:</h4>
</div>
<div class="form-group col-lg-6">
					<label></label>
					<div>
					<select id = "overall_condition" name = "overall_condition" required>
					<option value = "acceptable">acceptable</option>
					<option value = "required attention">Required Attention</option>
					<option value = "immediate attention">Immediate Attention</option>
					
					
					
					</select>
					
					
					</div>
					
				</div>
				<div class="form-group col-lg-6">
					<label>Rating:</label>
					<input type="text" name="rating" class="form-control" id="rating" value="" required= "required">
				</div>

				<div class="form-group col-lg-12">
					<button type="submit" class="btn btn-default">Add Car</button>
					</div>
			</div>
			</form>
		</div>
		</div>		
	</section>
	<i id = "loader" class="fa fa-spinner fa-spin" style="font-size:24px;display:none;"></i>
		<div id = "result" style = "display:none;margin:0 0 0 200px;font-size:17px;color:red;">
</div>

<?php  
include('../footer.php');
?>
<style>
.btn-file {
    position: relative;
    overflow: hidden;
}
.btn-file input[type=file] {
    position: absolute;
    top: 0;
    right: 0;
    min-width: 100%;
    min-height: 100%;
    font-size: 100px;
    text-align: right;
    filter: alpha(opacity=0);
    opacity: 0;
    outline: none;
    background: white;
    cursor: inherit;
    display: block;
}

#img-upload{
    width: 50%;
}
input[type="file"] {
 
 display:block;
}
.imageThumb {
 max-height: 75px;
 border: 2px solid;
 margin: 10px 10px 0 0;
 padding: 1px;
 }

</style>
