<?php 
include('../header.php');
date_default_timezone_set('Asia/Kolkata');
										 ?>
										 
										
 <div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
							
   <div class="form-group col-xs-3">
   <form name="bid_status" action="" method ="post">	
  <label for="usr">Status:</label>
  <select class="form-control" id="sel1" name="status" onchange="this.form.submit()">
    <option value="win">Win</option>
    <option value="lost">lost</option>
  </select>
 </form>		
</div> 
				
 		<div class="row">
									<div class="col-xs-12">
										<table id="simple-table" class="table  table-bordered table-hover">
											<thead>
												<tr>
													<th class="detail-col">Sr.no</th>
													<th>User</th>
													<th>Car</th>
													<th class="hidden-480">Bid price</th>
													<th class="hidden-480">highest bid</th>												
													<th class="hidden-480">status</th>												
													
												</tr>
											</thead>

											<tbody id="result">
											
											<?php 
if(!isset($_POST['status']) || $_POST['status']== 'win')
{	
$qry = "SELECT ca_cars.car_name, ca_cars.car_model, ca_cars.price, car_auction.price_auction as max_bid, car_auction.user_id,car_auction.bid_status
FROM ca_cars
JOIN car_auction ON ca_cars.car_id = car_auction.car_id
WHERE car_auction.bid_status = 'win'";
}
else
{
	$qry = "SELECT ca_cars.car_name, ca_cars.car_model, ca_cars.price, car_auction.price_auction as max_bid, car_auction.user_id,car_auction.bid_status
FROM ca_cars
JOIN car_auction ON ca_cars.car_id = car_auction.car_id
WHERE car_auction.bid_status = 'lost'";
}
$result1 = $connection->query($qry);
$count=1;
while($row2 = $result1->fetch_assoc())
{
	
	

// print_r($row);



?>
			<tr>
													<td class="center">
														<?php echo $count; ?>
													</td>

													<td class="center">
					<?php echo $var= $row2['user_id'];
					  // $sqlqry="select mobile_no from ca_user where email='$var' ";
					 //  $resultqry=$connection->query($sqlqry);
					  // $rowqry=$resultqry->fetch_object();
					  // echo $rowqry->mobile_no;?>
															
														</div>
													</td>

													<td>
														<?php echo $row2['car_name']." ".$row2['car_model'] ;?>
													</td>
													<td><?php echo $row2['price'];?></td>
													<td><?php echo $row2['max_bid'];?></td>
													<td><?php echo $row2['bid_status'];?></td>
													
												`
												</tr>
<?php  $count++; }?>
											</tbody>
										</table>
									</div><!-- /.span -->
								</div><!-- /.row -->
								</div><!-- /.row -->
								</div><!-- /.row -->
								


<?php include('../footer.php'); ?>
