<?php 
include('conn.php');
echo $url =  $_REQUEST['gallery_url'];
$carname = $_REQUEST['car_name']; 
$kms = $_REQUEST['kms'];
$year = $_REQUEST['year'];
$model = $_REQUEST['model'];
$car_reg = $_REQUEST['car_reg'];
$car_varriant = $_REQUEST['car_varriant']; 
$color = $_REQUEST['color'];
$transmission = $_REQUEST['transmission'];
$second_key = $_REQUEST['second_key'];
$owner_serial = $_REQUEST['serial'];
$insurance = $_REQUEST['insurance'];
$wheel_cover = $_REQUEST['wheel_cover'];
$music_player = $_REQUEST['music_player'];
$tool_kit = $_REQUEST['tool_kit'];
$sun_roof = $_REQUEST['sunroof'];
$jack = $_REQUEST['jack'];
$fog_lamp = $_REQUEST['fog_lamp'];
$seat_covers = $_REQUEST['seat_covers'];
$noise = $_REQUEST['noise'];
$temprature = $_REQUEST['temprature'];
 $fuel = $_REQUEST['fuel'];
$dashboard_warning_light = $_REQUEST['dashboard_warning_light'];
$headlight = $_REQUEST['headlight'];
$break_light = $_REQUEST['break_light'];
$parking_light = $_REQUEST['parking_light'];
$turn_signals = $_REQUEST['turn_signals'];
$hazzard_light = $_REQUEST['hazzard_light'];
$Windshield_wipers = $_REQUEST['Windshield_wipers'];
$steering = $_REQUEST['Steering'];
$fans_defroster = $_REQUEST['fans_defroster'];
$brakes = $_REQUEST['brakes'];
$parking_break = $_REQUEST['parking_break'];
$mirrors = $_REQUEST['mirrors'];
$horn = $_REQUEST['horn'];
$exhaust_system = $_REQUEST['exhaust_system'];
$suspension = $_REQUEST['Suspension'];
$infaltion = $_REQUEST['infaltion'];
$adequate = $_REQUEST['adequate'];
$spare_inflated = $_REQUEST['spare_inflated'];
$oil = $_REQUEST['oil'];
$leaks_other = $_REQUEST['leaks_other'];
$steering_cntrls = $_REQUEST['steering_cntrls'];
$first_aid = $_REQUEST['first_aid'];
$seat_belts = $_REQUEST['seat_belts'];
$airbag = $_REQUEST['airbag'];
$absbreak = $_REQUEST['absbreak'];
$ac = $_REQUEST['ac'];
$boonet = $_REQUEST['boonet'];
$right_fander = $_REQUEST['right_fander'];
$left_fander = $_REQUEST['left_fander'];
$front_rit_window = $_REQUEST['front_rit_window'];
$front_left_window = $_REQUEST['front_left_window'];
$rear_left_window = $_REQUEST['rear_left_window'];
$right_quarter_panel = $_REQUEST['right_quarter_panel'];
$left_quarter_panel = $_REQUEST['left_quarter_panel'];
$boot = $_REQUEST['boot'];
$rear_right_window = $_REQUEST['rear_right_window'];
$roof = $_REQUEST['roof'];
$front_bumper = $_REQUEST['front_bumper'];
$rear_bumper = $_REQUEST['rear_bumper'];
$exterior_comments = $_REQUEST['exterior_comments'];
$dashboard = $_REQUEST['dashboard'];
$int_steering = $_REQUEST['int_steering'];
$gear_console = $_REQUEST['gear_console'];
$hand_break = $_REQUEST['hand_break'];
$seats = $_REQUEST['seats'];
$int_comments = $_REQUEST['int_comments'];
$overall_condition = $_REQUEST['overall_condition'];
$ac_cond = $_REQUEST['ac_cond'];
 $price = $_REQUEST['price'];
 $rating = $_REQUEST['rating'];
 $car_id = "car_".uniqid();
 $url =  $_SERVER['HTTP_HOST'];
												$dir =  basename(__DIR__) ;
												  $base_url =  "http://go4intern.com/cars/cars4u";
												  
												  if(is_uploaded_file($_FILES['profile_img']['tmp_name'])) {
$sourcePath1 = $_FILES['profile_img']['tmp_name'];
$id1= uniqid();
$targetPath1 = "images/".$id1.$_FILES['profile_img']['name'];
 echo $image_url1 = $base_url."/data/images/".$id1.$_FILES['profile_img']['name'];
 imagejpeg($image, null, 10);
move_uploaded_file($sourcePath1,$targetPath1);

}
else
{
	echo $image_url1 = $_REQUEST['profile_image_val'];
}

if(is_uploaded_file($_FILES['signature']['tmp_name'])) {
$sourcePath2 = $_FILES['signature']['tmp_name'];
$id1= uniqid();
$targetPath2 = "images/".$id1.$_FILES['signature']['name'];
$image_url2 = $base_url."/data/images/".$id1.$_FILES['signature']['name'];
move_uploaded_file($sourcePath2,$targetPath2);
}
else
{
	$image_url2 = $_REQUEST['signature_image_val'];
}

?>