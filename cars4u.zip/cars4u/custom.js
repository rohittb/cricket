$(document).ready( function() {
    	$(document).on('change', '.btn-file :file', function() {
		var input = $(this),
			label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
		input.trigger('fileselect', [label]);
		});

		$('.btn-file :file').on('fileselect', function(event, label) {
		    
		    var input = $(this).parents('.input-group').find(':text'),
		        log = label;
		    
		    if( input.length ) {
		        input.val(log);
		    } else {
		        if( log ) alert(log);
		    }
	    
		});
		function readURL(input) {
		    if (input.files && input.files[0]) {
		        var reader = new FileReader();
		        
		        reader.onload = function (e) {
		            $('#img-upload').attr('src', e.target.result);
		        }
		        
		        reader.readAsDataURL(input.files[0]);
		    }
		}

		$("#imgInp").change(function(){
		    readURL(this);
		}); 	
	});
	

$(document).ready(function() {
 
 if(window.File && window.FileList && window.FileReader) {
 $("#files").on("change",function(e) {
 var files = e.target.files ,
 filesLength = files.length ;
 for (var i = 0; i < filesLength ; i++) {
 var f = files[i]
 var fileReader = new FileReader();
 fileReader.onload = (function(e) {
 var file = e.target;
 $("<img></img>",{
 class : "imageThumb",
 src : e.target.result,
 title : file.name
 }).insertAfter("#files");
 });
 fileReader.readAsDataURL(f);
 }
});
 } else { alert("Your browser doesn't support to File API") }
});
 
  
 


$(document).ready(function (e) {
	$("#uploadForm").on('submit',(function(e) {
		
		e.preventDefault();
		$("#loader").show();
		$.ajax({
        	url: "../data/user_car.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
			success: function(data)
		    {
				$("#loader").hide();
			$("#result").show();
			$("#result").html(data);
			document.getElementById("uploadForm").reset(); 
			//alert(data);
		    },
		  	error: function() 
	    	{
				
	    	} 	        
	   });
	}));
});

$(".approve").click(function(event) {
      event.preventDefault();
//$("#loader").show();
      /* get the action attribute from the <form action=""> element */
      
          url = '../data/update_user.php'
var user_id = $(this).attr('edit');
var user_approve = $(this).attr('app_rove');

      /* Send the data using post with element id name and name2*/
      var posting = $.post( url, { user_id: user_id ,user_approve: user_approve} );

      /* Alerts the results */
      posting.done(function( data ) {
		 location.reload(); 
      });
    });
	
	$(".delete_user").click(function(event) {
		
      event.preventDefault();
//$("#loader").show();
      /* get the action attribute from the <form action=""> element */
      
          url = '../data/delete_user.php'
var user_id = $(this).attr('dlt');

      /* Send the data using post with element id name and name2*/
      var posting = $.post( url, { user_id: user_id} );

      /* Alerts the results */
      posting.done(function( data ) {
		 
		 location.reload(); 
      });
    });
	
	
	$("#new_user_reg").submit(function(event) {
		alert("hello");
      event.preventDefault();
$("#loader").show();
      /* get the action attribute from the <form action=""> element */
      var $form = $( this ),
          url = $form.attr( 'action' );

      /* Send the data using post with element id name and name2*/
      var posting = $.post( url, { email: $('#email').val(), password: $('#password').val(),pan: $('#pan').val(),mobile: $('#mobile').val(),location: $('#location').val(),prefrences: $('#prefrences').val() } );

      /* Alerts the results */
      posting.done(function( data ) {
      if(data == "exist")
	  {
		  $("#loader").hide();
		$("#result").show();
		
		 $("#result").html("user already exist");
		 
	  }	
else if(data = "inserted")
{
	$("#loader").hide();
	$("#result").show();
	
		 $("#result").html("user added sucessfully");
		
}

else{
	$("#loader").hide();
	$("#result").show();
	
		 $("#result").html("please try again");
		 




}	
      });
    });
	
	
	$("#user_update").submit(function(event) {
      event.preventDefault();
$("#loader").show();
      /* get the action attribute from the <form action=""> element */
      var $form = $( this ),
          url = $form.attr( 'action' );

      /* Send the data using post with element id name and name2*/
      var posting = $.post( url, { email: $('#email').val(), password: $('#password').val(),pan: $('#pan').val(),mobile: $('#mobile').val(),location: $('#location').val(),prefrences: $('#prefrences').val(),user_id:$('#user_id').val() } );

      /* Alerts the results */
      posting.done(function( data ) {
    alert(data);  
 if(data = "inserted")
 {
	 $("#loader").hide();
	 $("#result").show();
	
		  $("#result").html("user updated sucessfully");
		
}

else{
	$("#loader").hide();
	$("#result").show();
	
		 $("#result").html("please try again");
		 




 }	
      });
    });
	
	
	$(".delete_car").click(function(event) {
		
      event.preventDefault();
//$("#loader").show();
      /* get the action attribute from the <form action=""> element */
      
          url = '../data/delete_car.php'
var user_id = $(this).attr('dlt');

      /* Send the data using post with element id name and name2*/
      var posting = $.post( url, { user_id: user_id} );

      /* Alerts the results */
      posting.done(function( data ) {
		 
		 location.reload(); 
      });
    });
	
	/********** signture image upload *****************/
	$(document).ready( function() {
    	$(document).on('change', '.btn-file :file', function() {
		var input = $(this),
			label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
		input.trigger('fileselect', [label]);
		});

		$('.btn-file :file').on('fileselect', function(event, label) {
		    
		    var input = $(this).parents('.input-group').find(':text'),
		        log = label;
		    
		    if( input.length ) {
		        input.val(log);
		    } else {
		        if( log ) alert(log);
		    }
	    
		});
		function readURL(input) {
		    if (input.files && input.files[0]) {
		        var reader = new FileReader();
		        
		        reader.onload = function (e) {
		            $('#img-signature').attr('src', e.target.result);
		        }
		        
		        reader.readAsDataURL(input.files[0]);
		    }
		}

		$("#signature").change(function(){
		    readURL(this);
		}); 	
	});
	
	
	$(".start_auction").click(function(event) {
	var price = $(this).attr('price');
var car_id =  $(this).attr('car_id');
var car_name =  $(this).attr('car_name');
document.getElementById("car_id_auction").value = car_id;
document.getElementById("price").value = price;
document.getElementById("car_name1").value = car_name;
});


$(document).ready(function (e) {
	$("#auction_form").on('submit',(function(e) {
		$('#myModal').modal('hide');
		e.preventDefault();
		$.ajax({
        	url: "../data/auction_car_update.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
			success: function(data)
		    {
		
			location.reload();
		    },
		  	error: function() 
	    	{
				
	    	} 	        
	   });
	}));
});

$(".stop_auction").click(function(event) {
      event.preventDefault();
	 
//$("#loader").show();
      /* get the action attribute from the <form action=""> element */
      
          url = '../data/stop_auction.php'
var car_id = $(this).attr('edit');

      /* Send the data using post with element id name and name2*/
      var posting = $.post( url, { car_id: car_id } );

      /* Alerts the results */
      posting.done(function( data ) {
	 location.reload(); 
		 //alert(data);
      });
    });