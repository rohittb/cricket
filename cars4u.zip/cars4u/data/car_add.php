<?php 
include('conn.php');
$username = $_REQUEST['email']; 
$password = $_REQUEST['password'];
$pan = $_REQUEST['pan'];
$mobile = $_REQUEST['mobile'];
$location = $_REQUEST['location'];
$price = $_REQUEST['price'];
$username = stripslashes($username);
$password = stripslashes($password);
$pan = stripslashes($pan);
$mobile = stripslashes($mobile);
$location = stripslashes($location);
$username = mysql_real_escape_string($username);
$password = mysql_real_escape_string($password);
$pan = mysql_real_escape_string($pan);
$mobile = mysql_real_escape_string($mobile);
$location = mysql_real_escape_string($location);
$sql="SELECT * FROM ca_user WHERE email='$username' or mobile_no='$mobile'";
$result=$connection->query($sql);

if ($result==false)
{
    die(mysql_error());
}
$count=$result->num_rows($result);
// If result matched $username and $password, table row must be 1 row
if ($count>=1) {
  
  echo "exist";
 
}
else
{
 $sql="INSERT INTO ca_user (role, email,password,pan_no,mobile_no,location) VALUES('subscriber','$username','$password','$pan','$mobile','$location')";
$result=$connection->query($sql);
if($result)
{
	echo "inserted";
}
else
{
	echo "not";
}
}
?>