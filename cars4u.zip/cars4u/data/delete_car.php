<?php
include('conn.php');
$user_id = $_REQUEST['user_id'];
$qry ="select car_id from ca_cars where id=$user_id";
$result1=$connection->query($qry);
$row = $result1->fetch_object();
$car_id = $row->car_id;
  $qry1= "DELETE FROM car_auction WHERE car_id = '$car_id'";
$result2=$connection->query($qry1);
 $sql = "DELETE FROM ca_cars WHERE id = $user_id";
 $result=$connection->query($sql);
if($result)
 {
	echo "deleted";
 }
 else
 {
	 echo "not deleted";
 }
?>