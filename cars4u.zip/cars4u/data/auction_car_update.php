<?php
include('conn.php');
$car_id = $_REQUEST['car_id_auction'];
$auction_start = $_REQUEST['auction_start'];
 $auction_duration = $_REQUEST['auction_duration'];
 $car_name1 = $_REQUEST['car_name1'];
 date_default_timezone_set('Asia/Kolkata');
  $date = date('d-m-Y H:i:s');
$sql="UPDATE ca_cars SET auction_date = '$date',start_auction  ='$auction_start',auction_duration = '$auction_duration' where id = $car_id";
$result=$connection->query($sql);
if($result)
{
	echo "updated";
	
}
else
{
	echo "not";
}

 $qry="select prefrences from ca_user";
$result2 =$connection->query($qry);

//$rows=array();

$rows = array();
while($row2 = $result2->fetch_assoc())
{

 $rows[] = $row2['prefrences'];
 
	

}

#API access key from Google API's Console
    define( 'API_ACCESS_KEY', 'AAAA0L2gPtk:APA91bF6nXcBa70NU0ZD5Y-Cig5OxsD64lZW7oOa_2wd4qn96DPKEPTTl30ss9ZKDbQDhPcIrs2GqhaN4nIwNbwXi8b2qLMiHRcBuck0kgyS9H8bBJ8mT0sLFEgBVBNJU6wfJGDZPyDI' );


// $ids=json_encode($registrationIds);
 #prep the bundle
     $msg = array
          (
		'body' 	=> 'auction started',
		'title'	=> $car_name1,
             	'icon'	=> 'myicon',/*Default Icon*/
              	'sound' => 'mySound'/*Default sound*/
          );
	$fields = array
			(
				'registration_ids'		=> $rows,
				'notification'	=> $msg
			);
	
	
	$headers = array
			(
				'Authorization: key=' . API_ACCESS_KEY,
				'Content-Type: application/json'
			);
#Send Reponse To FireBase Server	
		$ch = curl_init();
		curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
		curl_setopt( $ch,CURLOPT_POST, true );
		curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
		curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
		curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
		$result = curl_exec($ch );
		curl_close( $ch );
#Echo Result Of FireBase Server

 echo $result;
?>