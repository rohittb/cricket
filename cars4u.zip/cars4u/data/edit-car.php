<?php
include('../header.php');
 $car_id =$_REQUEST['car_id']; 
$sql = "select * from ca_cars where id='$car_id'";
$result = $connection->query($sql);
$row = $result->fetch_assoc();
?>
<div class="container-fluid">
    <section class="container">
		<div class="container-page">
	
			<div class="col-md-6">
			<form id ="update_car1" action = "../data/car_update.php" method = "get">
				<h3 class="dark-grey">Registration</h3>
				<div class="col-md-12">
    <div class="form-group">
        <label>car main Image</label>
        <div class="input-group">
            <span class="input-group-btn">
                <span class="btn btn-default btn-file">
                    Browse… <input type="file" id="imgInp" name = "profile_img">
                </span>
            </span>
            <input type="text" class="form-control" readonly>
            <input type="hidden" class="form-control" name = "profile_image_val" value="<?php echo $row['car_profile_img']; ?>">
            <input type="hidden" class="form-control" name = "signature_image_val" value="<?php echo $row['signature_image_url']; ?>">
            <input type="hidden" class="form-control" name = "id" value="<?php echo $row['id']; ?>">
            <input type="hidden" class="form-control" name = "car_id" value="<?php echo $row['car_id']; ?>">
        </div>
		
        <img id='img-upload' src="<?php echo $row['car_profile_img']; ?>" />
    </div>
</div>	
				<div class="form-group col-lg-6">
					<label>Vehicle Make</label>
					<input type="text" name="car_name" class="form-control" id="car_name" value="<?php echo $row['car_name']; ?>" required= "required">
				</div>
				
				<div class="form-group col-lg-6">
					<label>Car Registration</label>
					<input type="text" name="car_reg" class="form-control" id="car_reg" value="<?php echo $row['registration']; ?>" required= "required">
				</div>
				
				<div class="form-group col-lg-6">
					<label>Odometer Reading</label>
					<input type="text" name="kms" class="form-control" id="kms" value="<?php echo $row['car_kms']; ?>" required= "required">
				</div>
								
				<div class="form-group col-lg-6">
					<label>Model</label>
					<input type="text" name="model" class="form-control" id="model" value="<?php echo $row['car_model']; ?>" required= "required">
				</div>
				<div class="form-group col-lg-6">
					<label>Year</label>
					<input type="text" name="year" class="form-control" id="year" value="<?php echo $row['car_model_year']; ?>" required= "required">
				</div>	
				<div class="form-group col-lg-6">
					<label>color</label>
					<input type="text" name="color" class="form-control" id="color" value="<?php echo $row['color']; ?>" required= "required">
				</div>
<div class="form-group col-lg-6">
					<label>2nd Key</label>
					<input type="text" name="second_key" class="form-control" id="second_key" value="<?php echo $row['second_key']; ?>" required= "required">
				</div>	
<div class="form-group col-lg-6">
					<label>Insurance</label>
					<input type="text" name="insurance" class="form-control" id="insurance" value="<?php echo $row['insurance']; ?>" required= "required">
				</div>	
<div class="form-group col-lg-12">
					<label>Owner Serial</label>
					<input type="text" name="serial" class="form-control" id="serial" value="<?php echo $row['owner_serial']; ?>" required= "required">
				</div>					
<div class="form-group col-lg-6">
					<label>Fuel Type</label>
					<div>
					<select id = "car_varriant" name ="car_varriant" required>
					<option value = "Petrol" <?php if($row['fuel_type']=='Petrol') { echo 'selected= "selected"'; }?>>Petrol</option>
					<option value = "Diesel" <?php if($row['fuel_type']=='Diesel') { echo 'selected= "selected"'; }?>>Diesel</option>
					<option value = "Cng & Petrol" <?php if($row['fuel_type']=='Cng & Petrol') { echo 'selected= "selected"'; }?>>Cng & Petrol</option>
					
					</select>
				</div>				
				</div>	
<div class="form-group col-lg-6">
					<label>Transmission</label>
					<div>
					<select id = "transmission" name ="transmission" required>
					<option value = "automatic" <?php if($row['transmission']=='automatic') { echo 'selected= "selected"'; }?>>Automatic</option>
					<option value = "Manual" <?php if($row['transmission']=='Manual') { echo 'selected= "selected"'; }?>>Manual</option>
</select>
				</div>				
				</div>					
		<div class="form-group col-lg-6">
		
					<label>Wheel Cover</label>
					<div>
					<select id = "wheel_cover" name = "wheel_cover" required>
					<option value = "yes"<?php if($row['wheel_cover']=='yes') { echo 'selected= "selected"'; }?>>Yes</option>
					<option value = "no" <?php if($row['wheel_cover']=='no') { echo 'selected= "selected"'; }?>>No</option>
					
					
					</select>
				</div>
				</div>
				<div class="form-group col-lg-6">
					<label>Music Player</label>
					<div>
					<select id = "music_player" name = "music_player" required>
					<option value = "yes" <?php if($row['music_player']=='yes') { echo 'selected= "selected"'; }?>>Yes</option>
					<option value = "no" <?php if($row['wheel_cover']=='no') { echo 'selected= "selected"'; }?>>No</option>
					
					
					</select>
					
					
					</div>
				</div>	
			<div class="form-group col-lg-6">
					<label>Tool Kit</label>
					<div>
					<select id = "tool_kit" name = "tool_kit" required>
					<option value = "yes" <?php if($row['tool_kit']=='yes') { echo 'selected= "selected"'; }?>>Yes</option>
					<option value = "no" <?php if($row['tool_kit']=='no') { echo 'selected= "selected"'; }?>>No</option>
					
					
					</select>
					
					
					</div>
				</div>	
				<div class="form-group col-lg-6">
					<label>Jack</label>
					<div>
					<select id = "jack" name = "jack" required>
					<option value = "yes" <?php if($row['jack']=='yes') { echo 'selected= "selected"'; }?>>Yes</option>
					<option value = "no" <?php if($row['jack']=='no') { echo 'selected= "selected"'; }?>>No</option>
					
					
					</select>
					
					
					</div>
				</div>	
				<div class="form-group col-lg-6">
					<label>Sun Roof</label>
					<div>
					<select id = "sunroof" name = "sunroof" required>
					<option value = "yes" <?php if($row['sun_roof']=='yes') { echo 'selected= "selected"'; }?>>Yes</option>
					<option value = "no" <?php if($row['sun_roof']=='no') { echo 'selected= "selected"'; }?>>No</option>
					
					
					</select>
					
					
					</div>
				</div>
<div class="form-group col-lg-6">
					<label>Fog Lamp</label>
					<div>
					<select id = "fog_lamp" name = "fog_lamp" required>
					<option value = "yes" <?php if($row['fog_lamp']=='yes') { echo 'selected= "selected"'; }?>>Yes</option>
					<option value = "no" <?php if($row['fog_lamp']=='no') { echo 'selected= "selected"'; }?>>No</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-12">
					<label>Seat Covers</label>
					<div>
					<select id = "seat_covers" name = "seat_covers" required>
					<option value = "yes" <?php if($row['seat_covers']=='yes') { echo 'selected= "selected"'; }?>>Yes</option>
					<option value = "no" <?php if($row['seat_covers']=='no') { echo 'selected= "selected"'; }?>>No</option>
					
					
					</select>
					
					
					</div>
				</div>	
				<div class="form-group col-lg-12">
<h4 style = "text-align:center;">INSPECTION CHECKLIST</h4>	
</div>
<h6 style = "text-align:center;">Unusual Noises:</h6>	
			<div class="form-group col-lg-12">
					<label>Noises:</label>
					<div>
					<select id = "noise" name = "noise" required>
					<option value = "ok" <?php if($row['noises']=='yes') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php if($row['noises']=='no') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
				<h6 style = "text-align:center;">Gauges</h6>
				<div class="form-group col-lg-6">
					<label>fuel:</label>
					<div>
					<select id = "fuel" name = "fuel" required>
					<option value = "ok" <?php if($row['fuel']=='yes') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php if($row['fuel']=='no') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Temprature:</label>
					<div>
					<select id = "temprature" name = "temprature" required>
					<option value = "ok" <?php if($row['temprature']=='ok') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php if($row['temprature']=='need attention') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-12">
					<label>Dashboard Warning Light:</label>
					<div>
					<select id = "dashboard_warning_light" name = "dashboard_warning_light" required>
					<option value = "ok" <?php if($row['dashboard_warning_light']=='ok') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php if($row['dashboard_warning_light']=='need attention') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<h6 style = "text-align:center;">Lights:</h6>	
<div class="form-group col-lg-6">
					<label>Headlight:</label>
					<div>
					<select id = "headlight" name = "headlight" required>
					<option value = "ok" <?php if($row['headlight']=='ok') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php if($row['headlight']=='need attention') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>		
<div class="form-group col-lg-6">
					<label>Break light:</label>
					<div>
					<select id = "break_light" name = "break_light" required>
					<option value = "ok" <?php if($row['break_light']=='ok') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php if($row['break_light']=='need attention') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Parking light:</label>
					<div>
					<select id = "park_light" name = "park_light" required>
					<option value = "ok" <?php if($row['parking_light']=='ok') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php if($row['parking_light']=='need attention') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Turn Signals:</label>
					<div>
					<select id = "turn_signals" name = "turn_signals" required>
					<option value = "ok" <?php if($row['turn_signals']=='ok') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php if($row['turn_signals']=='need attention') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
		<!--	<div class="form-group col-lg-12">
					<label>Hazzard Lights:</label>
					<div>
					<select id = "hazzard_light" name = "hazzard_light" required>
					<option value = "ok" <?php //if($row['hazzard_light']=='ok') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php// if($row['hazzard_light']=='need attention') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>-->
<h6 style = "text-align:center;">Others:</h6>	
<div class="form-group col-lg-6">
					<label>Windshield Wipers:</label>
					<div>
					<select id = "Windshield_wipers" name = "Windshield_wipers" required>
					<option value = "ok" <?php if($row['windshield_wipers']=='ok') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php if($row['windshield_wipers']=='need attention') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>		
<div class="form-group col-lg-6">
					<label>Fans and Defroster:</label>
					<div>
					<select id = "fans_defroster" name = "fans_defroster" required>
					<option value = "ok" <?php if($row['fans_defosters']=='ok') { echo 'selected= "selected"'; }?> >ok</option>
					<option value = "need attention" <?php if($row['fans_defosters']=='need attention') { echo 'selected= "selected"'; }?> >Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Brakes:</label>
					<div>
					<select id = "brakes" name = "brakes" required>
					<option value = "ok" <?php if($row['brakes']=='ok') { echo 'selected= "selected"'; }?> >ok</option>
					<option value = "need attention" <?php if($row['brakes']=='need attention') { echo 'selected= "selected"'; }?> >Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<!--<div class="form-group col-lg-6">
					<label>Parking Break:</label>
					<div>
					<select id = "parking_break" name = "parking_break" required>
					<option value = "ok" <?php //if($row['parking_brakes']=='ok') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php //if($row['parking_brakes']=='need attention') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	-->
			<div class="form-group col-lg-6">
					<label>Mirrors:</label>
					<div>
					<select id = "mirrors" name = "mirrors" required>
					<option value = "ok" <?php if($row['mirrors']=='ok') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php if($row['mirrors']=='need attention') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Horn:</label>
					<div>
					<select id = "horn" name = "horn" required>
					<option value = "ok" <?php if($row['horn']=='ok') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php if($row['horn']=='need attention') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Exhaust System:</label>
					<div>
					<select id = "exhaust_system" name = "exhaust_system" required>
					<option value = "ok" <?php if($row['exhaust_system']=='ok') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php if($row['exhaust_system']=='need attention') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Suspension:</label>
					<div>
					<select id = "Suspension" name = "Suspension" required>
					<option value = "ok" <?php if($row['suspension']=='ok') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php if($row['suspension']=='need attention') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>
<div class="form-group col-lg-6">
					<label>Steering:</label>
					<div>
					<select id = "steering" name = "Steering" required>
					<option value = "ok" <?php if($row['steering']=='ok') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php if($row['steering']=='need attention') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>
<div class="form-group col-lg-12">
					<label>Steering controls:</label>
					<div>
					<select id = "steering_cntrls" name = "steering_cntrls" required>
					<option value = "ok" <?php if($row['steering_cntrls']=='ok') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php if($row['steering_cntrls']=='need attention') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
				<h6 style = "text-align:center;">Tyres:</h6>
				<div class="form-group col-lg-6">
					<label>Front Tyres:</label>
					<div>
					<select id = "infaltion" name = "infaltion" required>
					<option value = "20%" <?php if($row['proper_inflation']=='20%') { echo 'selected= "selected"'; }?>>20%</option>
					<option value = "40%" <?php if($row['proper_inflation']=='40%') { echo 'selected= "selected"'; }?>>40%</option>					<option value = "60%" <?php if($row['proper_inflation']=='60%') { echo 'selected= "selected"'; }?>>60%</option>					<option value = "80%" <?php if($row['proper_inflation']=='80%') { echo 'selected= "selected"'; }?>>80%</option>					<option value = "100%" <?php if($row['proper_inflation']=='100%') { echo 'selected= "selected"'; }?>>100%</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Rear Tyre:</label>
					<div>
					<select id = "adequate" name = "adequate" required>
					<option value = "20" <?php if($row['adequate']=='20%') { echo 'selected= "selected"'; }?>>20%</option>					<option value = "40" <?php if($row['adequate']=='40%') { echo 'selected= "selected"'; }?>>40%</option>					<option value = "60%" <?php if($row['adequate']=='60%') { echo 'selected= "selected"'; }?>>60%</option>					<option value = "80%" <?php if($row['adequate']=='80%') { echo 'selected= "selected"'; }?>>80%</option>					<option value = "100" <?php if($row['adequate']=='100%') { echo 'selected= "selected"'; }?>>100</option>
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-12">
					<label>Spare Tyre	:</label>
					<div>
					<select id = "spare_inflated" name = "spare_inflated" required>
					<option value = "20%" <?php if($row['spare_inflated']=='20%') { echo 'selected= "selected"'; }?>>20%</option>					<option value = "40%" <?php if($row['spare_inflated']=='40%') { echo 'selected= "selected"'; }?>>40%</option>					<option value = "60%" <?php if($row['spare_inflated']=='60%') { echo 'selected= "selected"'; }?>>60%</option>					<option value = "80%" <?php if($row['spare_inflated']=='80%') { echo 'selected= "selected"'; }?>>80%</option>					<option value = "100%" <?php if($row['spare_inflated']=='100%') { echo 'selected= "selected"'; }?>>100%</option>
					
					
					</select>
					
					
					</div>
				</div>	
				<h6 style = "text-align:center;">Leaks:</h6>
				<div class="form-group col-lg-6">
					<label>Oil:</label>
					<div>
					<select id = "oil" name = "oil" required>
					<option value = "ok" <?php if($row['oil']=='ok') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php if($row['oil']=='need attention') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Other:</label>
					<div>
					<select id = "leaks_other" name = "leaks_other" required>
					<option value = "ok" <?php if($row['other_leaks']=='ok') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php if($row['other_leaks']=='need attention') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
					<h6 style = "text-align:center;">Safety Equipment:</h6>
				<div class="form-group col-lg-6">
					<label>First Aid Kit:</label>
					<div>
					<select id = "first_aid" name = "first_aid" required>
					<option value = "ok" <?php if($row['first_aid_kit']=='ok') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php if($row['first_aid_kit']=='need attention') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Seat Belts:</label>
					<div>
					<select id = "seat_belts" name = "seat_belts" required>
					<option value = "ok" <?php if($row['seat_belts']=='ok') { echo 'selected= "selected"'; }?>>ok</option>
					<option value = "need attention" <?php if($row['seat_belts']=='need attention') { echo 'selected= "selected"'; }?>>Needs Attention</option>
					
					
					</select>
					
					
					</div>
				</div>	
				<div class="form-group col-lg-6">
					<label>Airbag:</label>
					<div>
					<select id = "airbag" name = "airbag" required>
					<option value = "yes" <?php if($row['airbag']=='yes') { echo 'selected= "selected"'; }?>>yes</option>
					<option value = "no" <?php if($row['airbag']=='no') { echo 'selected= "selected"'; }?>>No</option>
					
					
					</select>
					
					
					</div>
				</div>	
<div class="form-group col-lg-6">
					<label>Abs Break:</label>
					<div>
					<select id = "abs_break" name = "absbreak" required>
					<option value = "Yes" <?php if($row['absbreak']=='Yes') { echo 'selected= "selected"'; }?>>Yes</option>
					<option value = "No" <?php if($row['absbreak']=='No') { echo 'selected= "selected"'; }?>>No</option>
					
					
					</select>
					
					
					</div>
				</div>
<h6 style = "text-align:center;">Air conditioner:</h6>
				<div class="form-group col-lg-6">
					<label>Ac:</label>
					<div>
					<select id = "ac" name = "ac" required>
					<option value = "automatic" <?php if($row['ac_cond']=='automatic') { echo 'selected= "selected"'; }?>>automatic</option>
					<option value = "manual" <?php if($row['ac_cond']=='manual') { echo 'selected= "selected"'; }?>>manual</option>
					
					
					</select>
					
					
					</div>
				</div>	<div class="form-group col-lg-6">					
				<label>Ac Condition:</label>				
				<div>					
				<select id = "ac_cond" name = "ac_cond" required>					
				<option value = "ok" <?php if($row['ac_cond']=='ok') { echo 'selected= "selected"'; }?>>ok</option>					
				<option value = "needs attention" <?php if($row['ac_cond']=='needs attention') { echo 'selected= "selected"'; }?>>needs attention</option>															
				</select>															
				</div>				
				</div>	
				<div class="form-group col-lg-12">
<h4 style = "text-align:center;">Exterior</h4>	

</div>			
<div class="form-group col-lg-6">
					<label>Boonet:</label>
					<div>
					<select id = "boonet" name = "boonet" required>
					<option value = "original" <?php if($row['boonet']=='original') { echo 'selected= "selected"'; }?>>original</option>
					<option value = "painted" <?php if($row['boonet']=='painted') { echo 'selected= "selected"'; }?>>painted</option>
					<option value = "changed" <?php if($row['boonet']=='changed') { echo 'selected= "selected"'; }?>>changed</option>
					<option value = "need reparing" <?php if($row['boonet']=='need repairing') { echo 'selected= "selected"'; }?>>need reparing</option>
					
					
					</select>
					
					
					</div>
				</div>
				<div class="form-group col-lg-6">
					<label>Right Fander:</label>
					<div>
					<select id = "right_fander" name = "right_fander" required>
					<option value = "original" <?php if($row['right_fander']=='original') { echo 'selected= "selected"'; }?>>original</option>
					<option value = "painted" <?php if($row['right_fander']=='painted') { echo 'selected= "selected"'; }?>>painted</option>
					<option value = "changed" <?php if($row['right_fander']=='changed') { echo 'selected= "selected"'; }?>>changed</option>
					<option value = "need reparing" <?php if($row['right_fander']=='need repairing') { echo 'selected= "selected"'; }?>>need reparing</option>
					
					
					</select>
					
					
					</div>
				</div>
				<div class="form-group col-lg-6">
					<label>Left Fander:</label>
					<div>
					<select id = "left_fander" name = "left_fander" required>
					<option value = "original" <?php if($row['left_fander']=='original') { echo 'selected= "selected"'; }?>>original</option>
					<option value = "painted" <?php if($row['left_fander']=='painted') { echo 'selected= "selected"'; }?>>painted</option>
					<option value = "changed" <?php if($row['left_fander']=='changed') { echo 'selected= "selected"'; }?>>changed</option>
					<option value = "need reparing" <?php if($row['left_fander']=='need repairing') { echo 'selected= "selected"'; }?>>need reparing</option>
					
					
					</select>
					
					
					</div>
					
				</div>
					<div class="form-group col-lg-6">
					<label>Front Right Window:</label>
					<div>
					<select id = "front_rit_window" name = "front_rit_window" required>
					<option value = "original" <?php if($row['front_right_window']=='original') { echo 'selected= "selected"'; }?> >original</option>
					<option value = "painted" <?php if($row['front_right_window']=='painted') { echo 'selected= "selected"'; }?>>painted</option>
					<option value = "changed" <?php if($row['front_right_window']=='changed') { echo 'selected= "selected"'; }?>>changed</option>
					<option value = "need reparing" <?php if($row['front_right_window']=='need repairing') { echo 'selected= "selected"'; }?>>need reparing</option>
					
					
					</select>
					
					
					</div>
					
				</div>
				<div class="form-group col-lg-6">
					<label>Front Left Window:</label>
					<div>
					<select id = "front_left_window" name = "front_left_window" required>
					<option value = "original" <?php if($row['front_left_window']=='original') { echo 'selected= "selected"'; }?>>original</option>
					<option value = "painted" <?php if($row['front_left_window']=='painted') { echo 'selected= "selected"'; }?>>painted</option
					<option value = "changed" <?php if($row['front_left_window']=='changed') { echo 'selected= "selected"'; }?>>changed</option>
					<option value = "need reparing" <?php if($row['front_left_window']=='need repairing') { echo 'selected= "selected"'; }?>>need reparing</option>
					
					
					</select>
					
					
					</div>
					
				</div>
				<div class="form-group col-lg-6">
					<label>Rear right Window:</label>
					<div>
					<select id = "rear_right_window" name = "rear_right_window" required>
					<option value = "original" <?php if($row['rear_right_window']=='original') { echo 'selected= "selected"'; }?>>original</option>
					<option value = "painted" <?php if($row['rear_right_window']=='original') { echo 'selected= "selected"'; }?>>painted</option>
					<option value = "changed" <?php if($row['rear_right_window']=='painted') { echo 'selected= "selected"'; }?>>changed</option>
					<option value = "need reparing" <?php if($row['rear_right_window']=='need repairing') { echo 'selected= "selected"'; }?>>need reparing</option>
					
					
					</select>
					
					
					</div>
					
				</div>
				<div class="form-group col-lg-6">
					<label>Rear Left Window:</label>
					<div>
					<select id = "rear_left_window" name = "rear_left_window" required>
					<option value = "original" <?php if($row['rear_left_window']=='original') { echo 'selected= "selected"'; }?>>original</option>
					<option value = "painted" <?php if($row['rear_left_window']=='painted') { echo 'selected= "selected"'; }?>>painted</option>
					<option value = "changed" <?php if($row['rear_left_window']=='changed') { echo 'selected= "selected"'; }?>>changed</option>
					<option value = "need reparing" <?php if($row['rear_left_window']=='need repairing') { echo 'selected= "selected"'; }?>>need reparing</option>
					
					
					</select>
					
					
					</div>
					
				</div>
				<div class="form-group col-lg-6">
					<label>Right Quarter Panel:</label>
					<div>
					<select id = "right_quarter_panel" name = "right_quarter_panel" required>
					<option value = "original" <?php if($row['right_quarter_panel']=='original') { echo 'selected= "selected"'; }?>>original</option>
					<option value = "painted" <?php if($row['right_quarter_panel']=='painted') { echo 'selected= "selected"'; }?>>painted</option>
					
					<option value = "changed" <?php if($row['right_quarter_panel']=='changed') { echo 'selected= "selected"'; }?>>changed</option>
					<option value = "need reparing" <?php if($row['right_quarter_panel']=='need attention') { echo 'selected= "selected"'; }?>>need reparing</option>
					
					
					</select>
					
					
					</div>
					
				</div>
				<div class="form-group col-lg-6">
					<label>Left Quarter Panel:</label>
					<div>
					<select id = "left_quarter_panel" name = "left_quarter_panel" required>
					<option value = "original" <?php if($row['left_quarter_panel']=='original') { echo 'selected= "selected"'; }?>>original</option>
					<option value = "painted" <?php if($row['left_quarter_panel']=='painted') { echo 'selected= "selected"'; }?>>painted</option>
					<option value = "changed" <?php if($row['left_quarter_panel']=='changed') { echo 'selected= "selected"'; }?>>changed</option>
					<option value = "need reparing" <?php if($row['left_quarter_panel']=='need repairing') { echo 'selected= "selected"'; }?>>need reparing</option>
					
					
					</select>
					
					
					</div>
					
				</div>
				<div class="form-group col-lg-6">
					<label>Roof:</label>
					<div>
					<select id = "roof" name = "roof" required>
					<option value = "original" <?php if($row['roof']=='original') { echo 'selected= "selected"'; }?>>original</option>
					<option value = "painted" <?php if($row['roof']=='painted') { echo 'selected= "selected"'; }?>>painted</option>
					<option value = "changed" <?php if($row['roof']=='changed') { echo 'selected= "selected"'; }?>>changed</option>
					<option value = "need reparing" <?php if($row['roof']=='need repairing') { echo 'selected= "selected"'; }?>>need reparing</option>
					
					
					</select>
					
					
					</div>
					
				</div>
				<div class="form-group col-lg-6">
					<label>Boot:</label>
					<div>
					<select id = "boot" name = "boot" required>
					<option value = "original" <?php if($row['boot']=='original') { echo 'selected= "selected"'; }?>>original</option>
					<option value = "painted" <?php if($row['boot']=='painted') { echo 'selected= "selected"'; }?>>painted</option>
					<option value = "changed" <?php if($row['boot']=='changed') { echo 'selected= "selected"'; }?>>changed</option>
					<option value = "need reparing" <?php if($row['boot']=='need repairing') { echo 'selected= "selected"'; }?>>need reparing</option>
					
					
					</select>
					
					
					</div>
					
				</div>
				<div class="form-group col-lg-6">
					<label>Alloy wheel:</label>
					<div>
					<select id = "alloy_wheel" name = "alloy_wheel" required>
					<option value = "Yes" <?php if($row['alloy_wheel']=='Yes') { echo 'selected= "selected"'; }?>>Yes</option>
					<option value = "No" <?php if($row['alloy_wheel']=='No') { echo 'selected= "selected"'; }?>>No</option>
					</select>
					</div>
			 </div>
					<div class="form-group col-lg-6">
					<label>Front Bumper</label>
					<input type="text" name="front_bumper" class="form-control" id="front_bumper" value="<?php echo $row['front_bumper']; ?>" required= "required">
				</div>
				<div class="form-group col-lg-6">
					<label>Rear Bumper</label>
					<input type="text" name="rear_bumper" class="form-control" id="rear_bumper" value="<?php echo $row['rear_bumper']; ?>" required= "required">
				</div>
				<div class="form-group col-lg-12">
					<label>Exterior comment:</label>
					<div>
					<input name = "exterior_comments" value="<?php echo $row['ext_comment']; ?>"> </input> 
					
		
					
					
					</div>
					
				</div>
				<div class="form-group col-lg-12">
				<h4 style = "text-align:center;">Interior</h4>
				
				</div>
				<div class="form-group col-lg-6">
				<label>Dashboard:</label>	
				<div>				
				<select id = "dashboard" name = "dashboard" required>	
				<option value = "ok" <?php if($row['int_dashboard']=='ok') { echo 'selected= "selected"'; }?>>ok</option>
				<option value = "needs attention" <?php if($row['int_dashboard']=='needs attention') { echo 'selected= "selected"'; }?>>needs attention</option>	
				</select>				
				</div>				
				</div>	
			<div class="form-group col-lg-6">				
			<label>Steering:</label>					
			<div>					
			<select id = "int_steering" name = "int_steering" required>				
			<option value = "ok" <?php if($row['int_steeering']=='ok') { echo 'selected= "selected"'; }?>>ok</option>					
			<option value = "needs attention" <?php if($row['int_steeering']=='needs attention') { echo 'selected= "selected"'; }?>>needs attention</option>	
			
			</select>					
			</div>				
			</div>	
				<div class="form-group col-lg-6">					
				<label>Gear Console:</label>					
				<div>					
				<select id = "gear_console" name = "gear_console" required>				
				<option value = "ok" <?php if($row['gear_console']=='ok') { echo 'selected= "selected"'; }?>>ok</option>					
				<option value = "needs attention" <?php if($row['gear_console']=='needs attention') { echo 'selected= "selected"'; }?>>needs attention</option>	
				</select>					
				</div>				
				</div>	
				<div class="form-group col-lg-6">				
				<label>Hand Break:</label>			
				<div>				
				<select id = "hand_break" name = "hand_break" required>	
				<option value = "ok" <?php if($row['hand_break']=='ok') { echo 'selected= "selected"'; }?>>ok</option>					
				<option value = "needs attention" <?php if($row['hand_break']=='need attention') { echo 'selected= "selected"'; }?>>needs attention</option>	
				</select>					
				</div>				
				</div>	
				<div class="form-group col-lg-6">					
				<label>Seats:</label>					
				<div>					
				<select id = "seats" name = "seats" required>		
				<option value = "ok" <?php if($row['seats']=='ok') { echo 'selected= "selected"'; }?>>ok</option>			
				<option value = "needs attention" <?php if($row['seats']=='needs attention') { echo 'selected= "selected"'; }?>>needs attention</option>
				</select>					
				</div>				
				</div>	
				<div class="form-group col-lg-12">
					<label>Interior comments</label>
<input name = "int_comments" value="<?php echo $row['int_comments']; ?>"> </input> 
					
				</div>
				<div class="form-group col-lg-12">
<h4 style="text-align:center;">Auction:</h4>
</div>
				<div class="form-group col-lg-6">
					<label>Price:</label>
					<input type="text" name="price" class="form-control" id="price" value="<?php echo $row['price']; ?>" required= "required">
				</div>
				
				<input type = "hidden" name =  "gallery_url" id="gallery_url" value="" />
				
				<div class="form-group col-lg-12">
<h4 style="text-align:center;">Car gallery</h4>
</div>
<div class="form-group col-lg-12">
<input type="file" id="files" name="files[]" multiple />
 <?php if(!empty($row['car_gallery_image']))
{
$urls = $row['car_gallery_image']; 
$ex = explode(",",$urls);
foreach($ex as $exe)
{ ?>
<span class="thumbnail col-md-4">
<img class="imageThumb1" src="<?php echo $exe; ?>" />	
<a class="close"></a>
</span>
<?php }


// foreach($urls as $url)
// {
	// echo $url;
// }	
}
?>
</div>	
				<div class="form-group col-lg-12">
<h4 style="text-align:center;">Signature</h4>
</div>
				<div class="form-group col-lg-12">
       
        <div class="input-group">
            <span class="input-group-btn">
                <span class="btn btn-default btn-file">
                    Browse… <input type="file" id="signature" name = "signature">
                </span>
            </span>
            <input type="text" class="form-control" readonly>
        </div>
		
        <img id='img-signature' style="width:20%" src="<?php echo $row['signature_image_url']; ?>"/>
		
    </div>
				<div class="form-group col-lg-12">
<h4 style="text-align:center;">Condition of Vehicle Following the Inspection:</h4>
</div>
<div class="form-group col-lg-6">
					<label></label>
					<div>
					<select id = "overall_condition" name = "overall_condition" required>
					<option value = "acceptable" <?php if($row['folowing_inception_condition']=='acceptable') { echo 'selected= "selected"'; }?>>acceptable</option>
					<option value = "required attention" <?php if($row['folowing_inception_condition']=='required attention') { echo 'selected= "selected"'; }?>>Required Attention</option>
					<option value = "immediate attention" <?php if($row['folowing_inception_condition']=='immediate attention') { echo 'selected= "selected"'; }?>>Immediate Attention</option>
					
					
					
					</select>
					
					
					</div>
					
				</div>
				<div class="form-group col-lg-6">
					<label>Rating:</label>
					<input type="text" name="rating" class="form-control" id="rating" value="<?php echo $row['rating']; ?>" required= "required">
				</div>
				<div class="form-group col-lg-12">
					<button type="submit" class="btn btn-default" id="update_car">Update Car</button>
					</div>
			</div>
			</form>
		</div>
		</div>		
	</section>
	<i id = "loader" class="fa fa-spinner fa-spin" style="font-size:24px;display:none;"></i>
		<div id = "result" style = "display:none;margin:0 0 0 200px;font-size:17px;color:red;">
</div>
<script>
$(".thumbnail").on("click", function(event) {
	
    $(this).remove();
});

/***************** get cars values *******************/
$("#update_car1").on("submit", function(event) {
	event.preventDefault();
	var array = [];
$(".imageThumb1").each(function() {
   
   array.push($(this).attr("src"));
});  
document.getElementById('gallery_url').value=array; 
//alert(array);
		$("#loader").show();
		
			$.ajax({
        	url: "../data/car_update.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
			success: function(data)
		    {
				$("#loader").hide();
			$("#result").show();
			$("#result").html(data);
			 
			//alert(data);
		    },
		  	error: function() 
	    	{
				
	    	} 	        
	   });
});
</script>
<?php  
include('../footer.php');
?>
<style>
.btn-file {
    position: relative;
    overflow: hidden;
}
.btn-file input[type=file] {
    position: absolute;
    top: 0;
    right: 0;
    min-width: 100%;
    min-height: 100%;
    font-size: 100px;
    text-align: right;
    filter: alpha(opacity=0);
    opacity: 0;
    outline: none;
    background: white;
    cursor: inherit;
    display: block;
}

#img-upload{
    width: 50%;
}
input[type="file"] {
 
 display:block;
}
.imageThumb {
 max-height: 75px;
 border: 2px solid;
 margin: 10px 10px 0 0;
 padding: 1px;
 width:20%;
 }
 .imageThumb1
 {
	 width:20%;
 }
.thumbnail {
    position: relative;
    width:20%;
    height:92px;
}

.thumbnail img {
    width:100%;
    height:92px;
}

.close {
    display: block;
    position: absolute;
    width:30px;
    height:30px;
    top: 2px;
    right: 2px;
    background: url(http://icons.iconarchive.com/icons/kyo-tux/delikate/512/Close-icon.png);
    background-size: 100% 100%;
    background-repeat: no-repeat;
    }

</style>
