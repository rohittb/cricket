<?php
include('conn.php');
$user_id = $_REQUEST['user_id'];
$user_approve = $_REQUEST['user_approve'];
if($user_approve == "0")
{
 $sql = "UPDATE ca_user SET user_approve =1 WHERE user_id=$user_id";
}
else{
$sql = "UPDATE ca_user SET user_approve =0 WHERE user_id=$user_id";
}
$result=$connection->query($sql);
if($result)
{
	echo "updated";
}
else
{
	echo "not updated";
}
?>