<?php
include('conn.php');
 $username = $_REQUEST['name']; 
$password = $_REQUEST['password'];

 $sql="SELECT * FROM ca_user WHERE email='$username' and password='$password' and role = 'admin'";
 $result = $connection->query($sql);
 $row_count=  $result->num_rows;
if ($result==false)
{
    die(mysql_error());
}

// If result matched $username and $password, table row must be 1 row
if ($row_count==1) {
  
  echo "login";
  session_start();
     $_SESSION['UserID'] = $username;
} else {
    echo "Unsuccessful! ";
}


?>