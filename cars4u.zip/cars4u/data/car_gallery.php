<?php
 $connection =  mysqli_connect("localhost", "cars_bid", "uUw3zbis-s(N","cars_bid");
 //return $connection;
  $id = $_REQUEST['car_id'];
 $qry = "SELECT car_gallery_image FROM ca_cars WHERE id='$id'";
			 $result = $connection->query($qry);
			 $row = $result->fetch_object();
$data = $row->car_gallery_image;
			 $arr['image'] = explode(",",$data);
			$count= count($arr['image'] );
			
			?>
			<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">

<div class="row">
<div class="col-md-2"></div>
<div class="col-md-8">
<div class="row">
<?php
for($i=0;$i<=$count;$i++)
{ ?>
<div class="row">
<img src="<?php echo $arr['image'][$i]; ?>" style="width:100%; ">
</div>
		
<?php } ?>


</div>
<div class="col-md-2"></div>
</div>

</div>
</body>
</html>
