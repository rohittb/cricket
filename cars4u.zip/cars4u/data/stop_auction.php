<?php
include('conn.php');
$car_id = $_REQUEST['car_id'];
$qry ="select car_id from ca_cars where id=$car_id";
$result1=$connection->query($qry);
$row2 = $result1->fetch_object();
$id = $row2->car_id;
$qry1 = "delete from car_auction where car_id=$id";
$result2=$connection->query($qry1);
//$user_approve = $_REQUEST['user_approve'];
$sql = "UPDATE ca_cars SET start_auction =0,auction_date='' WHERE id=$car_id";

$result=$connection->query($sql);
if($result)
{
	echo "updated";
}
else
{
	echo "not updated";
}
?>