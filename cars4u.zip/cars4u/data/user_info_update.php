<?php 
include('conn.php');
$user_id = $_REQUEST['user_id']; 
$username = $_REQUEST['email']; 
$password = $_REQUEST['password'];
$pan = $_REQUEST['pan'];
$mobile = $_REQUEST['mobile'];
$location = $_REQUEST['location'];
$prefrences = $_REQUEST['prefrences'];

//$user_id = "user_".uniqid(); 
$user_approve = 0;
 $sql="UPDATE ca_user SET email = '$username',password ='$password',pan_no = '$pan',mobile_no='$mobile',location='$location',prefrences ='$prefrences' where user_id = $user_id";
$result=$connection->query($sql);
if($result)
{
	echo "inserted";
}
else
{
	echo "not";
}


?>