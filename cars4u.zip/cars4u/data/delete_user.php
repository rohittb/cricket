<?php
include('conn.php');
$user_id = $_REQUEST['user_id'];
$sql = "DELETE FROM ca_user WHERE user_id = $user_id";
$result=$connection->query($sql);
if($result)
{
	echo "deleted";
}
else
{
	echo "not deleted";
}
?>