<?php 
include('conn.php');
$username = $_REQUEST['email']; 
$password = $_REQUEST['password'];
$pan = $_REQUEST['pan'];
$mobile = $_REQUEST['mobile'];
$location = $_REQUEST['location'];
$prefrences = $_REQUEST['prefrences'];
 $user_id = "user_".uniqid(); 
$user_approve = 0;
$sql="SELECT * FROM ca_user WHERE email='$username' or mobile_no='$mobile'";
$result=$connection->query($sql);

if ($result==false)
{
    die(mysql_error());
}
$count=$result->num_rows;
// If result matched $username and $password, table row must be 1 row
if ($count>=1) {
  
  echo "exist";
 
}
else
{
 $sql="INSERT INTO ca_user (role, email,password,pan_no,mobile_no,location,prefrences,user_approve,user_main_id) VALUES('subscriber','$username','$password','$pan','$mobile','$location','$prefrences','$user_approve','$user_id')";
$result=$connection->query($sql);
if($result)
{
	echo "inserted";
}
else
{
	echo "not";
}
}

?>