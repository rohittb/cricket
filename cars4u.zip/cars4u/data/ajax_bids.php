<?php 
  include('conn.php');
  
$qry = "select car_id from ca_cars where start_auction='1'";
$result1 = $connection->query($qry);
$count=1;
while($row2 = $result1->fetch_assoc())
{
	
	$id = $row2['car_id'];
	 $sql = "SELECT ca_cars.id, ca_cars.car_name, ca_cars.car_model, ca_cars.price, car_auction.price_auction as max_bid, car_auction.user_id
FROM ca_cars
JOIN car_auction ON ca_cars.car_id = car_auction.car_id
WHERE car_auction.price_auction = (
SELECT max( price_auction )
FROM car_auction
WHERE car_id = '$id')";
$result=$connection->query($sql);
 
 $row = $result->fetch_assoc();

 //print_r($row);



?>
			<tr>
													<td class="center">
														<?php echo $count; ?>
													</td>

													<td class="center">
					<?php echo $var= $row['user_id'];
					  // $sqlqry="select mobile_no from ca_user where email='$var' ";
					  // $result=$connection->query($sqlqry);
					  // $rowqry=$result->fetch_object();
					 //  echo $rowqry->mobile_no;?>
															
														</div>
													</td>

													<td>
														<?php echo $row['car_name']." ".$row['car_model'] ;?>
													</td>
													<td><?php echo $row['price'];?></td>
													<td><?php echo $row['max_bid'];?></td>
													
												
												</tr>
<?php  $count++; }?>
