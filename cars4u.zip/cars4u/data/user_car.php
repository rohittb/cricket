<?php
include('conn.php');
$carname = $_REQUEST['car_name']; 
$kms = $_REQUEST['kms'];
$year = $_REQUEST['year'];
$model = $_REQUEST['model'];
$car_reg = $_REQUEST['car_reg'];
$car_varriant = $_REQUEST['car_varriant']; 
$color = $_REQUEST['color'];
$transmission = $_REQUEST['transmission'];
$second_key = $_REQUEST['second_key'];
$owner_serial = $_REQUEST['serial'];
$insurance = $_REQUEST['insurance'];
$wheel_cover = $_REQUEST['wheel_cover'];
$music_player = $_REQUEST['music_player'];
$tool_kit = $_REQUEST['tool_kit'];
$sun_roof = $_REQUEST['sunroof'];
$jack = $_REQUEST['jack'];
$fog_lamp = $_REQUEST['fog_lamp'];
$seat_covers = $_REQUEST['seat_covers'];
$noise = $_REQUEST['noise'];
$temprature = $_REQUEST['temprature'];
 $fuel = $_REQUEST['fuel'];
$dashboard_warning_light = $_REQUEST['dashboard_warning_light'];
$headlight = $_REQUEST['headlight'];
$break_light = $_REQUEST['break_light'];
$parking_light = $_REQUEST['park_light'];
$turn_signals = $_REQUEST['turn_signals'];

$Windshield_wipers = $_REQUEST['Windshield_wipers'];
$steering = $_REQUEST['Steering'];
$fans_defroster = $_REQUEST['fans_defroster'];
$brakes = $_REQUEST['brakes'];

$mirrors = $_REQUEST['mirrors'];
$horn = $_REQUEST['horn'];
$exhaust_system = $_REQUEST['exhaust_system'];
$suspension = $_REQUEST['Suspension'];
$infaltion = $_REQUEST['infaltion'];
$adequate = $_REQUEST['adequate'];
$spare_inflated = $_REQUEST['spare_inflated'];
$oil = $_REQUEST['oil'];
$leaks_other = $_REQUEST['leaks_other'];
$steering_cntrls = $_REQUEST['steering_cntrls'];
$first_aid = $_REQUEST['first_aid'];
$seat_belts = $_REQUEST['seat_belts'];
$airbag = $_REQUEST['airbag'];
$absbreak = $_REQUEST['absbreak'];
$ac = $_REQUEST['ac'];
$boonet = $_REQUEST['boonet'];
$right_fander = $_REQUEST['right_fander'];
$left_fander = $_REQUEST['left_fander'];
$front_rit_window = $_REQUEST['front_rit_window'];
$front_left_window = $_REQUEST['front_left_window'];
$rear_left_window = $_REQUEST['rear_left_window'];
$right_quarter_panel = $_REQUEST['right_quarter_panel'];
$left_quarter_panel = $_REQUEST['left_quarter_panel'];
$boot = $_REQUEST['boot'];
$rear_right_window = $_REQUEST['rear_right_window'];
$roof = $_REQUEST['roof'];
$alloy_wheel=$_REQUEST['alloy_wheel'];
$front_bumper = $_REQUEST['front_bumper'];
$rear_bumper = $_REQUEST['rear_bumper'];
$exterior_comments = $_REQUEST['exterior_comments'];
$dashboard = $_REQUEST['dashboard'];
$int_steering = $_REQUEST['int_steering'];
$gear_console = $_REQUEST['gear_console'];
$hand_break = $_REQUEST['hand_break'];
$seats = $_REQUEST['seats'];
$int_comments = $_REQUEST['int_comments'];
$overall_condition = $_REQUEST['overall_condition'];
$ac_cond = $_REQUEST['ac_cond'];
 $price = $_REQUEST['price'];
 $rating = $_REQUEST['rating'];
 $car_id = "car_".uniqid();
 $url =  $_SERVER['HTTP_HOST'];
 $auction_time =  $_REQUEST['auction_time'];
												$dir =  basename(__DIR__) ;
												   $base_url =  "http://go4intern.com/cars/cars4u";
$all_images = '';
if(is_array($_FILES)) {
	for ($i = 0; $i < count($_FILES['files']['name']); $i++) {
if(is_uploaded_file($_FILES['files']['tmp_name'][$i])) {
$sourcePath = $_FILES['files']['tmp_name'][$i];
$id = uniqid();
$targetPath = "images/".$id.$_FILES['files']['name'][$i];
 $image_url = $base_url."/data/images/".$id.$_FILES['files']['name'][$i];
 $image_url = trim($image_url);
$all_images .= $image_url.",";
move_uploaded_file($sourcePath,$targetPath);

}
	}
	if(is_uploaded_file($_FILES['profile_img']['tmp_name'])) {
$sourcePath1 = $_FILES['profile_img']['tmp_name'];
$id1= uniqid();
$targetPath1 = "images/".$id1.$_FILES['profile_img']['name'];
 $image_url1 = $base_url."/data/images/".$id1.$_FILES['profile_img']['name'];
 $image_url1 = trim($image_url1);
 imagejpeg($image, null, 10);
move_uploaded_file($sourcePath1,$targetPath1);
}

if(is_uploaded_file($_FILES['signature']['tmp_name'])) {
$sourcePath2 = $_FILES['signature']['tmp_name'];
$id1= uniqid();
$targetPath2 = "images/".$id1.$_FILES['signature']['name'];
$image_url2 = $base_url."/data/images/".$id1.$_FILES['signature']['name'];
$image_url2 = trim($image_url2);
move_uploaded_file($sourcePath2,$targetPath2);
}

}
  $all_images;
  $star=floor($rating);
 $fraction = $rating-$star;
  /******************** report html *****************/
  $html = '<!DOCTYPE html>
<html lang="en">
<head>
  <title>CarsForu</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  .logo
  {
  height:95px;
  width:250px;
 
  }
   .star
  {
  font-size:300%; 
  color: #ff8000;
  }
   .td
  {
  background-color:#80b3ff;
  color:white;
  font-size:20px;
  }
  .white
  {
  background-color:white;
  color:#80b3ff; 
  font-size: 20px;
  }
  </style>
</head>
<body>

<div class="container">
<center><img src="http://go4intern.com/cars/cars4u/data/car.png" class="logo"></center>


	<p><center>'; 
	
	
	for($i=0;$i<$star;$i++) { 
	
	$html.='<i class="fa fa-star" aria-hidden="true" style="color:#d4af37;font-size:35px;"></i>';
	
	}
	if($fraction=="0.5")
	{
		$html.='<i class="fa fa-star-half" aria-hidden="true" style="color:#d4af37;font-size:35px;"></i>';
	}
	
	$html.='</center></p>
  <table class="table table-bordered">
    
    <tbody>
       
	     <tr>
	     <td class="td">Vehicle make</td>
        <td >'.$carname." ".$model.  '</td>
     
     
      </tr>
	  <tr>
	     <td class="td">Car registration</td>
              <td>'.$car_reg.'</td>
     
     
      </tr>
      <tr>
        <td class="td">Odometer Reading</td>
            <td>'.$kms.'</td>
     
      </tr>
	  
      <tr>
        <td class="td">Year</td>
                <td>'.$year.'</td>
     
      </tr>
	  <tr>
        <td class="td">Color</td>
               <td>'.$color.'</td>
     
      </tr>
	  <tr>
	     <td class="td">2nd key</td>
               <td>'.$second_key.'</td>
     
     
      </tr>
	  <tr>
	     <td class="td">Insurance</td>
             <td>'.$insurance.'</td>
     
     
      </tr>
	   <tr>
	     <td class="td">Transmission</td>
             <td>'.$transmission.'</td>
     
     
      </tr>
	  <tr>
	     <td class="td">Owner Serial</td>
             <td>'.$owner_serial.'</td>
     
     
      </tr>
  <tr>
    <td colspan="2" class="heading" style = "color:yellowgreen; font-size:40px;"> Car Information</td>
       
 
      </tr>
	   <tr>
	     <td class="td">Fuel Type</td>
        <td>'.$car_varriant.'</td>
     
     
      </tr>
	  <tr>
	     <td class="td">Wheel cover</td>
              <td>'.$wheel_cover.'</td>
     
     
      </tr>
      <tr>
        <td class="td">Music player</td>
            <td >'.$music_player.'</td>
     
      </tr>
	  <tr>
        <td class="td">Tool kit</td>
              <td>'.$tool_kit.'</td>
     
      </tr>
      <tr>
        <td class="td">Jack</td>
                <td>'.$jack.'</td>
     
      </tr>
	  <tr>
        <td class="td">Sun roof</td>
               <td>'.$sun_roof.'</td>
     
      </tr>
	  <tr>
	     <td class="td">Fog Lamp</td>
               <td>'.$fog_lamp.'</td>
     
     
      </tr>
	  <tr>
	     <td class="td">Seat cover</td>
             <td>'.$seat_covers.'</td>
     
     
      </tr>
	     <tr>
	        <td colspan="2" class="heading" style = "color:yellowgreen; font-size:40px;"> Unusual Noises:</td>
     
     
     
      </tr>
      <tr>
	     <td class="td">Noises</td>
        <td>'.$noise.'</td>
     
     
      </tr>
	  <tr>
	       <td colspan="2" style = "color:yellowgreen; font-size:40px;"> Gauges</td>
           
     
     
      </tr>
      <tr>
        <td class="td">Fuel</td>
            <td>'.$fuel.'</td>
     
      </tr>
	  <tr>
        <td class="td">Temprature</td>
              <td>'.$temprature.'</td>
     
      </tr>
      <tr>
        <td class="td">Dashboard Warning Light:</td>
                <td>'.$dashboard_warning_light.'</td>
     
      </tr>
	  <tr>
      
         <td colspan="2" style = "color:yellowgreen; font-size:40px;"> Lights</td>
     
      </tr>
	  <tr>
	     <td class="td">Headlight:</td>
               <td>'.$headlight.'</td>
     
     
      </tr>
	  <tr>
	     <td class="td">Break light:</td>
             <td  >'.$break_light.'</td>
     
     
      </tr>
	  <tr>
	     <td class="td">Parking light:</td>
             <td  >'.$parking_light.'</td>
     
     
      </tr>
	  <tr>
	     <td class="td">Turn signals:</td>
             <td  >'.$turn_signals.'</td>
     
     
      </tr>
	  <tr>
	     <td class="td">Alloy Wheel:</td>
             <td>'.$alloy_wheel.'</td>
     
     
      </tr>
  <tr>
    <td colspan="2" style = "color:yellowgreen; font-size:40px;">Others</td>
       
 
      </tr>
	  <tr>
	     <td class="td">Windshield Wipers:</td>
             <td >'.$Windshield_wipers.'</td>
     
     
      </tr>
	  <tr>
	     <td class="td">Fans and Defroster:</td>
             <td >'.$fans_defroster.'</td>
     
     
      </tr>
	  <tr>
	     <td class="td">Brakes:
</td>
             <td  >'.$fans_defroster.'</td>
     
     
      </tr>

	  <tr>
	     <td class="td">Mirrors:
</td>
             <td>'.$mirrors.'</td>
     
     
      </tr>
	  <tr>
	     <td class="td">Horn:</td>
             <td >'.$horn.'</td>
     
     
      </tr>
	  <tr>
	     <td class="td">Exhaust System:
:</td>
             <td >'.$exhaust_system.'</td>
     
     
      </tr>
	  <tr>
	     <td class="td">Suspension:</td>
             <td >'.$suspension.'</td>
     
     
      </tr>
	  <tr>
	     <td class="td">Steering:</td>
          <td  >'.$steering.'</td>
     
     
      </tr>
	  <tr>
	     <td class="td">Steering controls:
</td>
          <td  >'.$suspension.'</td>
     
     
      </tr>
	    <tr>
	       <td colspan="2" class="cols" style = "color:yellowgreen; font-size:40px;"> Tyres:</td>
           
     
     
      </tr>
      <tr>
        <td class="td">Front Tyres</td>
            <td>'.$infaltion.'</td>
     
      </tr>
	  <tr>
        <td class="td">Rear Tyre:
</td>
              <td  >'.$adequate.'</td>
     
      </tr>
	  	  <tr>
        <td class="td">Spare Tyre:
</td>
              <td  >'.$spare_inflated.'</td>
     
      </tr>
	   <tr>
	       <td colspan="2" class="cols" style = "color:yellowgreen; font-size:40px;"> Leaks:</td>
           
     
     
      </tr>
      <tr>
        <td class="td">Oil </td>
            <td >'.$oil.'</td>
     
      </tr>
	  <tr>
        <td class="td">Others:
</td>
              <td >'.$leaks_other.'</td>
     
      </tr>
	  <tr>
	       <td colspan="2" class="heading" style = "color:yellowgreen; font-size:40px;"> Safety Equipment:</td>
           
     
     
      </tr>
      <tr>
        <td class="td">First Aid Kit:</td>
            <td >'.$first_aid.'</td>
     
      </tr>
	  <tr>
        <td class="td">Seat Belts:
</td>
              <td  style="width:200px;">'.$seat_belts.'</td>
     
      </tr>
	  <tr>
        <td class="td">Airbag:
</td>
              <td  >'.$airbag.'</td>
     
      </tr>
	  <tr>
        <td class="td">Abs Break:

</td>
              <td >'.$absbreak.'</td>
     
      </tr>
	   <tr>
	       <td colspan="2" class="heading" style = "color:yellowgreen; font-size:40px;"> Air conditioner:</td>
           
     
     
      </tr>
      <tr>
        <td class="td">AC:</td>
            <td >'.$ac.'</td>
     
      </tr>
	  <tr>
        <td class="td">AC condition:</td>
            <td  >'.$ac_cond.'</td>
     
      </tr>
	   <tr>
	       <td colspan="2" class="heading" style = "color:yellowgreen; font-size:40px;"> Exterior</td>
           
     
     
      </tr>
      <tr>
        <td class="td">Boonet:
</td>
            <td>'.$boonet.'</td>
     
      </tr>
	   <tr>
        <td class="td">Right Fander:
</td>
            <td>'.$right_fander.'</td>
     
      </tr>
	   <tr>
        <td class="td">Left Fander:
</td>
            <td>'.$left_fander.'</td>
     
      </tr>
	   <tr>
        <td class="td">Front Right Window:
</td>
            <td>'.$front_rit_window.'</td>
     
      </tr>
	   <tr>
        <td class="td">Rear right Window:

</td>
            <td>'.$rear_right_window.'</td>
     
      </tr>
	   <tr>
        <td class="td">Rear Left Window:
</td>
            <td>'.$rear_left_window.'</td>
     
      </tr>
	   <tr>
        <td class="td">Right Quarter Panel:
</td>
            <td>'.$right_quarter_panel.'</td>
     
      </tr>
	   <tr>
        <td class="td">Left Quarter Panel:
</td>
            <td >'.$left_quarter_panel.'</td>
     
      </tr>
	   <tr>
        <td class="td">Roof:
</td>
            <td >'.$roof.'</td>
     
      </tr>
	   <tr>
        <td class="td">Boot:</td>
            <td >'.$boot.'</td>
     
      </tr>
	   <tr>
        <td class="td">Front Bumper:</td>
            <td >'.$front_bumper.'</td>
     
      </tr>
	  <tr>
        <td class="td">Rear Bumper:</td>
            <td >'.$rear_bumper.'</td>
     
      </tr>
	  <tr>
        <td class="td">Exterior comment:
</td>
            <td  >'.$exterior_comments.'</td>
     
      </tr>
	  <tr>
	       <td colspan="2" class="heading"> Interior</td>
           
     
     
      </tr>
      <tr>
        <td class="td">Dashboard:

</td>
            <td >'.$dashboard.'</td>
     
      </tr>
	   <tr>
        <td class="td"Steering:

</td>
            <td >'.$int_steering.'</td>
     
      </tr>
	   <tr>
        <td class="td">Gear Console:

</td>
            <td  >'.$gear_console.'</td>
     
      </tr>
	   <tr>
        <td class="td">Hand Break:

</td>
            <td  >'.$hand_break.'</td>
     
      </tr>
	   <tr>
        <td class="td">Seats:


</td>
            <td >'.$seats.'</td>
     
      </tr>
	   <tr>
        <td class="td">Interior comments

</td>
            <td  >'.$int_comments.'</td>
     
      </tr>
	  
	  
	  
	    <tr>
	       <td  class="td"> Condition of Vehicle Following the Inspection:</td>
           
       <td> '.$overall_condition.'</td>
     
      </tr>
    </tbody>
  </table>
<center><p><span>signature</span>
<img src="'.$image_url2.'" class="logo"></p></center>
</div>

  </body>'; 
  file_put_contents('reports/'.$car_id.'.html', $html);
  $report_url = $base_url."/data/reports/".$car_id.".html";
  $sql="INSERT INTO ca_cars (car_name,car_kms,registration,car_model_year,car_model,car_id,second_key,insurance,owner_serial,fuel_type,wheel_cover,music_player,tool_kit,jack,sun_roof,fog_lamp,seat_covers,noises,fuel,temprature,dashboard_warning_light,car_profile_img,car_gallery_image,signature_image_url,headlight,break_light,parking_light,turn_signals,windshield_wipers,fans_defosters,brakes,mirrors,horn,exhaust_system,suspension,steering,steering_cntrls,proper_inflation,adequate,spare_inflated,oil,other_leaks,first_aid_kit,seat_belts,airbag,absbreak,ac,boonet,right_fander,left_fander,front_right_window,front_left_window,rear_right_window,rear_left_window,right_quarter_panel,left_quarter_panel,roof,boot,front_bumper,rear_bumper,ext_comment,int_dashboard,int_steeering,gear_console,hand_break,seats,int_comments,folowing_inception_condition,price,start_auction,ac_cond,rating,report_url,transmission,alloy_wheel,color,auction_time) VALUES('$carname','$kms','$car_reg','$year','$model','$car_id','$second_key','$insurance','$owner_serial','$car_varriant','$wheel_cover','$music_player','$tool_kit','$jack','$sun_roof','$fog_lamp','$seat_covers','$noise','$fuel','$temprature','$dashboard_warning_light','$image_url1','$all_images','$image_url2','$headlight','$break_light','$parking_light','$turn_signals','$Windshield_wipers','$fans_defroster','$brakes','$mirrors','$horn','$exhaust_system','$suspension','$steering','$steering_cntrls','$infaltion','$adequate','$spare_inflated','$oil','$leaks_other','$first_aid','$seat_belts','$airbag','$absbreak','$ac','$boonet','$right_fander','$left_fander','$front_rit_window','$front_left_window','$rear_right_window','$rear_left_window','$right_quarter_panel','$left_quarter_panel','$roof','$boot','$front_bumper','$rear_bumper','$exterior_comments','$dashboard','$int_steering','$gear_console','$hand_break','$seats','$int_comments','$overall_condition','$price','0','$ac_cond','$rating','$report_url','$transmission','$alloy_wheel','$color','$auction_time')";
 $result=$connection->query($sql);
if($result)
{
	echo "car added succesfully";
	
	
	
	
}
else
{
	echo "please try again";
}
 ?>

