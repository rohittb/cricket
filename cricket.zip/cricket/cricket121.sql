-- phpMyAdmin SQL Dump
-- version 4.0.10.18
-- https://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Dec 13, 2017 at 02:18 AM
-- Server version: 5.6.36-cll-lve
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cricket121`
--

-- --------------------------------------------------------

--
-- Table structure for table `ca_cars`
--

CREATE TABLE IF NOT EXISTS `ca_cars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `car_name` varchar(255) NOT NULL,
  `car_kms` varchar(255) NOT NULL,
  `registration` varchar(255) NOT NULL,
  `car_model_year` varchar(255) NOT NULL,
  `car_id` varchar(255) NOT NULL,
  `car_profile_img` varchar(255) NOT NULL,
  `car_gallery_image` longtext NOT NULL,
  `price` varchar(255) NOT NULL,
  `start_auction` varchar(255) NOT NULL,
  `auction_date` varchar(255) NOT NULL,
  `auction_duration` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `second_key` varchar(255) NOT NULL,
  `insurance` varchar(255) NOT NULL,
  `owner_serial` varchar(255) NOT NULL,
  `fuel_type` varchar(255) NOT NULL,
  `wheel_cover` varchar(255) NOT NULL,
  `music_player` varchar(255) NOT NULL,
  `tool_kit` varchar(255) NOT NULL,
  `jack` varchar(255) NOT NULL,
  `sun_roof` varchar(255) NOT NULL,
  `fog_lamp` varchar(255) NOT NULL,
  `seat_covers` varchar(255) NOT NULL,
  `noises` varchar(255) NOT NULL,
  `fuel` varchar(255) NOT NULL,
  `temprature` varchar(255) NOT NULL,
  `dashboard_warning_light` varchar(255) NOT NULL,
  `headlight` varchar(255) NOT NULL,
  `break_light` varchar(255) NOT NULL,
  `parking_light` varchar(255) NOT NULL,
  `turn_signals` varchar(255) NOT NULL,
  `hazzard_light` varchar(255) NOT NULL,
  `windshield_wipers` varchar(255) NOT NULL,
  `fans_defosters` varchar(255) NOT NULL,
  `brakes` varchar(255) NOT NULL,
  `parking_brakes` varchar(255) NOT NULL,
  `mirrors` varchar(255) NOT NULL,
  `horn` varchar(255) NOT NULL,
  `exhaust_system` varchar(255) NOT NULL,
  `suspension` varchar(255) NOT NULL,
  `steering` varchar(255) NOT NULL,
  `steering_cntrls` varchar(255) NOT NULL,
  `proper_inflation` varchar(255) NOT NULL,
  `adequate` varchar(255) NOT NULL,
  `spare_inflated` varchar(255) NOT NULL,
  `oil` varchar(255) NOT NULL,
  `other_leaks` varchar(255) NOT NULL,
  `first_aid_kit` varchar(255) NOT NULL,
  `seat_belts` varchar(255) NOT NULL,
  `airbag` varchar(255) NOT NULL,
  `absbreak` varchar(255) NOT NULL,
  `ac` varchar(255) NOT NULL,
  `boonet` varchar(255) NOT NULL,
  `right_fander` varchar(255) NOT NULL,
  `left_fander` varchar(255) NOT NULL,
  `front_right_window` varchar(255) NOT NULL,
  `front_left_window` varchar(255) NOT NULL,
  `rear_right_window` varchar(255) NOT NULL,
  `rear_left_window` varchar(255) NOT NULL,
  `right_quarter_panel` varchar(255) NOT NULL,
  `left_quarter_panel` varchar(255) NOT NULL,
  `roof` varchar(255) NOT NULL,
  `boot` varchar(255) NOT NULL,
  `front_bumper` varchar(255) NOT NULL,
  `rear_bumper` varchar(255) NOT NULL,
  `ext_comment` varchar(255) NOT NULL,
  `int_dashboard` varchar(255) NOT NULL,
  `int_steeering` varchar(255) NOT NULL,
  `gear_console` varchar(255) NOT NULL,
  `hand_break` varchar(255) NOT NULL,
  `seats` varchar(255) NOT NULL,
  `int_comments` int(255) NOT NULL,
  `folowing_inception_condition` varchar(255) NOT NULL,
  `signature_image_url` varchar(255) NOT NULL,
  `car_model` varchar(255) NOT NULL,
  `ac_cond` varchar(20) NOT NULL,
  `report_url` varchar(100) NOT NULL,
  `rating` varchar(20) NOT NULL,
  `transmission` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=100 ;

--
-- Dumping data for table `ca_cars`
--

INSERT INTO `ca_cars` (`id`, `car_name`, `car_kms`, `registration`, `car_model_year`, `car_id`, `car_profile_img`, `car_gallery_image`, `price`, `start_auction`, `auction_date`, `auction_duration`, `color`, `second_key`, `insurance`, `owner_serial`, `fuel_type`, `wheel_cover`, `music_player`, `tool_kit`, `jack`, `sun_roof`, `fog_lamp`, `seat_covers`, `noises`, `fuel`, `temprature`, `dashboard_warning_light`, `headlight`, `break_light`, `parking_light`, `turn_signals`, `hazzard_light`, `windshield_wipers`, `fans_defosters`, `brakes`, `parking_brakes`, `mirrors`, `horn`, `exhaust_system`, `suspension`, `steering`, `steering_cntrls`, `proper_inflation`, `adequate`, `spare_inflated`, `oil`, `other_leaks`, `first_aid_kit`, `seat_belts`, `airbag`, `absbreak`, `ac`, `boonet`, `right_fander`, `left_fander`, `front_right_window`, `front_left_window`, `rear_right_window`, `rear_left_window`, `right_quarter_panel`, `left_quarter_panel`, `roof`, `boot`, `front_bumper`, `rear_bumper`, `ext_comment`, `int_dashboard`, `int_steeering`, `gear_console`, `hand_break`, `seats`, `int_comments`, `folowing_inception_condition`, `signature_image_url`, `car_model`, `ac_cond`, `report_url`, `rating`, `transmission`) VALUES
(85, 'Hyundai', '75000', 'HR72B8378', '2014', 'car_59de1ed4ba29f', 'http://go4intern.com/cars/cars4u/data/images/59de1ed4ba782untitled.png', 'http://go4intern.com/cars/cars4u/data/images/59de1ed4ba2ebuntitled.png,', '400000', '2', '11-10-2017 19:26:08', '1', '', 'Yes', 'YES', '1st', 'Diesel', 'yes', 'yes', 'yes', 'yes', 'no', 'yes', 'yes', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', '60%', '60%', '20%', 'ok', 'ok', 'ok', 'ok', 'no', 'ok', 'manual', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 0, 'acceptable', '', 'Grand i 10 Magna', 'ok', 'http://go4intern.com/cars/cars4u/data/reports/car_59de1ed4ba29f.html', '4.5', 'Manual'),
(86, 'MAHINDRA & MAHINDRA', '58100', 'HR26CF6682', '2014', 'car_59e3349283c06', 'http://go4intern.com/cars/cars4u/data/images/59e33493a125d1.png', 'http://go4intern.com/cars/cars4u/data/images/59e3349283c511.png,http://go4intern.com/cars/cars4u/data/images/59e33492841622.png,http://go4intern.com/cars/cars4u/data/images/59e33492846b03.png,http://go4intern.com/cars/cars4u/data/images/59e33493a04464.png,http://go4intern.com/cars/cars4u/data/images/59e33493a0a235.png,http://go4intern.com/cars/cars4u/data/images/59e33493a0e486.png,', '975000', '0', '', '', '', 'YES', 'MARCH 2018', '1st', 'Diesel', 'yes', 'yes', 'yes', 'yes', 'no', 'yes', 'yes', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', '60%', '40', '40%', 'ok', 'ok', 'ok', 'ok', 'yes', 'ok', 'automatic', 'original', 'original', 'painted', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'changed', 'OK', 'MINOR SCRATCHES', 'MINOR DENT ON BONAT MINOR DENT ON LHS SIDE REAR WINDOW', 'ok', 'ok', 'ok', 'ok', 'ok', 0, 'acceptable', '', 'XUV500 W8', 'ok', 'http://go4intern.com/cars/cars4u/data/reports/car_59e3349283c06.html', '4.5', 'Manual'),
(87, 'MARUTI SUZUKI', '56000', '2013', '2013', ' car_59e33a2a73864 ', ' http://go4intern.com/cars/cars4u/data/images/59edbb945a769ERTIGA 1.jpg', ' http://go4intern.com/cars/cars4u/data/images/59e33a2a738ad6.png,http://go4intern.com/cars/cars4u/data/images/59e33a2a73d8e7.png,http://go4intern.com/cars/cars4u/data/images/59e33a2c5b6528.png,http://go4intern.com/cars/cars4u/data/images/59e33a2c5ba979.png,http://go4intern.com/cars/cars4u/data/images/59e33a2c5c00310.png,', '565000', '0', '', '', 'WHITE', 'YES', 'MARCH 2018 ', '1st', 'Diesel', 'yes', 'yes ', 'yes', 'yes', 'no ', 'yes', 'yes', 'ok', 'ok ', 'ok ', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok ', 'ok', 'ok', 'ok ', 'ok', 'ok', 'ok ', 'ok', 'ok', 'ok', 'ok ', '80%', '80%', '20% ', 'ok', 'ok', 'ok', 'ok', 'no', 'ok ', 'automatic', 'original', 'original', 'original', 'original', 'original ', 'painted ', 'original', 'original', 'original ', 'original', 'original', 'OK', 'OK', 'MINOR DENT ON LHS FRONT DOOR ', 'ok ', 'ok ', 'ok', 'ok', 'ok', 0, 'acceptable', ' ', 'ERTIGA VDI', 'ok', 'http://go4intern.com/cars/cars4u/data/reports/59edbb945a72e.html ', '4.5', 'Manual'),
(88, 'FORD', '41000', '2014', '2014', ' car_59e33ddc5179a ', ' http://go4intern.com/cars/cars4u/data/images/59e33dde31c1614.png', ' http://go4intern.com/cars/cars4u/data/images/59e33ddc517e416.png,http://go4intern.com/cars/cars4u/data/images/59e33ddc51db011.png,http://go4intern.com/cars/cars4u/data/images/59e33ddc522f212.png,http://go4intern.com/cars/cars4u/data/images/59e33ddc5287613.png,http://go4intern.com/cars/cars4u/data/images/59e33dde313be14.png,http://go4intern.com/cars/cars4u/data/images/59e33dde318a715.png,', '710000', '0', '', '', 'G GREY', 'YES', 'YES ', '1st', 'Diesel', 'yes', 'yes ', 'yes', 'yes', 'no ', 'yes', 'yes', 'ok', 'ok ', 'ok ', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok ', 'ok', 'ok', 'ok ', 'ok', 'ok', 'ok ', 'ok', 'ok', 'ok', 'ok ', '40%', '40', '40% ', 'ok', 'ok', 'ok', 'ok', 'yes', 'ok ', 'automatic', 'original', 'original', 'painted', 'original', 'original ', 'painted ', 'original', 'original', 'painted ', 'original', 'original', 'OK', 'OK', 'OK ', 'ok ', 'ok ', 'ok', 'ok', 'ok', 0, 'acceptable', ' ', 'EECO SPORT TITANIUM+', 'ok', 'http://go4intern.com/cars/cars4u/data/reports/59e359d2b74f2.html ', '4.8', 'Manual'),
(89, 'HYUNDAI', '45500', 'HR14J9265', '2013', 'car_59e35c224b4ef', 'http://go4intern.com/cars/cars4u/data/images/59e35c23bd92f26.png', 'http://go4intern.com/cars/cars4u/data/images/59e35c224b53e28.png,http://go4intern.com/cars/cars4u/data/images/59e35c224b99f22.png,http://go4intern.com/cars/cars4u/data/images/59e35c239b29024.png,http://go4intern.com/cars/cars4u/data/images/59e35c239b69225.png,http://go4intern.com/cars/cars4u/data/images/59e35c239bbe126.png,http://go4intern.com/cars/cars4u/data/images/59e35c239c06127.png,', '285000', '0', '', '', '', 'YES', 'AUGUST 2018', '1st', 'Petrol', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'yes', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', '80%', '80%', '40%', 'ok', 'ok', 'ok', 'ok', 'no', 'ok', 'automatic', 'changed', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'OK', 'MINOR SCRATCHES', 'EXTERIORS ARE VERY GOOD', 'ok', 'ok', 'ok', 'ok', 'ok', 0, 'acceptable', '', 'I10 MAGNA', 'ok', 'http://go4intern.com/cars/cars4u/data/reports/car_59e35c224b4ef.html', '4.5', 'Manual'),
(90, 'HONDA', '55339', 'HR26BU6705', '2011', 'car_59e35e7906e01', 'http://go4intern.com/cars/cars4u/data/images/59e35e7a4a05932.png', 'http://go4intern.com/cars/cars4u/data/images/59e35e7906e4e34.png,http://go4intern.com/cars/cars4u/data/images/59e35e79072bd29.png,http://go4intern.com/cars/cars4u/data/images/59e35e7a48dc630.png,http://go4intern.com/cars/cars4u/data/images/59e35e7a4926431.png,http://go4intern.com/cars/cars4u/data/images/59e35e7a4982a32.png,http://go4intern.com/cars/cars4u/data/images/59e35e7a49c2833.png,', '450000', '0', '', '', '', 'NO', 'NO', '2ND', 'Petrol', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'yes', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', '80%', '40', '20%', 'ok', 'ok', 'ok', 'ok', 'yes', 'ok', 'manual', 'painted', 'painted', 'original', 'original', 'painted', 'original', 'painted', 'painted', 'painted', 'original', 'painted', 'OK', 'OK', 'GOOD', 'ok', 'ok', 'ok', 'ok', 'ok', 0, 'acceptable', '', 'HONDA CITY', 'ok', 'http://go4intern.com/cars/cars4u/data/reports/car_59e35e7906e01.html', '4', 'Manual'),
(91, 'MARUTI SUZUKI', '80000', 'HR26AX3260', '2009', 'car_59e3603fe84e0', 'http://go4intern.com/cars/cars4u/data/images/59e360421c9ad38.png', 'http://go4intern.com/cars/cars4u/data/images/59e3603fe852b40.png,http://go4intern.com/cars/cars4u/data/images/59e3603fe8a2d35.png,http://go4intern.com/cars/cars4u/data/images/59e36041c464436.png,http://go4intern.com/cars/cars4u/data/images/59e36041c4a2f37.png,http://go4intern.com/cars/cars4u/data/images/59e36041c4f5c38.png,http://go4intern.com/cars/cars4u/data/images/59e36041c535439.png,', '260000', '0', '', '', '', 'NO', 'YES', '1st', 'Petrol', 'yes', 'yes', 'yes', 'yes', 'no', 'yes', 'yes', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', '80%', '80%', '40%', 'ok', 'ok', 'ok', 'ok', 'yes', 'ok', 'automatic', 'painted', 'painted', 'original', 'original', 'painted', 'original', 'painted', 'original', 'painted', 'original', 'original', 'NEED TO BE REPAIR', 'OK', 'GOOD', 'ok', 'ok', 'ok', 'ok', 'ok', 0, 'acceptable', '', 'SX4 ZXI', 'ok', 'http://go4intern.com/cars/cars4u/data/reports/car_59e3603fe84e0.html', '4', 'Manual'),
(92, 'MARUTI SUZUKI', '62000', 'HR26BU6001', '2012', 'car_59e36371ad48f', 'http://go4intern.com/cars/cars4u/data/images/59e363727ca3645.png', 'http://go4intern.com/cars/cars4u/data/images/59e36371ad4d741.png,http://go4intern.com/cars/cars4u/data/images/59e363727b12442.png,http://go4intern.com/cars/cars4u/data/images/59e363727b62843.png,http://go4intern.com/cars/cars4u/data/images/59e363727bb6644.png,http://go4intern.com/cars/cars4u/data/images/59e363727c0db45.png,http://go4intern.com/cars/cars4u/data/images/59e363727c4d846.png,', '210000', '0', '', '', '', 'NO', 'NO', '1ST', 'Petrol', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'yes', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', '60%', '60%', '20%', 'ok', 'ok', 'ok', 'ok', 'no', 'ok', 'manual', 'changed', 'painted', 'painted', 'original', 'painted', 'original', 'painted', 'original', 'painted', 'original', 'original', 'OK', 'OK', 'GOOD', 'ok', 'ok', 'ok', 'ok', 'ok', 0, 'acceptable', '', 'ALTO LXI', 'ok', 'http://go4intern.com/cars/cars4u/data/reports/car_59e36371ad48f.html', '4.1', 'Manual'),
(93, 'HYUNDAI', '67000', 'GHR26AT3526', '2008', 'car_59e365e14d81d', 'http://go4intern.com/cars/cars4u/data/images/59e365e3a64fb51.png', 'http://go4intern.com/cars/cars4u/data/images/59e365e14d86647.png,http://go4intern.com/cars/cars4u/data/images/59e365e3a481248.png,http://go4intern.com/cars/cars4u/data/images/59e365e3a4ece49.png,http://go4intern.com/cars/cars4u/data/images/59e365e3a556350.png,http://go4intern.com/cars/cars4u/data/images/59e365e3a5c0d51.png,http://go4intern.com/cars/cars4u/data/images/59e365e3a606552.png,', '275000', '0', '', '', '', 'YES', 'NO', '1ST', 'Diesel', 'yes', 'yes', 'yes', 'yes', 'no', 'yes', 'yes', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', '40%', '40', '20%', 'ok', 'ok', 'ok', 'ok', 'no', 'ok', 'automatic', 'original', 'original', 'painted', 'painted', 'painted', 'painted', 'painted', 'painted', 'painted', 'original', 'original', 'OK', 'OK', 'EXTERIORS ARE VERY GOOD', 'ok', 'ok', 'ok', 'ok', 'ok', 0, 'acceptable', '', 'VERNA VGT', 'ok', 'http://go4intern.com/cars/cars4u/data/reports/car_59e365e14d81d.html', '4.1', 'Manual'),
(94, 'Renault', '62000', 'HR26BU2830', '2012', 'car_59edaa1f12347', 'http://go4intern.com/cars/cars4u/data/images/59edaa1f1401dd5.jpg', 'http://go4intern.com/cars/cars4u/data/images/59edaa1f1238ed6.jpg,http://go4intern.com/cars/cars4u/data/images/59edaa1f124c6d1.jpg,http://go4intern.com/cars/cars4u/data/images/59edaa1f125add2.jpg,http://go4intern.com/cars/cars4u/data/images/59edaa1f13c0ad3.jpg,http://go4intern.com/cars/cars4u/data/images/59edaa1f13d61d4.jpg,http://go4intern.com/cars/cars4u/data/images/59edaa1f13ebed5.jpg,', '585000', '0', '', '', '', 'YES', '18 JULY 2018', '1st', 'Diesel', 'yes', 'yes', 'yes', 'yes', 'no', 'yes', 'yes', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', '60%', '60%', '40%', 'ok', 'ok', 'ok', 'ok', 'yes', 'ok', 'manual', 'original', 'painted', 'painted', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'OK', 'OK', 'EXCELLENT', 'ok', 'ok', 'ok', 'ok', 'ok', 0, 'acceptable', '', 'DUSTER RXZ 110', 'ok', 'http://go4intern.com/cars/cars4u/data/reports/car_59edaa1f12347.html', '4.8', 'Manual'),
(95, 'VOLKSWAGEN', '21500', 'DL7CN7355', '2013', 'car_59edae471762d', 'http://go4intern.com/cars/cars4u/data/images/59edae4717e6dp2.jpg', 'http://go4intern.com/cars/cars4u/data/images/59edae4717675p5.jpg,http://go4intern.com/cars/cars4u/data/images/59edae47177fep6.jpg,http://go4intern.com/cars/cars4u/data/images/59edae4717917p7.jpg,http://go4intern.com/cars/cars4u/data/images/59edae4717a45p1.jpg,http://go4intern.com/cars/cars4u/data/images/59edae4717b20p2.jpg,http://go4intern.com/cars/cars4u/data/images/59edae4717c7dp3.jpg,http://go4intern.com/cars/cars4u/data/images/59edae4717d95p4.jpg,', '1290000', '0', '', '', '', 'YES', ' JAN 2018', '1st', 'Diesel', 'yes', 'yes', 'yes', 'yes', 'no', 'yes', 'yes', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', '60%', '60%', '60%', 'ok', 'ok', 'ok', 'ok', 'yes', 'ok', 'automatic', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'OK', 'OK', 'EXCELLENT', 'ok', 'ok', 'ok', 'ok', 'ok', 0, 'acceptable', '', 'PASSAT', 'ok', 'http://go4intern.com/cars/cars4u/data/reports/car_59edae471762d.html', '4.8', 'Manual'),
(96, 'HYUNDAI', '24500', 'HR22L0800', '2016', 'car_59edb0a438fad', 'http://go4intern.com/cars/cars4u/data/images/59edb0a439473c3.jpg', 'http://go4intern.com/cars/cars4u/data/images/59edb0a438ff6c5.jpg,http://go4intern.com/cars/cars4u/data/images/59edb0a43910bc 1.jpg,http://go4intern.com/cars/cars4u/data/images/59edb0a4391f8c2.jpg,http://go4intern.com/cars/cars4u/data/images/59edb0a4392cec3.jpg,http://go4intern.com/cars/cars4u/data/images/59edb0a439392c4.jpg,', '1050000', '0', '', '', '', 'YES', 'NO', '1st', 'Diesel', 'yes', 'yes', 'yes', 'yes', 'no', 'yes', 'yes', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', '40%', '40', '60%', 'ok', 'ok', 'ok', 'ok', 'yes', 'ok', 'manual', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'OK', 'OK', 'EXCELLENT', 'ok', 'ok', 'ok', 'ok', 'ok', 0, 'acceptable', '', 'CRETA ', 'ok', 'http://go4intern.com/cars/cars4u/data/reports/car_59edb0a438fad.html', '4.8', 'Manual'),
(97, 'MARUTI SUZUKI', '87142', '2012', '2012', ' car_59edb42a7fb34 ', ' http://go4intern.com/cars/cars4u/data/images/59edb42a8028bw2.jpg', ' http://go4intern.com/cars/cars4u/data/images/59edb42a7fb81w4.jpg,http://go4intern.com/cars/cars4u/data/images/59edb42a7fca0w5.jpg,http://go4intern.com/cars/cars4u/data/images/59edb42a7fd9ew6.jpg,http://go4intern.com/cars/cars4u/data/images/59edb42a7ff0dw1.jpg,http://go4intern.com/cars/cars4u/data/images/59edb42a80055w2.jpg,http://go4intern.com/cars/cars4u/data/images/59edb42a80190w3.jpg,', '2.25', '0', '', '', 'WHITE', 'YES', 'NO ', '1ST', 'Cng', 'yes', 'yes ', 'yes', 'yes', 'no ', 'yes', 'no', 'ok', 'ok ', 'ok ', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok ', 'ok', 'ok', 'ok ', 'ok', 'ok', 'ok ', 'ok', 'ok', 'ok', 'ok ', '80%', '80%', '20% ', 'ok', 'ok', 'ok', 'ok', 'no', 'ok ', 'automatic', 'original', 'original', 'original', 'original', 'original ', 'painted ', 'original', 'original', 'original ', 'original', 'original', 'OK', 'OK', 'GOOD ', 'ok ', 'ok ', 'ok', 'ok', 'ok', 0, 'acceptable', ' ', 'WAGONR LXI', 'ok', 'http://go4intern.com/cars/cars4u/data/reports/59edba8e36a98.html ', '4.5', 'Manual'),
(98, '', '', '', '', 'car_59edb56b9f9f0', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', 'http://go4intern.com/cars/cars4u/data/reports/car_59edb56b9f9f0.html', '', ''),
(99, 'HONDA', '130000', 'HR26AT6666', '2008', 'car_59edb56dbde4c', 'http://go4intern.com/cars/cars4u/data/images/59edb56dbe43cc1.jpg', 'http://go4intern.com/cars/cars4u/data/images/59edb56dbde8a6.jpg,http://go4intern.com/cars/cars4u/data/images/59edb56dbdfb47.jpg,http://go4intern.com/cars/cars4u/data/images/59edb56dbe0c6c1.jpg,http://go4intern.com/cars/cars4u/data/images/59edb56dbe1b82.jpg,http://go4intern.com/cars/cars4u/data/images/59edb56dbe2974.jpg,http://go4intern.com/cars/cars4u/data/images/59edb56dbe3615.jpg,', '250000', '0', '', '', '', 'YES', 'JULY 2018', '1st', 'Petrol', 'yes', 'yes', 'yes', 'yes', 'no', 'yes', 'yes', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', '40%', '40', '40%', 'ok', 'ok', 'ok', 'ok', 'yes', 'ok', 'automatic', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'OK', 'OK', 'GOOD', 'ok', 'ok', 'ok', 'ok', 'ok', 0, 'acceptable', '', 'CIVIC', 'ok', 'http://go4intern.com/cars/cars4u/data/reports/car_59edb56dbde4c.html', '4.5', 'automatic');

-- --------------------------------------------------------

--
-- Table structure for table `ca_match`
--

CREATE TABLE IF NOT EXISTS `ca_match` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team1` varchar(50) NOT NULL,
  `team1_logo` varchar(255) NOT NULL,
  `team2` varchar(50) NOT NULL,
  `team2_logo` varchar(255) NOT NULL,
  `match_type` varchar(50) NOT NULL,
  `match_format` varchar(255) NOT NULL,
  `match_time` varchar(50) NOT NULL,
  `ground` varchar(50) NOT NULL,
  `active_innings` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=80 ;

--
-- Dumping data for table `ca_match`
--

INSERT INTO `ca_match` (`id`, `team1`, `team1_logo`, `team2`, `team2_logo`, `match_type`, `match_format`, `match_time`, `ground`, `active_innings`) VALUES
(64, 'INDIA', 'http://webpetalsoftware.com/cricket//data/images/5a16bdf1b5002az-large-1541002.jpg', 'australia', 'http://webpetalsoftware.com/cricket//data/images/5a16bdf1b50f3index.jpg', 'UPCOMING', 'ODI', '23-11-2017 17:53', 'FEROZ SHAH KOTLA NEW DELHI', ''),
(65, 'AUSTRALIA', 'http://webpetalsoftware.com/cricket//data/images/5a16be2b675fbbeach-style-blue-background-1080p_qyvzckhb__F0000.png', 'india', 'http://webpetalsoftware.com/cricket//data/images/5a16be2b677d7beach-style-blue-background-1080p_qyvzckhb__F0000.png', 'UPCOMING', 'T20I', '23-11-2017 17:54', 'FEROZ SHAH KOTLA NEW DELHI', ''),
(66, 'india', 'http://webpetalsoftware.com/cricket//data/images/5a1920c8aac8611665409_942760865790431_4048860266714419174_n (1).jpg', 'kale', 'http://webpetalsoftware.com/cricket//data/images/5a1920c8ac73111665409_942760865790431_4048860266714419174_n.jpg', 'LIVE', 'T20I', '26-11-2017 13:19', 'lahore', '1'),
(69, 'iun', 'http://webpetalsoftware.com/cricket//data/images/5a19252c0b94959bbb21b59fedmahindra-e-verito.jpg', 'india', 'http://webpetalsoftware.com/cricket//data/images/5a19252c0babelogo4.png', 'LIVE', 'T20I', '25-11-2017 13:38', '12', '1'),
(78, 'INDIA', 'http://webpetalsoftware.com/cricket//data/images/5a2f9a8a59f59CGL.png', 'NEW ZEALAND', 'http://webpetalsoftware.com/cricket//data/images/5a2f9a8a5b7daNZL-NEW1.png', 'LIVE', 'T20I', '15-12-2017 14:28', 'NAPIER , NEW ZEALAND', '1'),
(79, 'test', 'http://webpetalsoftware.com/cricket//data/images/5a30c6b149c27fluidlogo.png', 'fluid', 'http://webpetalsoftware.com/cricket//data/images/5a30c6b149cfbfluidlogo.png', 'LIVE', 'T20I', '', 'FEROZ SHAH KOTLA NEW DELHI', '1');

-- --------------------------------------------------------

--
-- Table structure for table `ca_user`
--

CREATE TABLE IF NOT EXISTS `ca_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `pan_no` varchar(255) NOT NULL,
  `mobile_no` varchar(11) NOT NULL,
  `location` varchar(255) NOT NULL,
  `prefrences` varchar(255) NOT NULL,
  `user_main_id` varchar(255) NOT NULL,
  `profile_image` varchar(255) NOT NULL,
  `user_approve` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ca_user`
--

INSERT INTO `ca_user` (`user_id`, `role`, `email`, `password`, `pan_no`, `mobile_no`, `location`, `prefrences`, `user_main_id`, `profile_image`, `user_approve`) VALUES
(1, 'admin', 'admin@admin.com', 'admin123', 'bam12345678', '123456789', 'delhi', 'd7TtTBSYY4Y:APA91bF_SUMPhROoQaS5kVNF4ZdbMOZqx-wDo1M0qWYeItIXJxcU94mruhP7GwN2ydtDfcEIPLHWHrd2JwkJ_HiC0Uyczm56O6XaRdA4nauLXFryJ8BqF4bW3CWCNZPsL0yVIK3koEsU', '', '', '1');

-- --------------------------------------------------------

--
-- Table structure for table `fall_of_wickets`
--

CREATE TABLE IF NOT EXISTS `fall_of_wickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `match_id` varchar(50) NOT NULL,
  `innings_one` text NOT NULL,
  `innings_two` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `fall_of_wickets`
--

INSERT INTO `fall_of_wickets` (`id`, `match_id`, `innings_one`, `innings_two`) VALUES
(1, '62', 'rohit#4	36-1(4.1 over),rohit#4	36-1(4.1 over),rohit#4	36-1(4.1 over),rohit#4	36-1(4.1 over),rohit#4	36-1(4.1 over),rohit#4	36-1(4.1 over),rohit#4	36-1(4.1 over),rohit#4	36-1(4.1 over),rohit#4	36-1(4.1 over),rohit#4	36-1(4.1 over)\n					', 'rohit#4	36-1(4.1 over),rohit#4	36-1(4.1 over),rohit#4	36-1(4.1 over),rohit#4	36-1(4.1 over),rohit#4	36-1(4.1 over),rohit#4	36-1(4.1 over),rohit#4	36-1(4.1 over),rohit#4	36-1(4.1 over),rohit#4	36-1(4.1 over),rohit#4	36-1(4.1 over)\n								\n					'),
(2, '', '', ''),
(3, '77', '					\n					', '					\n					'),
(4, '78', '					\n					', '			1-12,2-40,3-100		\n					'),
(5, '79', '					\nsdssd', '					\n			dssddsds		');

-- --------------------------------------------------------

--
-- Table structure for table `live_match_updates`
--

CREATE TABLE IF NOT EXISTS `live_match_updates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session` varchar(50) NOT NULL,
  `current_ball` varchar(50) NOT NULL,
  `match_id` int(50) NOT NULL,
  `run` varchar(50) NOT NULL,
  `wicket` int(11) NOT NULL,
  `rates` varchar(50) NOT NULL,
  `crr` varchar(50) NOT NULL,
  `rr` varchar(50) NOT NULL,
  `target` varchar(50) NOT NULL,
  `over` varchar(50) NOT NULL,
  `active_innings` varchar(50) NOT NULL,
  `crun` varchar(100) NOT NULL,
  `tagline` varchar(255) NOT NULL,
  `favourite` varchar(50) NOT NULL,
  `partnership` varchar(50) NOT NULL,
  `last_w` varchar(50) NOT NULL,
  `comment` text NOT NULL,
  `wicket_target` varchar(50) NOT NULL,
  `over_target` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `live_match_updates`
--

INSERT INTO `live_match_updates` (`id`, `session`, `current_ball`, `match_id`, `run`, `wicket`, `rates`, `crr`, `rr`, `target`, `over`, `active_innings`, `crun`, `tagline`, `favourite`, `partnership`, `last_w`, `comment`, `wicket_target`, `over_target`) VALUES
(13, '10-11', '', 49, '300', 2, '6-8', '6', '6.1', '301', '50', '1', '6', 'AUSTRALIA NEED 301 RUNS IN 50 OVERS\n\n', 'IND', '100(102)', 'SANGA 20 (22)', '', '', ''),
(14, '', '', 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(15, '', '', 53, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(16, '', '', 55, '', 0, '', '', '', '', '', '1', '', '', '', '', '', '', '', ''),
(17, '', '', 56, '', 0, '', '', '', '', '', '1', '', '', '', '', '', '', '', ''),
(18, '12-14', '3,4,W,NB,6', 58, '5', 1, '8-9', '', '', '', '2', '1', 'B', 'INDIA WIN THIS NMATCH', 'PAKI', '45', '25', '', '', ''),
(19, '12-12', '1,2', 62, '10-12', 0, '20-20', '', '', '', '', '2', '4', 'india need 2 run', 'ind', '', '', '					\n			dxzdfdfdf		', '', ''),
(20, '1', '1,2', 66, '12', 2, '13-13', '5', '6', '50', '2', '1', '8', 'dfbdf', 'india', '', '', '', '', ''),
(21, '12-13', '', 71, '10', 1, '40-42', '5', '', '', '2', '1', '4', '', '', '', '', '', '', ''),
(22, '12-12', '1,2', 72, '140', 3, '14-16', '7.00', '', '', '20', '2', '', 'fgfgfgggfg', 'TT', '34(6)', 'ROHIT 34 (111-3)', '', '', ''),
(23, '', '', 69, '', 0, '12-12', '', '', '', '', '1', '', 'xyz', 'iun', '', '', '', '', ''),
(24, '', '', 68, '12', 2, '15-16', '5', '5', '50', '2', '1', '', 'dffdgd', 'raj', '', '', '', '', ''),
(25, '1', '1,2', 73, '1', 2, '30-40', '0.5', '', '', '2', '1', '2', '', '', '', '', '', '', ''),
(26, '45-50', '1,2', 76, '12', 12, '55-98', '12', '12', '100', '12', '2', '5', 'ss', 'dds', 'ssd', 'dss', '', '12', '2'),
(27, '23-25', '1', 77, '45', 1, '', '', '', '', '10', '2', '1', 'india need 293 run in 50 overs\n', '', '18(19)', '', '					\n					', '', ''),
(28, '', '', 78, '120', 4, '41-43', '', '', '', '19', '1', '6', '', 'INDIA', '12(9)', '78-3( RONCHII)', '', '4', '20'),
(29, '45-50', '1,2', 79, '12', 12, '16-98', '12', '12', '', '12', '1', '5', 'ss', 'dsds', '1', '1', '					\n				dsdsdsdsds	', '1', '12');

-- --------------------------------------------------------

--
-- Table structure for table `match_stats`
--

CREATE TABLE IF NOT EXISTS `match_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `match_id` int(11) NOT NULL,
  `player_id` varchar(50) NOT NULL,
  `player_name` varchar(225) NOT NULL,
  `bat_run` varchar(11) NOT NULL,
  `bat_ball` varchar(11) NOT NULL,
  `player_status` varchar(225) NOT NULL,
  `player_type` varchar(225) NOT NULL,
  `team_name` varchar(225) NOT NULL,
  `innings` varchar(225) NOT NULL,
  `four` varchar(50) NOT NULL,
  `six` varchar(50) NOT NULL,
  `wicket_taken` varchar(50) NOT NULL,
  `status_bowl` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=131 ;

--
-- Dumping data for table `match_stats`
--

INSERT INTO `match_stats` (`id`, `match_id`, `player_id`, `player_name`, `bat_run`, `bat_ball`, `player_status`, `player_type`, `team_name`, `innings`, `four`, `six`, `wicket_taken`, `status_bowl`) VALUES
(77, 62, '', 'Zaheer ', '33', '10', 'bowling', 'bowler', 'australia', '1', '', '', '10', ''),
(78, 62, '1', 'HEYTU', '10', '2', 'out', 'batsmen', 'INDIA', '1', '1', '6', '', ''),
(79, 62, '2', 'ADARSH', '12', '2', 'out', 'batsmen', 'INDIA', '1', '', '2', '', ''),
(80, 62, '1', 'ROhit', '10', '10', 'playing', 'batsmen', 'INDIA', '2', '10', '10', '', ''),
(81, 0, '', '', '0', '0', '', '', '', '', '', '', '', ''),
(82, 62, '2', 'Sikhar', '10', '10', 'playing', 'batsmen', 'INDIA', '2', '10', '10', '', ''),
(83, 62, '', 'Warne', '10', '10', 'bowling', 'bowler', 'australia', '2', '', '', '10', ''),
(84, 62, '', 'Zahe', '10', '10', 'bowling', 'bowler', 'australia', '1', '', '', '10', ''),
(85, 49, '', 'RAJ KUMAR', '22', '0', 'bowling', 'bowler', 'AUS', '1', '', '', '0', ''),
(86, 62, '', 'RAJ', '22', '1', 'bowling', 'bowler', 'AUS', '', '', '', '', ''),
(87, 62, '', 'RAVI', '22', '1', 'bowling', 'bowler', 'AUS', '1', '', '', '0', ''),
(88, 62, '3', 'MAHESH* ', '10', '2', 'playing', 'batsmen', 'INDIA', '1', '1', '6', '', ''),
(89, 62, '4', 'RAJU*', '12', '2', 'playing', 'batsmen', 'INDIA', '1', '', '2', '', ''),
(90, 62, '1', 'sumit', '20', '4', 'out', 'batsmen', 'india', '1', '2', '2', '', ''),
(91, 62, '', '', '0', '0', 'bowling', 'bowler', 'AUS', '', '', '', '', ''),
(92, 76, '1', 'rohit', '12', '1', 'playing', 'batsmen', 'INDIA', '1', '1', '0', '', ''),
(93, 76, '2', 'virat', '0', '0', 'playing', 'batsmen', 'INDIA', '1', '0', '0', '', ''),
(94, 76, '3', 'KANE', '100', '90', 'out', 'batsmen', 'NEW ZEALAND', '1', '10', '6', '', ''),
(95, 76, '4', 'TAYLOR', '80', '90', 'out', 'batsmen', 'NEW ZEALAND', '1', '10', '6', '', ''),
(96, 77, '', 'Bhuvneshwar Kumar', '0', '0', 'bowling', 'bowler', 'NEWZILAND', '1', '', '', '0', ''),
(97, 77, '1', 'guptill*', '14', '11', 'playing', 'batsmen', 'newziland', '1', '', '', '', ''),
(98, 77, '2', 'RYDER*', '14', '13', 'playing', 'batsmen', 'NEW ZEALAND', '1', '2', '1', '', ''),
(99, 77, '', 'sssss', '1', '0', 'bowling', 'bowler', 'NEWZILAND', '1', '', '', '', ''),
(100, 76, '', 'bond', '12', '1', 'bowling', 'bowler', 'new zealand', '1', '', '', '1', ''),
(101, 76, '', 'rohit', '12', '1', 'bowling', 'bowler', 'new zealand', '1', '', '', '1', ''),
(102, 76, '', 'lalit', '1', '1', 'bowling', 'bowler', 'new zealand', '1', '', '', '1', '1'),
(105, 0, '', '', '', '', 'bowling', 'bowler', '', '', '', '', '', '0'),
(106, 76, '', 'lalit', '0', '0', 'bowling', 'bowler', 'new zealand', '2', '', '', 'ds', '1'),
(107, 78, '1.', 'SHIKHAR', '10', '9', 'playing', 'batsmen', 'INDIA', '1', '1', '', '', ''),
(108, 78, '2', 'KOHLI', '60', '55', 'playing', 'batsmen', 'INDIA', '1', '4', '5', '', ''),
(109, 78, '', 'TIM', '5', '3', 'bowling', 'bowler', 'NEW ZEALAND', '1', '', '', '4', '0'),
(110, 78, '', 'SOUTHHE', '78', '4', 'bowling', 'bowler', 'NEW ZEALAND', '1', '', '', '1', '1'),
(111, 78, '3.', 'ROHIT', '50', '15', 'out', 'batsmen', 'INDIA', '1', '5', '3', '', ''),
(112, 78, '', 'ISH', '45', '2', 'bowling', 'bowler', 'NEW ZEALAND', '1', '', '', '1', '1'),
(113, 78, '', 'WARNER', '45', '2', 'bowling', 'bowler', 'NEW ZEALAND', '1', '', '', '1', '1'),
(114, 78, '1', 'GUPTILL', '20', '40', 'out', 'batsmen', 'NEW ZEALAND', '2', '1', '0', '', ''),
(115, 78, '2.', 'RONCHI', '33', '15', 'playing', 'batsmen', 'NEW ZEALAND', '2', '2', '2', '', ''),
(116, 78, '', 'pandya', '23', '4', 'bowling', 'bowler', 'NEW ZEALAND', '2', '', '', '1', '0'),
(117, 78, '3', 'ISH', '55', '70', 'out', 'batsmen', 'NEW ZEALAND', '2', '2', '2', '', ''),
(118, 78, '', 'pandya1', '1', '2', 'bowling', 'bowler', 'NEW ZEALAND', '2', '', '', '2', '0'),
(119, 78, '', 'hardik', '1', '1', 'bowling', 'bowler', 'NEW ZEALAND', '2', '', '', '0', '1'),
(120, 78, '', 'pandy', '2', '1', 'bowling', 'bowler', 'NEW ZEALAND', '2', '', '', '0', '0'),
(121, 78, '', 'pandy 2', '2', '1', 'bowling', 'bowler', 'NEW ZEALAND', '2', '', '', '0', '1'),
(122, 79, '1', '1', '1', '1', 'playing', 'batsmen', 'test', '1', '', '', '', ''),
(123, 79, '2', 'sahid', '1', '1', 'playing', 'batsmen', 'test', '1', '0', '0', '', ''),
(124, 79, '', 'harry', '1', '2.2', 'bowling', 'bowler', 'fluid', '1', '', '', '0', '1'),
(125, 79, '', 'haepal', '1', '1.2', 'bowling', 'bowler', 'fluid', '1', '', '', '0', '0'),
(126, 79, '1', 'sanjeev', '1', '1', 'playing', 'batsmen', 'fluidsoft', '2', '0', '0', '', ''),
(127, 79, '2', 'aalam', '1', '1', 'playing', 'batsmen', 'fluidsoft', '2', '0', '0', '', ''),
(128, 79, '', 'rohit', '1', '1', 'bowling', 'bowler', 'fluid', '2', '', '', '0', '0'),
(129, 79, '', 'junaid', '1', '1.2', 'bowling', 'bowler', 'fluid', '2', '', '', '0', '1'),
(130, 79, '', 'er', '1', '1', 'bowling', 'bowler', 'fluid', '1', '', '', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE IF NOT EXISTS `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `match_id` varchar(50) NOT NULL,
  `gcm_token` mediumtext NOT NULL,
  `rate` int(11) NOT NULL,
  `rate_type` varchar(50) NOT NULL,
  `rate_varriation` varchar(50) NOT NULL,
  `favourite` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=83 ;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`id`, `match_id`, `gcm_token`, `rate`, `rate_type`, `rate_varriation`, `favourite`) VALUES
(81, '78', 'f-dtE2wcSdA:APA91bGCH7Fc3VbJT82idFN1daKV99GRmoGGK3GMwnD6l8ZWvG5qtbjl08fG4cPD-cp2D61rdQlDEqffsYiLvUeT-vjermH8Vgr_UjHCxLTYUtUyeM9o_4_jPd23TBwElZDrpPrbDIBb', 45, 'lay', '+=', 'INDIA'),
(80, '66', 'cV4q_aLNXv8:APA91bFzyXnMzE7oSXYJSHA8_sEk7RNEG9Ka5BkSqJ8OgHw88qgkZR1CCooibiCSk3D3iYHf8GWj25vWfXaRiPSkg2gJ-XtrjpJCRtT4vfcOmrmIyYU5u5r35ddmqoU4oAGLJenxofBr', 12, 'lay', '+', 'india'),
(79, '72', 'eT8qpsc0nLI:APA91bEjB4zurodrlMNNRbFdbIsyD4xx71ujxxMfhFsHVTKcxBrG0rlVSYYHHB6NLvzwggait0Fe0Mlun69dbMipdpLDWuMnvw9VJVzWmNoJs-TrFZ-bglXltxN6vliVOgiVbJOAWaYB', 20, 'lay', '-=', 'MM'),
(78, '72', 'fmKKezha3jY:APA91bHT1ECMdkc03x9kALoqzMEGd4khvg05B6Z29Zql0cAxeqNr84urYNk_6MmQOuvmb74Sw7gWJhFZefJ4q-vh_DEgUMmbEc7qQZQq9mhZ3VJGd4XbR2-4YGDIApAZ8q5V5vjhk2IZ', 20, 'lay', '-=', 'TT'),
(77, '66', 'dA4sSfY_OlA:APA91bHHLUbR4kwEgUAkcRUdHXTuXK8O4YtPWGXOWzIrQAFiTTaXcwf-uixT2h-sWEHZK0Z8Wtn4UZBU2lu0XsXOZ1bHTstJ5qKYKdqdgS0KfkrGyHphkZ_KF1UuXmFMaCSoywrzFr6W', 11, 'lay', '+', 'india'),
(76, '72', 'c3xOYXpyHh8:APA91bFavuNVbiWFpyEimkMpEDH1IN1jS0rNIPL2mgfPUAJlRdUa7kbS7VoH-EK-Porw75Ip81NxhRVt19jvGtftAnIzTUWDjXep2muHzioZM7Z75nomJwpFgeW-hY-b4S2qoyWZ3Apc', 54, 'lay', '+', 'MM'),
(75, '66', 'c3xOYXpyHh8:APA91bFavuNVbiWFpyEimkMpEDH1IN1jS0rNIPL2mgfPUAJlRdUa7kbS7VoH-EK-Porw75Ip81NxhRVt19jvGtftAnIzTUWDjXep2muHzioZM7Z75nomJwpFgeW-hY-b4S2qoyWZ3Apc', 44, 'back', '+=', 'india'),
(74, '73', 'eT8qpsc0nLI:APA91bEjB4zurodrlMNNRbFdbIsyD4xx71ujxxMfhFsHVTKcxBrG0rlVSYYHHB6NLvzwggait0Fe0Mlun69dbMipdpLDWuMnvw9VJVzWmNoJs-TrFZ-bglXltxN6vliVOgiVbJOAWaYB', 10, 'lay', '+', 'iuno'),
(73, '73', 'dohRc-jCCw8:APA91bHZvoNFqaaYTxAAfgzHTa7ylN-3rUpBpYdN8FUFC8nWGO7g_bQ9gnWOSp-gBsBSxZY8FUhAU1MOLi5lsNQgTJHPS2tSQ966gHOI-IsKuITCrinaBVRF10mG-jYNrjI5IdpvZqEH', 40, 'lay', '-=', 'MM'),
(71, '68', 'c6ums-JxsE4:APA91bHiv7Wv-JMqXhPeLn06SQOp48yhEd3VuYq4J7AU8xYD9ivDFsXNVAK1hOJbdX2RDCGO4D1NngSGecrROMbRbnKIwbiXpqdYwX6k79ByKbex5ZTnMlXfJMh9PKVDou4Y_2rvkYlk', 77, 'lay', '+', 'raj'),
(72, '72', 'dohRc-jCCw8:APA91bHZvoNFqaaYTxAAfgzHTa7ylN-3rUpBpYdN8FUFC8nWGO7g_bQ9gnWOSp-gBsBSxZY8FUhAU1MOLi5lsNQgTJHPS2tSQ966gHOI-IsKuITCrinaBVRF10mG-jYNrjI5IdpvZqEH', 22, 'back', '-=', 'india'),
(70, '66', 'c6ums-JxsE4:APA91bHiv7Wv-JMqXhPeLn06SQOp48yhEd3VuYq4J7AU8xYD9ivDFsXNVAK1hOJbdX2RDCGO4D1NngSGecrROMbRbnKIwbiXpqdYwX6k79ByKbex5ZTnMlXfJMh9PKVDou4Y_2rvkYlk', 55, 'lay', '+', 'india'),
(69, '66', 'dKQ4w-aPbXE:APA91bGGaf4TGidsUMyvUYyD6L6fOr-HCx1q1NHrPMaioODofqGG8h5ZhrsXsFm2yM2n45L52GFQAgo_jXpLC9IbwzbVzq22yv_Iy9CrqAiAmzCQCtCm2AnTUQautiz9ppKtCb93Ujhk', 44, 'lay', '=', 'india'),
(61, '66', 'eT8qpsc0nLI:APA91bEjB4zurodrlMNNRbFdbIsyD4xx71ujxxMfhFsHVTKcxBrG0rlVSYYHHB6NLvzwggait0Fe0Mlun69dbMipdpLDWuMnvw9VJVzWmNoJs-TrFZ-bglXltxN6vliVOgiVbJOAWaYB', 1, 'lay', '+', 'india'),
(62, '68', 'eT8qpsc0nLI:APA91bEjB4zurodrlMNNRbFdbIsyD4xx71ujxxMfhFsHVTKcxBrG0rlVSYYHHB6NLvzwggait0Fe0Mlun69dbMipdpLDWuMnvw9VJVzWmNoJs-TrFZ-bglXltxN6vliVOgiVbJOAWaYB', 77, 'lay', '+', 'raj'),
(64, '66', 'fOs0JMcnElU:APA91bHWBWcpgeQE9fH44muV9PaQdfuverSK1nO09yrVf38B04SwSLadqw_u099EPTrIGyiH2SLvhebAdZvLVSbZx3Mv0gHLgMoz1Tsq_6TV5OfWr-UqFjTkL0N5Cnx8qCLGvZlHe7VK', 20, 'lay', '-', 'india'),
(65, '66', 'frzhGGwmx3Y:APA91bGjGojU285Asm3hdeFZUDok7QlRHJ_MxqldcPpA6CO9AxDEd1eggdb1LHMNYeqjEtUqE7oyjk77God3W5c2mSWjxVpfYhBYG1qqduBtCBXOJnjIzyC0qCD3UiEh_izTtWYGGQTX', 20, 'lay', '-=', 'INDIA'),
(66, '69', 'fOs0JMcnElU:APA91bHWBWcpgeQE9fH44muV9PaQdfuverSK1nO09yrVf38B04SwSLadqw_u099EPTrIGyiH2SLvhebAdZvLVSbZx3Mv0gHLgMoz1Tsq_6TV5OfWr-UqFjTkL0N5Cnx8qCLGvZlHe7VK', 10, 'lay', '-', 'iun'),
(67, '68', 'fOs0JMcnElU:APA91bHWBWcpgeQE9fH44muV9PaQdfuverSK1nO09yrVf38B04SwSLadqw_u099EPTrIGyiH2SLvhebAdZvLVSbZx3Mv0gHLgMoz1Tsq_6TV5OfWr-UqFjTkL0N5Cnx8qCLGvZlHe7VK', 70, 'back', '-', 'money'),
(68, '72', 'fOs0JMcnElU:APA91bHWBWcpgeQE9fH44muV9PaQdfuverSK1nO09yrVf38B04SwSLadqw_u099EPTrIGyiH2SLvhebAdZvLVSbZx3Mv0gHLgMoz1Tsq_6TV5OfWr-UqFjTkL0N5Cnx8qCLGvZlHe7VK', 20, 'lay', '+', 'TT'),
(82, '69', 'fIbe7ePS4gU:APA91bE8-s9fZcbXt_MBXPyTmT9xfzEgSb37Tn2cPEWLrFMRbY-wYbaJlUvKX43r2zU5O8f3M0JTxPf5f9cfF3bJukDTJNuQSVChmgJqwLQscMN_jsus3ceKk0K_YCqgAx3wuhxLMz65', 100, 'lay', '=', 'india');

-- --------------------------------------------------------

--
-- Table structure for table `upcoming_match_stats`
--

CREATE TABLE IF NOT EXISTS `upcoming_match_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `match_id` int(11) NOT NULL,
  `team1_players` longtext NOT NULL,
  `team2_players` longtext NOT NULL,
  `pitch_report` longtext NOT NULL,
  `weather_report` longtext CHARACTER SET utf8 NOT NULL,
  `summary` longtext NOT NULL,
  `favourite` varchar(50) NOT NULL,
  `market_rate` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `upcoming_match_stats`
--

INSERT INTO `upcoming_match_stats` (`id`, `match_id`, `team1_players`, `team2_players`, `pitch_report`, `weather_report`, `summary`, `favourite`, `market_rate`) VALUES
(4, 46, ' Virat Kohli (c), MS Dhoni (wk), Rohit Sharma, Shikhar Dhawan, Manish Pandey, Kedar Jadhav, Hardik Pandya, Kuldeep Yadav, Yuzvendra Chahal, Jasprit Bumrah, Bhuvneshwar Kumar, Lokesh Rahul, Dinesh Karthik, Axar Patel, Ashish Nehra \r\n', ' David Warner (c), Tim Paine (wk), Aaron Finch, Moises Henriques, Travis Head, Glenn Maxwell, Marcus Stoinis, Nathan Coulter-Nile, Andrew Tye, Adam Zampa, Jason Behrendorff, Daniel Christian, Kane Richardson \r\n', 'Travis Head''s latest India sojourn can be summed up in a few words - immense backing, missed opportunities and delayed success. The 23-year-old arrived in India with Steven Smith throwing his weight behind the youngster and handing him the No. 4 spot. Even if that meant letting Hilton Cartwright open the batting in the first two One-Day Internationals.', 'Australia offered the 23-year-old chances in the No. 3, 4, 5 bracket in batting order to see what fits best, but couldn''t find conclusive evidence at the end of the five ODIs. Head at four was one of Australia''s projects in the series that didn''t quite take off like they - or he - would''ve liked, but the flame flickered on in the second T20I.', 'Australia offered the 23-year-old chances in the No. 3, 4, 5 bracket in batting order to see what fits best, but couldn''t find conclusive evidence at the end of the five ODIs. Head at four was one of Australia''s projects in the series that didn''t quite take off like they - or he - would''ve liked, but the flame flickered on in the second T20I.', '', ''),
(5, 47, ' Virat Kohli (c), MS Dhoni (wk), Rohit Sharma, Shikhar Dhawan, Manish Pandey, Kedar Jadhav, Hardik Pandya, Kuldeep Yadav, Yuzvendra Chahal, Jasprit Bumrah, Bhuvneshwar Kumar, Lokesh Rahul, Dinesh Karthik, Axar Patel, Ashish Nehra \r\n', ' David Warner (c), Tim Paine (wk), Aaron Finch, Moises Henriques, Travis Head, Glenn Maxwell, Marcus Stoinis, Nathan Coulter-Nile, Andrew Tye, Adam Zampa, Jason Behrendorff, Daniel Christian, Kane Richardson \r\n', 'Travis Head''s latest India sojourn can be summed up in a few words - immense backing, missed opportunities and delayed success. The 23-year-old arrived in India with Steven Smith throwing his weight behind the youngster and handing him the No. 4 spot. Even if that meant letting Hilton Cartwright open the batting in the first two One-Day Internationals.', 'Australia offered the 23-year-old chances in the No. 3, 4, 5 bracket in batting order to see what fits best, but couldn''t find conclusive evidence at the end of the five ODIs. Head at four was one of Australia''s projects in the series that didn''t quite take off like they - or he - would''ve liked, but the flame flickered on in the second T20I.', 'Australia offered the 23-year-old chances in the No. 3, 4, 5 bracket in batting order to see what fits best, but couldn''t find conclusive evidence at the end of the five ODIs. Head at four was one of Australia''s projects in the series that didn''t quite take off like they - or he - would''ve liked, but the flame flickered on in the second T20I.', '', ''),
(6, 48, ' Virat Kohli (c), MS Dhoni (wk), Rohit Sharma, Shikhar Dhawan, Manish Pandey, Kedar Jadhav, Hardik Pandya, Kuldeep Yadav, Yuzvendra Chahal, Jasprit Bumrah, Bhuvneshwar Kumar, Lokesh Rahul, Dinesh Karthik, Axar Patel, Ashish Nehra \r\n', ' David Warner (c), Tim Paine (wk), Aaron Finch, Moises Henriques, Travis Head, Glenn Maxwell, Marcus Stoinis, Nathan Coulter-Nile, Andrew Tye, Adam Zampa, Jason Behrendorff, Daniel Christian, Kane Richardson \r\n', 'Travis Head''s latest India sojourn can be summed up in a few words - immense backing, missed opportunities and delayed success. The 23-year-old arrived in India with Steven Smith throwing his weight behind the youngster and handing him the No. 4 spot. Even if that meant letting Hilton Cartwright open the batting in the first two One-Day Internationals.', 'Australia offered the 23-year-old chances in the No. 3, 4, 5 bracket in batting order to see what fits best, but couldn''t find conclusive evidence at the end of the five ODIs. Head at four was one of Australia''s projects in the series that didn''t quite take off like they - or he - would''ve liked, but the flame flickered on in the second T20I.', 'Australia offered the 23-year-old chances in the No. 3, 4, 5 bracket in batting order to see what fits best, but couldn''t find conclusive evidence at the end of the five ODIs. Head at four was one of Australia''s projects in the series that didn''t quite take off like they - or he - would''ve liked, but the flame flickered on in the second T20I.', '', ''),
(7, 64, '\r\nesd', '\r\nDFDF', 'DFDF', 'DDDF', 'DFFD', 'DFDF', 'DFDFDF'),
(8, 65, '\r\n', '\r\n', '', '', '', '', ''),
(9, 66, 'adarsh,mohit,raaj,akash,rahul,\r\n', '\r\n', '', '', '', '', ''),
(10, 70, '\r\n', '\r\n', '', '', '', '', ''),
(11, 69, '\r\n12', '12\r\n', '12', '12', '12', '12', '12'),
(12, 71, '\r\n', '\r\n', 'very hard pitch', 'cloudy', 'india will loose match', 'INDIA', '65-70'),
(13, 72, 'SBADCNSD\r\n', 'CVCV\r\n', 'VFGHFG', 'DSFSDG', 'VCNBCV', 'MM', '10-12'),
(14, 76, '\r\nVIRAT KOHLI,SHIKHAR DHAWAN,HARDIK PANDHYA, M.S DHONI,ROHIT SHARMA,KEDAR JADAV,JASPRIT BUMRAH,BHUVNESWAR KUMAR,RAVICHANDRAN ASWIN,RAVINDRA JADEEJA', '\r\nMARTIN GUPTILL, KANE WILLIAMSON,LUKE RONCHI,TIM SOUTHEE,JASTIN VIER', 'YEH PITCH EK DUM FLAT HAI YAHA RUNS BANEGE AUR CHASE HOGA', 'KAL BARISH AAYI THI BUT AAJ AISA KUCH NHI HONE WALA AAJ KA MOUSAM SAAF H PURA MATCH HONGA', 'INIDA IS FAV TO AAJ INDIA HI JTITEAGA', 'INDIA', '40-42'),
(15, 77, 'MS Dhoni (c & wk), Suresh Raina, Rohit Sharma, Ravindra Jadeja, Ishant Sharma, Virat Kohli, Shikhar Dhawan, Ajinkya Rahane, Ravichandran Ashwin, Bhuvneshwar Kumar, Mohammed Shami', 'Brendon McCullum (c), Ross Taylor, Nathan McCullum, Jesse Ryder, Tim Southee, Luke Ronchi (wk), Martin Guptill, Kane Williamson, Mitchell McClenaghan, Adam Milne, Corey Anderson\r\n', 'The usual hype surrounding any Indian series. For MS Dhoni, it is a great chance to get his players acclimatized to conditions before the World Cup next year. Remember New Zealand co-host the event with Australia. The defending world champions had a poor time in the ODIs in South Africa and Dhoni would like to see his team shape up, especially the bowlers', 'Blustery conditions. Strong gusting wind. The Indians were enveloped in two layers of woolen during their rigorous practise sessions over the past couple of days. The New Zealand skipper, Brendon McCullum and coach Mike Henson have urged the groundsmen to prepare fast, bouncy tracks to intimidate the Indian batsmen. A stiff challenge awaits Mahendra Singh Dhoni''s merry men. Hello and welcome to the series opening ODI between India and New Zealand at Napier. Whilst India are the Number 1 ranked ODI side, New Zealand are languishing at 8th place. But that does not tell us the entire story', 'India would look to gain some valuable experience and confidence when they clash with New Zealand in a five-match ODI series, beginning on Sunday, as Mahendra Singh Dhoni and his boys will begin the defence of their World Cup title on these very shores next year. \r\n\r\nThe reigning World Champions will also be looking to defend their number one ranking, in this format of the game, against the eighth-ranked hosts. Unlike their previous tour in December, this trip imparts greater significance to India. Against South Africa, the Indian team management decided to use the three-match series as a learning exercise for the ensuing Test series. It worked up to an extent against their formidable opponents with their young Test side losing the two-match series only on the last day of the tour at Durban. While the importance of taking that learning forward in the Tests versus New Zealand cannot be neglected, at the same time, India need to up the ante in ODIs as the run-up to their title defence officially begins. India will travel to Australia in the latter part of the 2014-15 season, which will be a final dress-rehearsal, and as such this series against the Black Caps is an important marker in their preparation for the World Cup. \r\n\r\nThe 16-man squad that has arrived here is already a much settled unit, losing only to Pakistan at home and South Africa away in the calendar year 2013, winning six consecutive ODI contests in between. While this provides a good starting point, there are important questions that need to be answered. The first of them is related to the opening combination, with both Shikhar Dhawan and Rohit Sharma not doing much in South Africa, ODIs and Tests combined. \r\n\r\nSharma perhaps has more time, given that he bats in the middle order in the longer format and particularly because on away tours, the role of openers to give a solid start becomes more important. Murali Vijay performed that bit to perfection in the Tests there, further highlighting Dhawan''s plight, who scored only 88 runs in six innings (avg. 14.66) in Africa. Even so, the toughest question pertains to the middle order, given that a misfiring Yuvraj Singh is no longer part of this ODI squad. The number four spot is proving to be a pain ever since this season started against Australia at home. Suresh Raina moved back to this spot in that series but the southpaw himself is struggling for consistency. Either he needs to draw experience of finishing the innings in these conditions, batting at number five or six, or he needs to learn how to drive the batting from number four, in preparation of the World Cup next year. Doing both is not an option for him or the team management. \r\n\r\nHe will need to watch out for Ambati Rayudu and Stuart Binny who will come into contention at some point in this series. Especially the latter, if Raina continues to bat at number five or six, since Binny too is a lower-order batsman. More importantly, he bowls military medium, which could be an additional usage in these windy and bouncy conditions. \r\n\r\nThe pace department looks settled for India. Ishant Sharma and Mohammed Shami will look to carry on from where they left off in South Africa, with Bhuvneshwar Kumar getting another look-in. Otherwise there is always Ishwar Pandey and Varun Aaron to contend with. \r\n\r\nIt looks like India will play five bowlers, though spin is where the real competition is. R Ashwin needs to win back his Test spot from Ravindra Jadeja and while both are expected to feature in the Indian ODI eleven, this could shape up to be a personal duel between them. For New Zealand too, this series is a good launch-pad to firm up their plans for the future. They have a good base going already, with new players - a healthy mix of ballistic batsmen and good all-rounders - coming through in the preceding West Indies series. \r\n\r\nThe key for them will be to put India under pressure early on in the series, putting the shorter grounds and windy conditions to good use. \r\n\r\nWhile skipper Brendon McCullum hinted that they might look to play four fast bowlers on Sunday, the Kiwis'' bowling coach Shane Bone was thinking in the longer term. Whilst hosting the World Cup next year, New Zealand will get to play a quarterfinal and a semifinal at their home turf, should they make it that far ahead into the tournament. \r\n\r\n"We might have to play India in the quarters, or the semis, next year. We too need to size them up and plan ahead," Bond said, ahead of the opening clash of the tour on Sunday.Teams:New Zealand (From): Martin Guptill, Jesse Ryder, Kane Williamson, Ross Taylor, Brendon McCullum(c), Corey Anderson, Luke Ronchi(w), Nathan McCullum, Tim Southee, Kyle Mills, Mitchell McClenaghan, James Neesham, Adam MilneIndia (From): Shikhar Dhawan, Rohit Sharma, Virat Kohli, Suresh Raina, MS Dhoni(w/c), Ajinkya Rahane, Ravindra Jadeja, Ravichandran Ashwin, Mohammed Shami, Ishant Sharma, Bhuvneshwar Kumar, Stuart Binny, Ishwar Pandey, Varun Aaron, Ambati Rayudu, Amit Mishra', 'NEWZILAND', '68-71'),
(16, 78, 'SHIKHAR, RAJU, KOHLI,ROHIT,SEHWAG,TENDULKAR,PADNYA,', '\r\nGUPTILL,TAYLOR,MACCULULLM,RONCHI,ISH SODHI,MONTY,ANDERSON', 'PITCH IS DRY HARD TO BELIWE THAT MAY BE SOFT', 'WHEATER IS CLODY MAY BE RAIN FALL DOWN AFTERR FEW OVERS', 'OVEROLL IT GREAT TO KNOW THAT ITS 100 MATCH HERE IN NAPIER', 'INIDA', '48-50');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gcm_token` text NOT NULL,
  `device_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
